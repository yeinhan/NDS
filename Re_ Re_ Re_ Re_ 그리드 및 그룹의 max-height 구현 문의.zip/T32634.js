
/*
 * 루트 컨테이너에서 load 이벤트 발생 시 호출.
 * 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 */
function onBodyLoad(e) {
	var tab1 = app.lookup("tab1");
		
	var grd1 = app.lookup("grd1");
	var rowCount = Math.floor(Math.random() * 15) + 1;
	for(var i = 0; i < rowCount; i++) {
		grd1.insertRow(i, false);
	}
	
	cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
		console.log("before: " + grd1.getActualRect().height);
		if (grd1.getActualRect().height >= 373){
			grd1.getParent().updateConstraint(grd1, {
				autoSize: "none",
				height: 373
			});
		}
		console.log("after: " + grd1.getActualRect().height);
		
		tab1.setSelectedTabItem(tab1.getTabItemByID(1));
	});
	
}


/*
 * 루트 컨테이너에서 init 이벤트 발생 시 호출.
 * 앱이 최초 구성될 때 발생하는 이벤트 입니다.
 */
function onBodyInit(e) {
	var tab1 = app.lookup("tab1");
	tab1.setItemsDelegate({
		shouldForceRender: function(folder, item){
			console.log("forcerender");
			return (folder.id == "tab1" && item.id == 1);
		}
	});
}
