/************************************************
 * Search_.js
 * @프로그램설명 : 
 *
 * @작성일자 :  2024. 10. 17..
 * @작성자 : ryu
 *
 * @수정이력 : 수정일자 (수정자) 수정내용
 ************************************************/

var util = createCommonUtil();

// 검색어일 경우 highlight
exports.highlight = function( /*String*/ psText, /*String*/ psDesc, /*String*/ psSearchText, self, /*String*/ psStandard) {
	if (ValueUtil.fixNull(psSearchText) == "") {
		return new cpr.expression.Expression(psStandard).evaluate(self);
	}
	var vsText = ValueUtil.fixNull(psText).toLowerCase();
	if (vsText.indexOf(psSearchText) != -1) {
		
		var voStyleInfo = {
			"classNames": ["text-red", "bg-yellow"],
			style: {}
		}
		var voStyledString = new cpr.ufc.StyledString();
		var vnIndex = vsText.indexOf(psSearchText);
		var vsReplaceText = psText.substr(vnIndex, psSearchText.length);
		if (vnIndex > 0) {
			voStyledString.append(psText.substring(0, vnIndex));
		}
		voStyledString.append(vsReplaceText, voStyleInfo);
		if (vnIndex + psSearchText.length < vsText.length) {
			voStyledString.append(psText.substring(vnIndex + psSearchText.length, vsText.length));
		}
		return voStyledString;
	} else {
		var vsDesc = ValueUtil.fixNull(psDesc).toLowerCase();
		if (vsDesc != "" && vsDesc.indexOf(psSearchText) != -1) {
			var voRelatedStyle = {
				classNames: ["text-sm", "text-red", "bg-yellow"],
				style: {}
			}
			var voStyledString = new cpr.ufc.StyledString();
			voStyledString.append(psText + " ");
			voStyledString.append(" 연관됨    ", voRelatedStyle);
			return voStyledString;
		}
		return new cpr.expression.Expression(psStandard).evaluate(self);
	}
}
var moDataAllMenu;
/*
 * 루트 컨테이너에서 load 이벤트 발생 시 호출.
 * 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 */
function onBodyLoad(e){

	moDataAllMenu = app.getRootAppInstance().lookup("dsAllMenu");
	
	var vcBtnTop = app.lookup("btnSetTop");
	app.floatControl(vcBtnTop, {
		bottom: "24px",
		right: "24px",
		width: "48px",
		height: "48px"
	});
	
	if(app.getHost()) {
		var initValue = app.getHost().getAppProperty("initValue");
		if(!ValueUtil.isNull(initValue)) {
			util.Control.setValue(app, "srch1", initValue);
			app.lookup("srch1").search();
		}
	}
}

/*
 * 루트 컨테이너에서 screen-change 이벤트 발생 시 호출.
 * 스크린 크기 변경 시 호출되는 이벤트.
 */
function onBodyScreenChange(e){
}


/*
 * 서치 인풋에서 search 이벤트 발생 시 호출.
 * Searchinput의 enter키 또는 검색버튼을 클릭하여 인풋의 값이 Search될때 발생하는 이벤트
 */
function onSearchInputSearch(e){
	var searchInput = e.control;
	var vsSearchValue = app.lookup("srch1").value;
	if(!ValueUtil.isNull(vsSearchValue)){
		var replaceValue = vsSearchValue.replace("([\'\"\\])", "");
	}
	
	var vcSiteMap = app.lookup("grpSitemap2");
	var vsParentValue = app.lookup("rdbFilterRange").value;
	var vcIncludeChkBox = app.lookup("includeCheckBox");
	var vcIncludeInput = app.lookup("includeInputBox");
	var vcExcludeCheck = app.lookup("excludeCheckBox");
	var vcExcludeInput = app.lookup("excludeInputBox");
	// 검색 결과들 지움
	vcSiteMap.removeAllChildren();
	
	if(ValueUtil.isNull(vsSearchValue)){
		emptySearchItem();
		app.lookup("optSearchCnt").value = 0;
		return;
	}
	
	var vcTree = new cpr.controls.Tree();
	vcTree.setItemSet(moDataAllMenu, {
		label: "MENU_NM",
		value: "MENU_ID",
		parentValue: "UP_MENU_ID"
	});
	// MENU_DESC = 메뉴 NAME + DESC
	var vsFilterStr = "doLowerCase(MENU_DESC) *= '"+ vsSearchValue.toLowerCase() +"' && CALL_PAGE != ''";
	vcTree.setFilter(vsFilterStr);
	var vaTreeFilterArr = vcTree.getItems();
	
	// 검색 범위
	if(vsParentValue != "__all__"){
		vsFilterStr += "&& hasAncestor('"+ vsParentValue +"')";
	}
	// 포함하는 단어
	if(vcIncludeChkBox.checked){
		if(vcIncludeInput.value == null){
			vcIncludeInput.value = ValueUtil.fixNull(vcIncludeInput.value);
		}
		// 빈값이 아닐 경우에만 필터
		if(vcIncludeInput.value != ""){
			vsFilterStr += "&& doLowerCase(MENU_DESC) *= '" + vcIncludeInput.value.toLowerCase() + "'";
		}
	}
	// 제외하는 단어
	if(vcExcludeCheck.checked){
		if(vcExcludeInput.value == null){
			vcExcludeInput.value = ValueUtil.fixNull(vcExcludeInput.value);
		}
		// 빈값이 아닐 경우에만 필터
		if(vcExcludeInput.value != ""){
			vsFilterStr += "&& (doLowerCase(MENU_DESC) *= '" + vcExcludeInput.value.toLowerCase() + "' ? false : true)"
		}
	}
	
	vcTree.setFilter(vsFilterStr);
	vaTreeFilterArr = vcTree.getItems();
	
	// 검색 결과가 없을 경우
	if(vaTreeFilterArr.length == 0){
		emptySearchItem();
	}
	
	// 검색 결과 동적 생성
	vaTreeFilterArr.forEach(function(each,idx){
		var vbNotice = false;
		if(idx == vaTreeFilterArr.length-1){
			vbNotice = true;
		}
		createSearchItem(each.row, replaceValue, vbNotice);
	});
	
	util.Control.setValue(app, "optSearchCnt", vaTreeFilterArr.length);
}

// 검색 결과가 없을 경우
function emptySearchItem(){
	var vcContainer = new cpr.controls.Container();
	var vcSiteMap = app.lookup("grpSitemap2");
	
	var vcContainer = new cpr.controls.Container();
	vcContainer.style.setClasses(["item"]);
	var vcLayout = new cpr.controls.layouts.VerticalLayout();
	vcLayout.spacing = 0;
	vcContainer.setLayout(vcLayout);
					
	var vcOutput = new cpr.controls.Output();
	vcOutput.style.setClasses(["text-lg", "font-medium", "text-center"]);
	vcOutput.value = "조회된 내용이 없습니다."
	
	vcContainer.addChild(vcOutput,{
		"autoSize" : "height"
	});
	
	vcSiteMap.addChild(vcContainer, {
		"autoSize" : "height"
	});
	
	util.Msg.notify(app, "INF-M004");
}

/**
 * 검색 결과 동적 생성
 * @param {cpr.data.Row} voRow
 * @param {String} replaceValue
 * @param {Boolean} pbNotice
 */
function createSearchItem(voRow, replaceValue, pbNotice){
	
	// 메뉴 위치 (메뉴 최상위까지 배열에 저장)
	var vaResultRows = [];
	var vaResultRow = moDataAllMenu.findAllRow("MENU_ID == '"+ voRow.getValue("UP_MENU_ID") +"'");
	while(vaResultRow.length > 0){
		vaResultRow.forEach(function(each){
			vaResultRows.push(each);
		});
		
		var vaTmpRow = [];		
		vaResultRow.forEach(function(each){
			 var vaTmpFindedRow = moDataAllMenu.findAllRow("MENU_ID == '"+each.getValue("UP_MENU_ID")+"'");
			 vaTmpFindedRow.forEach(function(fEach){
			 	vaTmpRow.push(fEach);
			 });			 
		});
		
		if(vaTmpRow.length > 0) {
			vaResultRow = vaTmpRow;
		} else {
			vaResultRow = [];
		}
	};
	
	var vcRoot = app.lookup("grpSitemap2");
	// 조회된 결과 카드 형태로 동적 생성
	var vcContainer1 = new cpr.controls.Container();
	vcContainer1.style.setClasses(["item"]);
	var vcContainer1_Vertical = new cpr.controls.layouts.VerticalLayout();
	vcContainer1_Vertical.spacing = 0;
	vcContainer1.setLayout(vcContainer1_Vertical);
	
	// 메뉴 위치 동적 생성 (ex. 공통모듈 예제 > 공통모듈 > 유효성 체크 > 그리드 유효성 검사)
	var vcOutput1 = new cpr.controls.Output();
	vcOutput1.value = "";
	vcOutput1.style.setClasses(["location"]);
	for(var i = vaResultRows.length-1 ; i >= 0; i--){
		vcOutput1.value += vaResultRows[i].getValue("MENU_NM") + " > ";
	}
	vcOutput1.value += " " + voRow.getValue("MENU_NM");
	vcContainer1.addChild(vcOutput1, {
		"autoSize": "height",
		"width": "100px",
		"height": "20px"
	});
	
	// 메뉴 NAME 동적 생성
	var vcOutput3 = new cpr.controls.Output();
	vcOutput3.value = voRow.getValue("MENU_NM");
	// 검색어일 경우 highlight
	vcOutput3.displayExp = "@highlight(value,null,'"+replaceValue+"',this,'value')";
	vcOutput3.ellipsis = true;
	vcOutput3.style.setClasses(["title"]);
	vcContainer1.addChild(vcOutput3, {
		"autoSize": "height",
		"width": "100px",
		"height": "36px"
	});
	// 메뉴 DESC 동적 생성
	var vcOutput4 = new cpr.controls.Output();
	vcOutput4.value = voRow.getValue("DESC");
	// 검색어일 경우 highlight
	vcOutput4.displayExp = "@highlight(value,null,'"+replaceValue+"',this,'value')";
	vcOutput4.style.setClasses(["desc"]);
	vcContainer1.addChild(vcOutput4, {
		"autoSize": "height",
		"width": "100px",
		"height": "40px"
	});
	
	// 메뉴 TAG 동적 생성
	var vcContainer3 = new cpr.controls.Container();
	vcContainer3.style.setClasses(["badge-wrap"]);
	var vcContaienr3_Flow = new cpr.controls.layouts.FlowLayout();
	vcContaienr3_Flow.scrollable = false;
	vcContaienr3_Flow.horizontalSpacing = 8;
	vcContaienr3_Flow.verticalSpacing =8;
	vcContainer3.setLayout(vcContaienr3_Flow);
	
	if(!ValueUtil.isNull(voRow.getValue("TAG"))){
		// , 로 구분하여 각각 동적 생성
		var vsSplittedTag = voRow.getValue("TAG").split(",")
		if(vsSplittedTag.length > 0 && !(ValueUtil.isNull(vsSplittedTag))){
			for(var i=0; i<vsSplittedTag.length;i++){
				var vcOutput5 = new cpr.controls.Output();
				vcOutput5.value = vsSplittedTag[i];
				// 검색어일 경우 highlight
				vcOutput5.displayExp = "@highlight(value,null,'"+replaceValue+"',this,'value')";
				vcOutput5.style.setClasses(["badge"]);
				vcContainer3.addChild(vcOutput5, {
					"autoSize": "width",
					"width": "100px",
					"height": "26px"
					});
			};
		};
	}
		
	vcContainer1.addChild(vcContainer3, {
		"autoSize": "height",
		"width": "400px",
		"height": "52px"
	});
	vcRoot.addChild(vcContainer1, {
		"autoSize": "height",
		"width": "400px",
		"height": "200px"
	});
	
	if(pbNotice){
		// 조회되었습니다.
		util.Msg.notify(app, "INF-M001");
	}	
	// 해당 카드 클릭 시 페이지 열리도록
	vcContainer1.addEventListener("click", function(e){
		openApp(voRow);
	});
}

/*
 * 인풋 박스에서 keydown 이벤트 발생 시 호출.
 * 사용자가 키를 누를 때 발생하는 이벤트. 키코드 관련 상수는 {@link cpr.events.KeyCode}에서 참조할 수 있습니다.
 */
function onIncludeInputBoxKeydown(e){
	var includeInputBox = e.control;
	var vcSearchInput = app.lookup("srch1");
	if(e.keyCode == cpr.events.KeyCode.ENTER){
		vcSearchInput.search();
	}
}

/*
 * 인풋 박스에서 keydown 이벤트 발생 시 호출.
 * 사용자가 키를 누를 때 발생하는 이벤트. 키코드 관련 상수는 {@link cpr.events.KeyCode}에서 참조할 수 있습니다.
 */
function onExcludeInputBoxKeydown(e){
	var excludeInputBox = e.control;
	var vcSearchInput = app.lookup("srch1");
	if(e.keyCode == cpr.events.KeyCode.ENTER){
		vcSearchInput.search();
	}
}

/*
 * 체크 박스에서 value-change 이벤트 발생 시 호출.
 * CheckBox의 value를 변경하여 변경된 값이 저장된 후에 발생하는 이벤트.
 */
function onIncludeCheckBoxValueChange(e){
	var includeCheckBox = e.control;
	
	var vcIncludeChkBox = app.lookup("includeCheckBox");
	var vcIncludeInput = app.lookup("includeInputBox");
	// 체크박스 true일 경우에만 입력 가능
	if(vcIncludeChkBox.checked){
		vcIncludeInput.enabled = true;
	}else{
		vcIncludeInput.enabled = false;
		vcIncludeInput.value = "";
	}
}

/*
 * 체크 박스에서 value-change 이벤트 발생 시 호출.
 * CheckBox의 value를 변경하여 변경된 값이 저장된 후에 발생하는 이벤트.
 */
function onExcludeCheckBoxValueChange(e){
	var excludeCheckBox = e.control;
	
	var vcExcludeChkBox = app.lookup("excludeCheckBox");
	var vcExcludeInput = app.lookup("excludeInputBox");
	// 체크박스 true일 경우에만 입력 가능
	if(vcExcludeChkBox.checked){
		vcExcludeInput.enabled = true;
	}else{
		vcExcludeInput.enabled = false;
		vcExcludeInput.value = "";
	}
}

/**
 * 
 * @param {cpr.data.Row} poRow
 */
function openApp(poRow){
	//메인화면 호스트앱의 instance 를 가져온다.
	var vcMdiCn = app.getRootAppInstance().lookup("mdiCn");
	
	//배열형태
	var vsCallPage = poRow.getValue("CALL_PAGE");
	var vsMenuId = poRow.getValue("MENU_ID");
	var vsMenuNm = poRow.getValue("MENU_NM");
	
	var vaCallPgm = vsCallPage.toString().split("/");
	//vaCallPgm 에서 앱이름을 가져옴(배열의 맨 마지막)
	
	var vsPgm = vaCallPgm[vaCallPgm.length - 1];
	//.clx확장자를 뺀 아이디값을 가져옴
	var vsPgmId = vsPgm.substr(0, vsPgm.length - 4);
	
	var vsAppId = vsCallPage.replace(".clx", "");
	var voRootAppIns = app.getRootAppInstance();
	if(voRootAppIns.hasAppMethod("openPage")) {
		voRootAppIns.callAppMethod("openPage", poRow);
	}
					
	if (!ValueUtil.isNull(vsCallPage) && window.eb6Preview){
		window.eb6Preview.openAppEditor(vsCallPage.split(".clx")[0]);
	}
}

/*
 * 버튼에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onButtonClick2(e){
	var button = e.control;
	
	app.getContainer().scrollTo(0, 0, 0.5);
}

/*
 * 루트 컨테이너에서 scroll 이벤트 발생 시 호출.
 * 그룹 컨텐츠가 스크롤될 때 발생하는 이벤트.
 */
function onBodyScroll2(e){
	var group = e.control;
	var vcBtnSetTop = app.lookup("btnSetTop");
	vcBtnSetTop.visible = true;
	
	if(app.getContainer().getViewPortRect().top == 0){
		vcBtnSetTop.visible = false;
	}
}

/*
 * 루트 컨테이너에서 property-change 이벤트 발생 시 호출.
 * 앱의 속성이 변경될 때 발생하는 이벤트 입니다.
 */
function onBodyPropertyChange(e){
	
	if(app.rendered) {
		var initValue = app.getHost().getAppProperty("initValue");
		if(!ValueUtil.isNull(initValue)) {
			util.Control.setValue(app, "srch1", initValue);
			app.lookup("srch1").search();
		}
	}
}
