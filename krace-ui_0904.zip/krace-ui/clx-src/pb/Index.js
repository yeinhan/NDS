/************************************************
 * @file      Index.js
 * @author    ryu
 * @created   2026. 4. 6. 오전 9:36:34
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/

/**
 * @function
 * @desc	임베디드앱에 페이지를 표시합니다.
 * @param	{cpr.controls.TreeItem} item
 */
function openPage(item) {
	var row = item.row;
	var appId = row.getValue("CALL_PAGE");
	if (appId && appId != "") {
		var content = app.lookup("eaCn");
		new cpr.core.App.load(appId, function(loadedApp){
			content.app = loadedApp;
			content.ready(function(ea){
			})
		});
	}
}

/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyLoad(e){
	/* 사이드 내비게이션 아이템 펼침 및 닫힘 방지 */
	var navigation = app.lookup("snavMenu");
	navigation.expandAllItems();
	navigation.addEventListener("node-close", function(e){
		e.preventDefault();
	});
	
	/* 사이드 내비게이션 Sticky */
	var aside = navigation.getParent();
	var header = app.lookup("header");
	
	if (!aside || !header) {
		console.warn("Sticky 적용을 위한 타겟 또는 기준 객체를 찾을 수 없습니다.");
		return;
	}
	
	// 기준값 상태 보관 객체
	var stickyState = {
		initialY: 0,
		paddingTop: 0,
		isFixed: false,
		isCalculated: false
	}
	
	/**
	 * 초기 로드 시점 및 화면 크기 변경 시 호출
	 */
	function calcuateBounds() {
		// transform 적용 상태에서 좌표 측정시 오차 발생으로 임시 해제
		var wasFixed = stickyState.isFixed;
		if (wasFixed) {
			aside.style.removeStyle("transform");
		}
		
		// 실제 렌더링된 패딩 값 수집
		var asideEl = document.querySelector("[data-usr-sticky-target='true']");
		if (asideEl) {
			var computedStyle = window.getComputedStyle(asideEl);
			stickyState.paddingTop = parseFloat(computedStyle.paddingTop) || 0;
		}
		
		// 기준 Y 좌표 갱신
		var rect = aside.getActualRect();
		var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
		stickyState.initialY = rect.top + scrollTop;
		
		// 상태 계산 완료 처리
		stickyState.isCalculated = true;
		
		if (wasFixed) {
			handleSticky();
		}
	}
	
	/**
	 * 스타일 제어 토글 및 레이아웃 붕괴 방지
	 */
	function handleSticky() {
		var currentScrollY = window.pageYOffset || document.documentElement.scrollTop;
		var threshold = stickyState.initialY;
		
		if (currentScrollY >= threshold) {
			var moveY = currentScrollY - threshold;
			
			aside.style.css({
				"transform": "translateY(" + moveY + "px)",
				"z-index": "1"
			});
			stickyState.isFixed = true;
		} else {
			if (stickyState.isFixed) {
				aside.style.removeStyle("transform");
				aside.style.removeStyle("z-index");
				stickyState.isFixed = false;
			}
		}
	}
	
	// 렌더링 성능 최적화 (requestAnimationFrame) 및 이벤트 핸들러 구성
	var isTicking = false;
	function onScroll() {
		// 스크롤 처음 발생 시 기준값 없는 경우 1회 계산 수행
		if (!stickyState.isCalculated) {
			calcuateBounds();
		}
		
		if (!isTicking) {
			window.requestAnimationFrame(function() {
				handleSticky();
				isTicking = false;
			});
			isTicking = true;
		}
	}
	
	// 스크립트 실행 시점의 초기 기준값 계산
	//calcuateBounds();
	
	// 이벤트 바인딩
	window.addEventListener("scroll", onScroll);
	window.addEventListener("resize", calcuateBounds);
	
	// 메모리 누수 방지 (생명주기 이벤트 초기화)
	app.addEventListener("unload", function(e){
		window.removeEventListener("scroll", onScroll);
		window.removeEventListener("resize", calcuateBounds);
	});
	
	/* 첫 페이지 로드 (소개) */
	navigation.dispatchEvent(new cpr.events.CItemEvent("item-click", {
		item: navigation.getItemByValue("O_M1")
	}));
}

/**
 * @function 
 * @desc    "eXBuilder6" 버튼(logo)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onLogoClick(e){
	location.reload();
}

/**
 * @function 
 * @desc    "검색" 버튼(btnSch)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onBtnSchClick(e){
}

/**
 * @function 
 * @desc    "다운로드" 버튼(btnDown)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onBtnDownClick(e){
	var pages = app.lookup("dsPubMenu").findAllRow("CALL_PAGE *= 'pb/guide/'");
	if (pages.length === 0) return;
	
	pages.sort();

	var guideApp = new cpr.core.App("__guide__", {
		onPrepare: function(loader) {
			loader.addScript("pb/asset/js/html2canvas.min.js");
			loader.addScript("pb/asset/js/jspdf.umd.min.js");
		},
		onCreate: function(app, exports) {
			var container = app.getContainer();
			container.style.addClass("pb-preview");
			
			var layout = new cpr.controls.layouts.VerticalLayout();
			layout.spacing = 0;
			layout.scrollable = true;
			container.setLayout(layout);
			
			var pbPdfExport = cpr.core.Module.require("pb/asset/js/awesome-pdf").pdfExport;
			
			app.addEventListener("init", function(e) {
				/** @type cpr.data.DataRow[] */
				var pages = app.getHostProperty("initValue");
				if (!pages) return;
				
				for (var p = 0; p < pages.length; p++) {
					var page = pages[p].getRowData();
					
					new cpr.core.App.load(page["CALL_PAGE"], function(loadedApp) {
						var embed = new cpr.controls.EmbeddedApp("", loadedApp);
						embed.ready(function(ea) {
							// 숨겨진 코드 블럭을 표시
							var eaAppIns = ea.getEmbeddedAppInstance();
							eaAppIns.getContainer().getAllRecursiveChildren(false).filter(function(each) {
								return each.style.hasClass("code") && each.style.hasClass("cm");
							}).forEach(function(code) {
								code.visible = true;
							});
						});
						
						container.addChild(embed, {
							autoSize: "height"
						});
					});
				}
			});
			
			app.addEventListener("load", function(e) {
				cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function(){ 
					setTimeout(function(){
						pbPdfExport({
							onClose: function() {
								// 콘텐츠 수집 왼료 후 print-root 삽입 전 시점에 호출
								app.close();
							}
						});
					}, 500);
				});
			});
		}
	});
	
	app.getRootAppInstance().dialogManager.openDialog(guideApp, "__guide_pop__", {top: 0, bottom: 0, width: 1280}, function(dialog){
		dialog.initValue = pages;
		dialog.style.css("opacity", "0");
		dialog.modal = false;
	});
}

/**
 * @function 
 * @desc    사이드 내비게이션에서 아이템 클릭시 발생하는 이벤트.
 * @param   {cpr.events.CItemEvent} e 이벤트 객체
 */
function onSnavMenuItemClick(e){
	openPage(e.item);
}
