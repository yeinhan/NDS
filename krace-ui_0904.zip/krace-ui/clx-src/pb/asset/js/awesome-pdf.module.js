/************************************************
 * @file      awesome-pdf.module.js
 * @desc      상세 역할을 기술하세요
 * @author    ryu
 * @created   2026. 4. 17. 오후 2:43:28
 * * [Dependencies]
 * - 파일경로 (역할)
 * * [History]
 * - 2026. 4. 17. : 최초 생성 (ryu)
 ************************************************/

/**
 * @file      pdf-download.module.js
 * @desc      클라이언트 사이드 PDF 다운로드 모듈 (ES5 / IE11 호환)
 *            DOM 재조립 방식 — eXBuilder6 pb-* 요소만 선택 추출하여 새 HTML 생성
 *
 * [Dependencies]
 *   - html2canvas.min.js  (v1.4.1+)  : pb-playground-in 캡처용
 *
 * [Usage]
 *   pbPdfExport({
 *     output  : 'print',        // 'print'(기본) | 'pdf'
 *     filename: 'guide.pdf',    // output='pdf' 일 때 파일명
 *     onClose : function() {}   // 콘텐츠 수집 완료 후 호출 콜백 (열려있던 다이얼로그 닫기 등)
 *   });
 *
 * [History]
 *   v4.1 - 로딩 오버레이 + 진행 상태 표시 + onClose 콜백 옵션 추가
 *   v4.0 - DOM 재조립 방식으로 전면 재작성
 */

/* ================================================================
 * 설정
 * ================================================================ */
var PDF_CONFIG = {
	previewSelector: '.pb-preview',
	pageSelector: '.pb-guide-page',
	output: 'print',
	filename: 'guide.pdf',
	pageMarginMm: 15,
	onClose: null // 콘텐츠 수집 완료 후 호출 콜백 (다이얼로그 닫기 등)
};

/* ================================================================
 * 진입 함수
 * ================================================================ */
exports.pdfExport = pbPdfExport;

function pbPdfExport(userConfig) {
	var cfg = _merge(PDF_CONFIG, userConfig || {});
	
	var preview = document.querySelector(cfg.previewSelector);
	if (!preview) {
		console.error('[pb-pdf] 미리보기 영역을 찾을 수 없습니다: ' + cfg.previewSelector);
		return;
	}
	
	var pageEls = [].slice.call(preview.querySelectorAll(cfg.pageSelector));
	if (!pageEls.length) {
		console.error('[pb-pdf] 가이드 페이지를 찾을 수 없습니다: ' + cfg.pageSelector);
		return;
	}
	
	// 스타일 주입
	_injectStyles();
	
	// 로딩 오버레이 생성
	var loader = _createLoader();
	_setLoaderStep(loader, 'collecting', '섹션 분석 중...', pageEls.length);
	
	// 비동기 처리 (playground 캡처 포함)
	_buildSections(pageEls, loader).then(function(sectionsHtml) {
		
		// ── onClose 콜백 ──────────────────────────────────────────
		// 콘텐츠 수집 완료 시점: print-root 삽입 전이므로 다이얼로그를 안전하게 닫을 수 있음
		if (typeof cfg.onClose === 'function') {
			try { cfg.onClose(); }
			catch (e) {
				console.warn('[pb-pdf] onClose 콜백 오류:', e);
			}
		}
		
		_setLoaderStep(loader, 'building', '문서 구성 중...');
		
		// print-root 생성 및 삽입
		var printRoot = _buildPrintRoot(sectionsHtml);
		
		// body 원본 요소 숨김
		var hidden = _hideBodySiblings(printRoot);
		
		// 로더 제거
		_removeLoader(loader);
		
		// 출력
		if (cfg.output === 'pdf') {
			_exportPdf(printRoot, cfg, function() {
				_cleanup(printRoot, hidden);
			});
		}
		else {
			_exportPrint(printRoot, hidden);
		}
		
	}).catch(function(err) {
		console.error('[pb-pdf] 오류:', err);
		_removeLoader(loader);
	});
}

/* ================================================================
 * 로딩 오버레이
 * ================================================================ */
function _createLoader() {
	var overlay = document.createElement('div');
	overlay.id = 'pb-pdf-loader';
	
	var card = document.createElement('div');
	card.id = 'pb-pdf-loader-card';
	
	var spinner = document.createElement('div');
	spinner.id = 'pb-pdf-spinner';
	
	var stepEl = document.createElement('div');
	stepEl.id = 'pb-pdf-step';
	
	var detailEl = document.createElement('div');
	detailEl.id = 'pb-pdf-detail';
	
	card.appendChild(spinner);
	card.appendChild(stepEl);
	card.appendChild(detailEl);
	overlay.appendChild(card);
	document.body.appendChild(overlay);
	
	return { overlay: overlay, step: stepEl, detail: detailEl };
}

function _setLoaderStep(loader, type, detail) {
	if (!loader || !loader.step) return;
	var labels = {
		collecting: 'PDF 콘텐츠 수집 중',
		capturing: '미리보기 캡처 중',
		building: '문서 구성 중',
		printing: '인쇄 준비 중'
	};
	loader.step.textContent = labels[type] || type;
	loader.detail.textContent = detail || '';
}

function _updateLoaderCapture(loader, current, total) {
	if (!loader) return;
	loader.step.textContent = '미리보기 캡처 중';
	loader.detail.textContent = current + ' / ' + total + ' 완료';
}

function _updateLoaderSection(loader, current, total) {
	if (!loader) return;
	loader.step.textContent = 'PDF 콘텐츠 수집 중';
	loader.detail.textContent = current + ' / ' + total + ' 섹션 처리 완료';
}

function _removeLoader(loader) {
	if (loader && loader.overlay && loader.overlay.parentNode) {
		loader.overlay.parentNode.removeChild(loader.overlay);
	}
}

/* ================================================================
 * 섹션 빌드 (HTML 재조립)
 * ================================================================ */
function _buildSections(pageEls) {
	// 순차 처리 (playground 캡처가 async이므로)
	var chain = Promise.resolve([]);
	var results = [];
	
	for (var i = 0; i < pageEls.length; i++) {
		(function(pageEl, idx) {
			chain = chain.then(function() {
				return _buildOnePage(pageEl, idx);
			}).then(function(html) {
				results.push(html);
				return results;
			});
		})(pageEls[i], i);
	}
	
	return chain.then(function() { return results; });
}

function _buildOnePage(pageEl, idx, loader) {
	var parts = [];
	
	return _walkChildren(pageEl, parts, loader).then(function() {
		var sectionClass = 'pdf-section' + (idx === 0 ? ' pdf-section-first' : '');
		return '<div class="' + sectionClass + '">' + parts.join('') + '</div>';
	});
}

/* ================================================================
 * 재귀 탐색 — pb-* 요소를 depth 무관하게 순서대로 추출
 * ================================================================ */
function _walkChildren(node, parts, loader) {
	var children = [].slice.call(node.children || []);
	var chain = Promise.resolve();
	
	for (var i = 0; i < children.length; i++) {
		(function(child) {
			chain = chain.then(function() {
				return _processNode(child, parts, loader);
			});
		})(children[i]);
	}
	
	return chain;
}

function _processNode(el, parts, loader) {
	var cls = el.className || '';
	
	// ── pb-page-title (h1) ──────────────────────────────
	if (_hasClass(cls, 'pb-page-title')) {
		parts.push('<h1 class="pdf-h1">' + _extractInline(el) + '</h1>');
		return Promise.resolve();
	}
	
	// ── pb-page-subtitle ────────────────────────────────
	if (_hasClass(cls, 'pb-page-subtitle')) {
		parts.push('<p class="pdf-subtitle">' + _extractInline(el) + '</p>');
		return Promise.resolve();
	}
	
	// ── pb-title-h2 ─────────────────────────────────────
	if (_hasClass(cls, 'pb-title-h2')) {
		parts.push('<h2 class="pdf-h2">' + _extractInline(el) + '</h2>');
		return Promise.resolve();
	}
	
	// ── pb-title-h3 ─────────────────────────────────────
	if (_hasClass(cls, 'pb-title-h3')) {
		parts.push('<h3 class="pdf-h3">' + _extractInline(el) + '</h3>');
		return Promise.resolve();
	}
	
	// ── pb-title-h4 (callout 밖) ─────────────────────────
	if (_hasClass(cls, 'pb-title-h4')) {
		parts.push('<h4 class="pdf-h4">' + _extractInline(el) + '</h4>');
		return Promise.resolve();
	}
	
	// ── pb-p ─────────────────────────────────────────────
	if (_hasClass(cls, 'pb-p')) {
		parts.push('<p class="pdf-p">' + _extractInline(el) + '</p>');
		return Promise.resolve();
	}
	
	// ── pb-list ──────────────────────────────────────────
	if (_hasClass(cls, 'pb-list')) {
		var listCls = 'pdf-list';
		var listPrefix = '';
		
		if (_hasClass(cls, 'decimal')) {
			listCls += ' pdf-list-decimal';
			listPrefix = '<span class="pdf-list-bullet">•</span>';
		}
		else if (_hasClass(cls, 'dash')) {
			listCls += ' pdf-list-dash';
			listPrefix = '<span class="pdf-list-bullet">-</span>';
		}
		else if (_hasClass(cls, 'order')) {
			listCls += ' pdf-list-order';
			var numEl = el.querySelector('.num');
			var numText = numEl ? numEl.textContent.trim() : '';
			if (numText) {
				listPrefix = '<span class="pdf-list-bullet">' + _esc(numText) + '</span>';
			}
		}
		if (_hasClass(cls, 'indent')) listCls += ' pdf-list-indent';
		
		parts.push(
			'<p class="' + listCls + '">'
			+ listPrefix
			+ '<span class="pdf-list-text">' + _extractInline(el) + '</span>'
			+ '</p>'
		);
		return Promise.resolve();
	}
	
	// ── pb-callout ───────────────────────────────────────
	if (_hasClass(cls, 'pb-callout')) {
		parts.push(_buildCallout(el));
		return Promise.resolve();
	}
	
	// ── pb-table ─────────────────────────────────────────
	if (_hasClass(cls, 'pb-table')) {
		parts.push(_buildTable(el));
		return Promise.resolve();
	}
	
	// ── pb-playground ────────────────────────────────────
	if (_hasClass(cls, 'pb-playground')) {
		var pgIndent = _hasClass(cls, 'indent');
		return _buildPlayground(el, loader).then(function(html) {
			if (html && pgIndent) {
				html = html.replace('class="pdf-playground"', 'class="pdf-playground pdf-playground-indent"');
			}
			parts.push(html);
		});
	}
	
	// ── 그 외: 자식 재귀 ─────────────────────────────────
	// pb-* 가 아닌 wrapper 요소는 자식으로 내려감
	return _walkChildren(el, parts, loader);
}

/* ================================================================
 * callout 빌드
 * ================================================================ */
function _buildCallout(el) {
	var cls = el.className || '';
	var typeClass = 'pdf-callout';
	if (_hasClass(cls, 'callout-success')) typeClass += ' pdf-callout-success';
	if (_hasClass(cls, 'callout-info')) typeClass += ' pdf-callout-info';
	if (_hasClass(cls, 'callout-warning')) typeClass += ' pdf-callout-warning';
	if (_hasClass(cls, 'callout-danger')) typeClass += ' pdf-callout-danger';
	if (_hasClass(cls, 'indent')) typeClass += ' pdf-callout-indent';
	
	var html = '<div class="' + typeClass + '">';
	
	// 타이틀 (pb-title-h4)
	var titleEl = el.querySelector('.pb-title-h4');
	if (titleEl) {
		html += '<div class="pdf-callout-title">' + _extractInline(titleEl) + '</div>';
	}
	
	// 본문 — pb-p 단위 (callout 안 직접 자식)
	var paras = [].slice.call(el.querySelectorAll('.pb-p'));
	for (var i = 0; i < paras.length; i++) {
		html += '<p class="pdf-callout-p">' + _extractInline(paras[i]) + '</p>';
	}
	
	// pb-list (callout 안)
	var lists = [].slice.call(el.querySelectorAll('.pb-list'));
	for (var j = 0; j < lists.length; j++) {
		var lCls = 'pdf-list pdf-callout-list';
		var lClass = lists[j].className || '';
		if (_hasClass(lClass, 'decimal')) lCls += ' pdf-list-decimal';
		if (_hasClass(lClass, 'dash')) lCls += ' pdf-list-dash';
		if (_hasClass(lClass, 'indent')) lCls += ' pdf-list-indent';
		html += '<p class="' + lCls + '">' + _extractInline(lists[j]) + '</p>';
	}
	
	html += '</div>';
	return html;
}

/* ================================================================
 * table 빌드 — CSS Grid → <table>
 * ================================================================ */
function _buildTable(tableEl) {
	var content = tableEl.querySelector('.cl-layout-content');
	if (!content) return '';
	
	var cellEls = [].slice.call(content.querySelectorAll('.pb-th, .pb-td'));
	var cells = [];
	
	for (var c = 0; c < cellEls.length; c++) {
		var cell = cellEls[c];
		var styleAttr = cell.getAttribute('style') || '';
		var m = styleAttr.match(
			/grid-area:\s*(\d+)\s*\/\s*(\d+)\s*\/\s*span\s*(\d+)\s*\/\s*span\s*(\d+)/
		);
		if (!m) continue;
		
		cells.push({
			el: cell,
			rowStart: parseInt(m[1], 10),
			colStart: parseInt(m[2], 10),
			rowSpan: parseInt(m[3], 10),
			colSpan: parseInt(m[4], 10),
			isTh: _hasClass(cell.className, 'pb-th')
		});
	}
	
	if (!cells.length) return '';
	
	// 행 그룹핑
	var rows = {};
	for (var i = 0; i < cells.length; i++) {
		var key = cells[i].rowStart;
		if (!rows[key]) rows[key] = [];
		rows[key].push(cells[i]);
	}
	
	var rowKeys = Object.keys(rows).sort(function(a, b) {
		return parseInt(a, 10) - parseInt(b, 10);
	});
	
	var html = '<table class="pdf-table"><tbody>';
	for (var ri = 0; ri < rowKeys.length; ri++) {
		var rowCells = rows[rowKeys[ri]].sort(function(a, b) {
			return a.colStart - b.colStart;
		});
		html += '<tr>';
		for (var rci = 0; rci < rowCells.length; rci++) {
			var rc = rowCells[rci];
			var tag = rc.isTh ? 'th' : 'td';
			var attrs = '';
			if (rc.colSpan > 1) attrs += ' colspan="' + rc.colSpan + '"';
			if (rc.rowSpan > 1) attrs += ' rowspan="' + rc.rowSpan + '"';
			html += '<' + tag + attrs + '>' + _extractInline(rc.el) + '</' + tag + '>';
		}
		html += '</tr>';
	}
	html += '</tbody></table>';
	return html;
}

/* ================================================================
 * playground 빌드 (async)
 *   패턴 A: pb-playground-in 만
 *   패턴 B: pb-code 만
 *   패턴 C: pb-playground-in + pb-code 모두
 * ================================================================ */
function _buildPlayground(pgEl, loader) {
	var pgIn = pgEl.querySelector('.pb-playground-in');
	var pbCode = pgEl.querySelector('.pb-code');
	
	var chain = Promise.resolve('');
	var parts = [];
	
	// pb-playground-in 처리 (캡처)
	if (pgIn) {
		chain = chain.then(function() {
			_setLoaderStep(loader, 'capturing', '미리보기 이미지 캡처 중...');
			return _capturePlaygroundIn(pgIn, loader);
		}).then(function(imgHtml) {
			if (imgHtml) parts.push(imgHtml);
		});
	}
	
	// pb-code 처리 (텍스트 추출)
	if (pbCode) {
		chain = chain.then(function() {
			parts.push(_buildCode(pbCode));
		});
	}
	
	return chain.then(function() {
		if (!parts.length) return '';
		return '<div class="pdf-playground">' + parts.join('') + '</div>';
	});
}

/* ================================================================
 * pb-playground-in 캡처
 *   규칙:
 *   - cl-layout-wrap 직계의 첫 번째 cl-control 을 캡처 대상으로 수집
 *   - 단, 해당 cl-control 이 cl-container 인 경우:
 *       a. cl- 외 클래스 있음 → 해당 cl-container 전체를 캡처 (하위 탐색 없음)
 *       b. cl- 클래스만 있음 → cl-container 내부 첫 번째 cl-control 을 캡처
 *   - 캡처된 이미지를 flex + justify-content:center 로 가운데 정렬
 * ================================================================ */
function _capturePlaygroundIn(pgIn, loader) {
	if (!window.html2canvas) {
		return Promise.resolve('<div class="pdf-preview-fallback">미리보기 (html2canvas 미로드)</div>');
	}
	
	var layoutContent = pgIn.querySelector('.cl-layout > .cl-layout-content');
	var wraps = layoutContent
		? [].slice.call(layoutContent.children).filter(function(child) {
			return _hasClass(child.className || '', 'cl-layout-wrap');
		})
		: [];
	
	if (!wraps.length) return Promise.resolve('');
	
	// inline-block 레이아웃 여부 판별
	// cl-layout-wrap 중 하나라도 style 에 display:inline-block 이 있으면
	function _isInlineBlock() {
		for (var i = 0; i < wraps.length; i++) {
			var st = wraps[i].getAttribute('style') || '';
			if (st.indexOf('inline-block') !== -1) return true;
		}
		// cl-layout 의 white-space:normal 도 inline-block 레이아웃 신호
		var layout = pgIn.querySelector('.cl-layout');
		if (layout) {
			var lst = layout.getAttribute('style') || '';
			if (lst.indexOf('white-space: normal') !== -1
				|| lst.indexOf('white-space:normal') !== -1) return true;
		}
		return false;
	}
	
	// wrap 직계 첫 번째 cl-control 반환
	function _firstControl(wrap) {
		var children = [].slice.call(wrap.children);
		for (var i = 0; i < children.length; i++) {
			if (_hasClass(children[i].className || '', 'cl-control')) {
				return children[i];
			}
		}
		return null;
	}
	
	// ── inline-block 레이아웃: pb-playground-in 전체를 1개로 캡처 ──
	if (_isInlineBlock()) {
		_updateLoaderCapture(loader, 0, 1);
		return _captureElement(pgIn).then(function(url) {
			_updateLoaderCapture(loader, 1, 1);
			if (!url) return '';
			return '<div class="pdf-preview-wrap">'
				+ '<div class="pdf-preview-flex">'
				+ '<img src="' + url + '" class="pdf-preview-img" />'
				+ '</div></div>';
		});
	}
	
	// ── grid 레이아웃: wrap 당 cl-control 1개씩 캡처 ──
	var targets = [];
	for (var w = 0; w < wraps.length; w++) {
		var ctrl = _firstControl(wraps[w]);
		if (!ctrl) continue;
		// cl-container 이면 통째로, 아니면 직접
		targets.push(ctrl);
	}
	
	if (!targets.length) return Promise.resolve('');
	
	var imgPromises = [];
	var captureTotal = targets.length;
	for (var i = 0; i < captureTotal; i++) {
		(function(captureIdx) {
			imgPromises.push(
				_captureElement(targets[captureIdx]).then(function(url) {
					_updateLoaderCapture(loader, captureIdx + 1, captureTotal);
					return url;
				})
			);
		})(i);
	}
	
	return _promiseAll(imgPromises).then(function(dataUrls) {
		var validUrls = dataUrls.filter(function(u) { return !!u; });
		if (!validUrls.length) return '';
		
		var imgs = validUrls.map(function(url) {
			return '<img src="' + url + '" class="pdf-preview-img" />';
		}).join('');
		return '<div class="pdf-preview-wrap">'
			+ '<div class="pdf-preview-flex">' + imgs + '</div>'
			+ '</div>';
	});
}

function _captureElement(el) {
	// 캡처 가능 여부 사전 검증
	if (!el || !el.offsetWidth || !el.offsetHeight) {
		return Promise.resolve('');
	}
	
	var prevOverflow = el.style.overflow;
	el.style.overflow = 'visible';
	
	var result;
	try {
		result = window.html2canvas(el, {
			useCORS: true,
			allowTaint: true,
			scale: 1,
			backgroundColor: '#ffffff',
			logging: false,
			removeContainer: true,
			onclone: function(cloneDoc, cloneEl) {
				// (html2canvas 가 inherit 을 올바르게 계산하지 못하는 버그 대응)
				var all = [].slice.call(cloneEl.querySelectorAll('*'));
				for (var i = 0; i < all.length; i++) {
					var computed = window.getComputedStyle(all[i]);
					if (computed.display === 'table-cell') {
						var va = computed.verticalAlign;
						if (va === 'inherit' || va === '') {
							all[i].style.verticalAlign = 'middle';
						}
					}
				}
			}
		});
	}
	catch (e) {
		el.style.overflow = prevOverflow;
		console.warn('[pb-pdf] html2canvas 실행 오류:', e);
		return Promise.resolve('');
	}
	
	// html2canvas 가 undefined 반환하는 경우 방어
	if (!result || typeof result.then !== 'function') {
		el.style.overflow = prevOverflow;
		console.warn('[pb-pdf] html2canvas가 Promise를 반환하지 않음. el:', el);
		return Promise.resolve('');
	}
	
	return result.then(function(canvas) {
		el.style.overflow = prevOverflow;
		return canvas.toDataURL('image/png');
	}).catch(function(e) {
		el.style.overflow = prevOverflow;
		console.warn('[pb-pdf] 캡처 실패:', e);
		return '';
	});
}

/* ================================================================
 * pb-code 빌드 — 탭 레이블 + cm-line 텍스트 추출
 * ================================================================ */
function _buildCode(pbCodeEl) {
	// 탭 버튼 레이블 수집 (aria-label 우선)
	var tabBtns = [].slice.call(pbCodeEl.querySelectorAll('.pb-tab-btn'));
	var tabLabels = tabBtns.map(function(btn) {
		return btn.getAttribute('aria-label') || btn.textContent.trim();
	});
	
	// code.cm 요소 수집
	var codeCms = [].slice.call(pbCodeEl.querySelectorAll('.cl-uicontrolshell.code.cm'));
	if (!codeCms.length) {
		// fallback: cm-editor 직접
		codeCms = [].slice.call(pbCodeEl.querySelectorAll('.cm-editor'));
	}
	if (!codeCms.length) return '';
	
	// pb-code 안의 제목 요소 (pb-title-h2/h3/h4) 추출 — 텍스트로
	var headings = '';
	var h2s = [].slice.call(pbCodeEl.querySelectorAll('.pb-title-h2'));
	var h3s = [].slice.call(pbCodeEl.querySelectorAll('.pb-title-h3'));
	var h4s = [].slice.call(pbCodeEl.querySelectorAll('.pb-title-h4'));
	for (var hi = 0; hi < h2s.length; hi++) {
		headings += '<h2 class="pdf-h2">' + _extractInline(h2s[hi]) + '</h2>';
	}
	for (var hi = 0; hi < h3s.length; hi++) {
		headings += '<h3 class="pdf-h3">' + _extractInline(h3s[hi]) + '</h3>';
	}
	for (var hi = 0; hi < h4s.length; hi++) {
		headings += '<h4 class="pdf-h4">' + _extractInline(h4s[hi]) + '</h4>';
	}
	
	var html = headings + '<div class="pdf-code-section">';
	
	for (var i = 0; i < codeCms.length; i++) {
		var label = tabLabels[i] || ('코드 ' + (i + 1));
		var lang = (codeCms[i].querySelector('[data-language]') || {}).getAttribute
			? codeCms[i].querySelector('[data-language]').getAttribute('data-language') || ''
			: '';
		
		var lines = [].slice.call(codeCms[i].querySelectorAll('.cm-line'));
		var codeHtml = lines.map(function(line) {
			return _extractCodeLine(line);
		}).join('\n');
		
		html += '<div class="pdf-code-block">'
			+ '<div class="pdf-code-label pdf-code-label-' + _esc(lang) + '">' + _esc(label) + '</div>'
			+ '<pre class="pdf-code-pre">' + codeHtml + '</pre>'
			+ '</div>';
	}
	
	html += '</div>';
	return html;
}

/* ================================================================
 * CodeMirror cm-line → 색상 span HTML 변환
 *   getComputedStyle 로 실제 렌더링된 색상을 읽어 인라인 style 로 변환
 *   CodeMirror 클래스명(ͼh 등)은 인코딩 문제로 직접 매핑하지 않음
 * ================================================================ */
function _extractCodeLine(lineEl) {
	var result = [];
	var nodes = [].slice.call(lineEl.childNodes);
	
	for (var i = 0; i < nodes.length; i++) {
		var node = nodes[i];
		
		if (node.nodeType === 3) {
			// 텍스트 노드
			result.push(_esc(node.textContent));
			continue;
		}
		if (node.nodeType !== 1) continue;
		
		var text = _esc(node.textContent);
		var color = null;
		
		// getComputedStyle 로 실제 색상 읽기 (CodeMirror 가 CSS 로 주입한 색상)
		if (window.getComputedStyle) {
			try {
				var computed = window.getComputedStyle(node);
				var c = computed.color;
				// rgb(0, 0, 0) 은 기본값이므로 제외, 실제 색상만 적용
				if (c && c !== 'rgb(0, 0, 0)' && c !== 'rgba(0, 0, 0, 0)') {
					color = c;
				}
			}
			catch (e) { /* 무시 */ }
		}
		
		if (color) {
			result.push('<span style="color:' + color + '">' + text + '</span>');
		}
		else {
			result.push(text);
		}
	}
	
	return result.join('');
}

/* ================================================================
 * inline 텍스트 추출 — .cl-text 안의 span 스타일 보존
 * ================================================================ */
function _extractInline(el) {
	var src = el.querySelector('.cl-text') || el;
	return _walkInlineNodes(src.childNodes);
}

function _walkInlineNodes(nodes) {
	var result = [];
	for (var i = 0; i < nodes.length; i++) {
		var node = nodes[i];
		
		// 텍스트 노드
		if (node.nodeType === 3) {
			result.push(_esc(node.textContent));
			continue;
		}
		
		if (node.nodeType !== 1) continue;
		
		var tag = (node.tagName || '').toLowerCase();
		var cls = node.className || '';
		
		if (tag === 'br') {
			result.push('<br>');
			continue;
		}
		
		// pb-point
		if (_hasClass(cls, 'pb-point') || _hasClass(cls, 'point')) {
			result.push('<span class="pdf-point">' + _esc(node.textContent) + '</span>');
			continue;
		}
		
		// pb-code (inline 코드) — 배경색 인라인 스타일 강제 적용
		if (_hasClass(cls, 'pb-code') || _hasClass(cls, 'code')) {
			result.push(
				'<code class="pdf-code-inline" style="'
				+ 'background:rgba(169,32,39,0.08);'
				+ 'color:#a92027;'
				+ 'font-family:Consolas,Monaco,monospace;'
				+ 'font-size:0.9em;'
				+ 'border-radius:3px;'
				+ 'padding:1px 4px;'
				+ 'display:inline;">'
				+ _esc(node.textContent)
				+ '</code>'
			);
			continue;
		}
		
		// strong
		if (_hasClass(cls, 'strong')) {
			result.push('<strong>' + _esc(node.textContent) + '</strong>');
			continue;
		}
		
		// prop (속성명 — 파란색)
		if (_hasClass(cls, 'prop')) {
			result.push('<span class="pdf-prop">' + _esc(node.textContent) + '</span>');
			continue;
		}
		
		// type (타입 — 파란색)
		if (_hasClass(cls, 'type')) {
			result.push('<span class="pdf-type">' + _esc(node.textContent) + '</span>');
			continue;
		}
		
		// em
		if (_hasClass(cls, 'em')) {
			result.push('<em class="pdf-em">' + _esc(node.textContent) + '</em>');
			continue;
		}
		
		// underline
		if (_hasClass(cls, 'underline')) {
			result.push('<span class="pdf-underline">' + _esc(node.textContent) + '</span>');
			continue;
		}
		
		// cl-sound-only (스크린리더 전용 텍스트 — 제외)
		if (_hasClass(cls, 'cl-sound-only')) {
			continue;
		}
		
		// 그 외: 재귀
		result.push(_walkInlineNodes(node.childNodes));
	}
	return result.join('');
}

/* ================================================================
 * print-root 생성
 * ================================================================ */
function _buildPrintRoot(sectionsHtml) {
	var old = document.getElementById('pb-print-root');
	if (old && old.parentNode) old.parentNode.removeChild(old);
	
	var root = document.createElement('div');
	root.id = 'pb-print-root';
	root.innerHTML = sectionsHtml.join('');
	// visibility:hidden + position:fixed 로 화면에 보이지 않게 유지
	// display:none 은 @media print 에서 레이아웃 계산이 안 되므로 사용하지 않음
	root.style.cssText = 'visibility:hidden;position:fixed;top:0;left:0;width:100%;z-index:-1;';
	document.body.appendChild(root);
	return root;
}

/* ================================================================
 * body 원본 요소 숨김 / 복원
 * ================================================================ */
function _hideBodySiblings(printRoot) {
	var children = [].slice.call(document.body.children);
	var hidden = [];
	for (var i = 0; i < children.length; i++) {
		if (children[i] !== printRoot) {
			hidden.push({ el: children[i], display: children[i].style.display });
			children[i].style.display = 'none';
		}
	}
	return hidden;
}

function _restoreBodySiblings(hidden) {
	for (var i = 0; i < hidden.length; i++) {
		hidden[i].el.style.display = hidden[i].display;
	}
}

function _cleanup(printRoot, hidden) {
	_restoreBodySiblings(hidden);
	if (printRoot && printRoot.parentNode) {
		printRoot.parentNode.removeChild(printRoot);
	}
}

/* ================================================================
 * 출력 — window.print()
 * ================================================================ */
function _exportPrint(printRoot, hidden) {
	// visibility:visible 로만 전환 (화면에는 fixed+z-index:-1 로 보이지 않음)
	printRoot.style.visibility = 'visible';
	
	function onAfterPrint() {
		_cleanup(printRoot, hidden);
		if (window.removeEventListener) {
			window.removeEventListener('afterprint', onAfterPrint);
		}
		else if (window.detachEvent) {
			window.detachEvent('onafterprint', onAfterPrint);
		}
	}
	
	if (window.addEventListener) {
		window.addEventListener('afterprint', onAfterPrint);
	}
	else if (window.attachEvent) {
		window.attachEvent('onafterprint', onAfterPrint);
	}
	
	setTimeout(function() {
		window.print();
	}, 120);
}

/* ================================================================
 * 출력 — jsPDF (output:'pdf' 옵션)
 * ================================================================ */
function _exportPdf(printRoot, cfg, onDone) {
	var jsPDFCtor = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
	if (!jsPDFCtor) {
		console.warn('[pb-pdf] jsPDF 미로드 — window.print() 으로 대체합니다.');
		_exportPrint(printRoot, []);
		return;
	}
	
	printRoot.style.display = 'block';
	
	var pdf = new jsPDFCtor({ orientation: 'portrait', unit: 'mm', format: 'a4' });
	var pageW = pdf.internal.pageSize.getWidth();
	var pageH = pdf.internal.pageSize.getHeight();
	var margin = cfg.pageMarginMm;
	var contentW = pageW - margin * 2;
	var contentH = pageH - margin * 2;
	
	html2canvas(printRoot, {
		scale: 1,
		useCORS: true,
		allowTaint: true,
		logging: false,
		backgroundColor: '#ffffff'
	}).then(function(canvas) {
		var pxPerMm = canvas.width / contentW;
		var pageHpx = Math.floor(contentH * pxPerMm);
		var totalH = canvas.height;
		var slice = document.createElement('canvas');
		slice.width = canvas.width;
		var ctx = slice.getContext('2d');
		var offsetY = 0;
		var pageIdx = 0;
		
		while (offsetY < totalH) {
			var sliceH = Math.min(pageHpx, totalH - offsetY);
			if (sliceH <= 0) break;
			
			slice.height = sliceH;
			ctx.clearRect(0, 0, slice.width, sliceH);
			ctx.drawImage(canvas, 0, offsetY, canvas.width, sliceH, 0, 0, canvas.width, sliceH);
			
			var imgData = slice.toDataURL('image/jpeg', 0.92);
			var aspect = sliceH / canvas.width;
			var imgW = contentW;
			var imgH = imgW * aspect;
			
			if (pageIdx > 0) pdf.addPage();
			pdf.addImage(imgData, 'JPEG', margin, margin, imgW, imgH);
			
			offsetY += sliceH;
			pageIdx++;
		}
		
		pdf.save(cfg.filename);
		printRoot.style.display = 'none';
		onDone();
	}).catch(function(err) {
		console.error('[pb-pdf] PDF 생성 오류:', err);
		printRoot.style.display = 'none';
		onDone();
	});
}

/* ================================================================
 * 스타일 주입 (IE11 호환)
 * ================================================================ */
function _injectStyles() {
	var styleId = 'pb-pdf-styles-v4';
	if (document.getElementById(styleId)) return;
	
	var styleEl = document.createElement('style');
	styleEl.id = styleId;
	styleEl.type = 'text/css';
	
	var css = [
		/* ── 로딩 오버레이 (화면 표시용, @media print 제외) ── */
		
		/* ── 로딩 오버레이 ── */
		'#pb-pdf-loader {',
		'  position: fixed; inset: 0;',
		'  background: rgba(0,0,0,0.55);',
		'  z-index: 999999;',
		'  display: flex; align-items: center; justify-content: center;',
		'}',
		'#pb-pdf-loader-card {',
		'  background: #fff;',
		'  border-radius: 12px;',
		'  padding: 32px 40px;',
		'  min-width: 260px;',
		'  text-align: center;',
		'  box-shadow: 0 8px 40px rgba(0,0,0,0.22);',
		'  font-family: -apple-system, "Apple SD Gothic Neo", sans-serif;',
		'}',
		'#pb-pdf-spinner {',
		'  width: 36px; height: 36px;',
		'  border: 3px solid #e6e8ea;',
		'  border-top-color: #1e2124;',
		'  border-radius: 50%;',
		'  animation: pb-pdf-spin 0.8s linear infinite;',
		'  margin: 0 auto 16px;',
		'}',
		'@keyframes pb-pdf-spin { to { transform: rotate(360deg); } }',
		'#pb-pdf-step {',
		'  font-size: 14px; font-weight: 600;',
		'  color: #1e2124; margin-bottom: 6px;',
		'}',
		'#pb-pdf-detail {',
		'  font-size: 12px; color: #6d7882;',
		'  min-height: 18px;',
		'}',
		
		/* ── @media print 기본 ── */
		'@media print {',
		'  @page { size: A4 portrait; margin: 15mm 14mm; }',
		
		/* print-root 만 표시 */
		'  #pb-print-root {',
		'    display: block !important;',
		'    visibility: visible !important;',
		'    position: static !important;',
		'    z-index: auto !important;',
		'  }',
		'  #pb-pdf-loader { display: none !important; }',
		
		/* 섹션 분리 */
		'  .pdf-section { break-before: page; page-break-before: always; }',
		'  .pdf-section-first { break-before: auto; page-break-before: auto; }',
		
		/* 요소 중간 잘림 방지 */
		'  .pdf-callout, .pdf-table, .pdf-code-section, .pdf-preview-wrap { break-inside: avoid; page-break-inside: avoid; }',
		'  h1, h2, h3, h4 { break-after: avoid; page-break-after: avoid; }',
		
		/* ── 타이포그래피 (24px 기준, pt 환산) ── */
		'  .pdf-h1 {',
		'    font-size: 18pt; font-weight: 700; color: #131416;',
		'    border-bottom: 1.5pt solid #1e2124;',
		'    padding-bottom: 6pt; margin: 0 0 8pt;',
		'  }',
		'  .pdf-subtitle {',
		'    font-size: 11pt; color: #464c53;',
		'    margin: 0 0 10pt; line-height: 1.6;',
		'  }',
		'  .pdf-h2 {',
		'    font-size: 14pt; font-weight: 500; color: #1e2124;',
		'    border-bottom: 0.5pt solid #e6e8ea;',
		'    padding-bottom: 3pt; margin: 18pt 0 8pt;',
		'  }',
		'  .pdf-h3 {',
		'    font-size: 11pt; font-weight: 500; color: #1e2124;',
		'    margin: 10pt 0 5pt;',
		'  }',
		'  .pdf-h4 {',
		'    font-size: 10pt; font-weight: 500; color: #1e2124;',
		'    margin: 7pt 0 4pt;',
		'  }',
		'  .pdf-p {',
		'    font-size: 10pt; color: #33363d;',
		'    margin: 0 0 6pt; line-height: 1.65;',
		'  }',
		
		/* ── 리스트 ── */
		'  .pdf-list {',
		'    font-size: 10pt; color: #33363d;',
		'    margin: 0 0 4pt; line-height: 1.65;',
		'    display: flex; align-items: baseline; gap: 5pt;',
		'  }',
		'  .pdf-list-bullet {',
		'    flex-shrink: 0; min-width: 10pt;',
		'    color: #33363d;',
		'  }',
		'  .pdf-list-text { flex: 1; word-break: break-word; }',
		'  .pdf-list-indent { padding-left: 20pt; }',
		'  .pdf-list-order .pdf-list-bullet { color: #33363d; }',
		
		/* ── inline 스타일 ── */
		'  .pdf-point {',
		'    color: #a92027;',
		'    text-decoration: underline;',
		'    text-decoration-color: rgba(169,32,39,0.3);',
		'    text-underline-offset: 2pt;',
		'  }',
		'  .pdf-code-inline {',
		'    font-family: Consolas, Monaco, monospace;',
		'    font-size: 9pt;',
		'    background: rgba(169,32,39,0.08) !important;',
		'    -webkit-print-color-adjust: exact;',
		'    print-color-adjust: exact;',
		'    color: #a92027 !important;',
		'    border-radius: 3pt;',
		'    padding: 1pt 4pt;',
		'    display: inline;',
		'  }',
		'  .pdf-prop { color: #052561; font-family: Consolas, Monaco, monospace; font-size: 9pt; }',
		'  .pdf-type { color: #0b50d0; font-family: Consolas, Monaco, monospace; font-size: 9pt; }',
		'  .pdf-em   { color: #a92027; }',
		'  .pdf-underline { text-decoration: underline; }',
		
		/* ── callout ── */
		'  .pdf-callout {',
		'    border: 0.5pt solid #cdd1d5;',
		'    border-radius: 6pt;',
		'    background: #f4f5f6;',
		'    padding: 8pt 10pt;',
		'    margin: 6pt 0;',
		'  }',
		'  .pdf-callout-info    { background: #e7f4fe; border-color: #9ed2fa; }',
		'  .pdf-callout-success { background: #eaf6ec; border-color: #a9dab4; }',
		'  .pdf-callout-warning { background: #fff3db; border-color: #ffc95c; }',
		'  .pdf-callout-danger  { background: #fdefec; border-color: #f7afa1; }',
		'  .pdf-callout-indent  { margin-left: 20pt; }',
		'  .pdf-callout-title {',
		'    font-size: 10pt; font-weight: 500;',
		'    color: #1e2124;',
		'    padding-left: 14pt;',
		'    position: relative;',
		'    margin-bottom: 4pt;',
		'  }',
		'  .pdf-callout-title::before {',
		'    content: "!";',
		'    position: absolute; left: 0; top: 1pt;',
		'    width: 11pt; height: 11pt;',
		'    border: 1pt solid #464c53; border-radius: 50%;',
		'    font-size: 8pt; font-weight: 500;',
		'    display: flex; align-items: center; justify-content: center;',
		'  }',
		'  .pdf-callout-info    .pdf-callout-title { color: #0b78cb; }',
		'  .pdf-callout-info    .pdf-callout-title::before { border-color: #0b78cb; }',
		'  .pdf-callout-success .pdf-callout-title { color: #267337; }',
		'  .pdf-callout-success .pdf-callout-title::before { border-color: #228738; }',
		'  .pdf-callout-warning .pdf-callout-title { color: #8a5c00; }',
		'  .pdf-callout-warning .pdf-callout-title::before { border-color: #9e6a00; }',
		'  .pdf-callout-danger  .pdf-callout-title { color: #bd2c0f; }',
		'  .pdf-callout-danger  .pdf-callout-title::before { border-color: #de3412; }',
		'  .pdf-callout-p { font-size: 9pt; color: #33363d; margin: 0 0 3pt; }',
		'  .pdf-callout-list { font-size: 9pt; }',
		
		/* ── 테이블 ── */
		'  .pdf-table {',
		'    width: 100%; border-collapse: collapse;',
		'    margin: 6pt 0 12pt;',
		'    font-size: 9pt;',
		'    border: 0.5pt solid #e6e8ea;',
		'    border-radius: 6pt;',
		'  }',
		'  .pdf-table th {',
		'    background: #e6e8ea !important;',
		'    -webkit-print-color-adjust: exact;',
		'    print-color-adjust: exact;',
		'    color: #1e2124 !important;',
		'    font-size: 9.5pt; font-weight: 600;',
		'    padding: 5pt 8pt;',
		'    border-bottom: 0.5pt solid #cdd1d5;',
		'    border-right: 0.5pt solid #cdd1d5;',
		'    text-align: left; vertical-align: middle;',
		'  }',
		'  .pdf-table th:last-child { border-right: none; }',
		'  .pdf-table td {',
		'    color: #33363d;',
		'    padding: 5pt 8pt;',
		'    border-bottom: 0.5pt solid #e6e8ea;',
		'    border-right: 0.5pt solid #e6e8ea;',
		'    vertical-align: top;',
		'  }',
		'  .pdf-table td:last-child { border-right: none; }',
		'  .pdf-table tr:last-child td,',
		'  .pdf-table tr:last-child th { border-bottom: none; }',
		
		/* ── 코드블록 ── */
		'  .pdf-code-section { margin: 6pt 0 10pt; }',
		'  .pdf-code-block {',
		'    border: 0.5pt solid #e6e8ea;',
		'    border-radius: 5pt;',
		'    overflow: hidden;',
		'    margin-bottom: 4pt;',
		'    break-inside: avoid; page-break-inside: avoid;',
		'  }',
		'  .pdf-code-label {',
		'    display: block;',
		'    font-family: -apple-system, sans-serif;',
		'    font-size: 8pt; font-weight: 600;',
		'    color: #1e2124;',
		'    background: #e6e8ea !important;',
		'    -webkit-print-color-adjust: exact;',
		'    print-color-adjust: exact;',
		'    padding: 4pt 8pt;',
		'    border-bottom: 0.5pt solid #cdd1d5;',
		'  }',
		'  .pdf-code-pre {',
		'    font-family: Consolas, "D2Coding", "Courier New", monospace;',
		'    font-size: 8pt; line-height: 1.5;',
		'    color: #1e2124;',
		'    background: #fafafa;',
		'    margin: 0; padding: 7pt 10pt;',
		'    white-space: pre-wrap;',
		'    word-break: break-all;',
		'  }',
		
		/* ── playground 미리보기 ── */
		'  .pdf-playground { margin: 6pt 0 10pt; }',
		'  .pdf-playground-indent { margin-left: 20pt; }',
		
		'  .pdf-preview-wrap {',
		'    border: 0.5pt solid #e6e8ea;',
		'    border-radius: 6pt;',
		'    padding: 12pt;',
		'    background: #ffffff;',
		'    break-inside: avoid; page-break-inside: avoid;',
		'  }',
		'  .pdf-preview-flex { display: flex; gap: 8pt; flex-wrap: wrap; align-items: flex-start; justify-content: center; }',
		'  .pdf-preview-img { max-width: 100%; height: auto; display: block; }',
		'  .pdf-preview-img-multi { max-width: 48%; }',
		'  .pdf-preview-fallback {',
		'    font-size: 9pt; color: #888;',
		'    padding: 10pt; background: #f8f8f8;',
		'    border-radius: 4pt;',
		'  }',
		'}'
	].join('\n');
	
	if (styleEl.styleSheet) {
		styleEl.styleSheet.cssText = css;
	}
	else {
		styleEl.appendChild(document.createTextNode(css));
	}
	
	var head = document.head || document.getElementsByTagName('head')[0];
	head.appendChild(styleEl);
}

/* ================================================================
 * 유틸
 * ================================================================ */
function _hasClass(cls, name) {
	return (' ' + cls + ' ').indexOf(' ' + name + ' ') !== -1;
}

function _esc(str) {
	return String(str || '')
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;');
}

function _merge(a, b) {
	var r = {},
		k;
	for (k in a) { if (a.hasOwnProperty(k)) r[k] = a[k]; }
	for (k in b) { if (b.hasOwnProperty(k)) r[k] = b[k]; }
	return r;
}

// Promise.all ES5 대체 (순서 보장)
function _promiseAll(promises) {
	var results = new Array(promises.length);
	var chain = Promise.resolve();
	
	for (var i = 0; i < promises.length; i++) {
		(function(idx) {
			chain = chain.then(function() {
				return promises[idx];
			}).then(function(val) {
				results[idx] = val;
			});
		})(i);
	}
	
	return chain.then(function() { return results; });
}