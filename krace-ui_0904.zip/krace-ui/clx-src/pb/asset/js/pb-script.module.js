/************************************************
 * @file      pb-script.module.js
 * @desc      상세 역할을 기술하세요
 * @author    ryu
 * @created   2026. 4. 6. 오후 3:40:39
 * * [Dependencies]
 * - 파일경로 (역할)
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/

/**
 * 가이드 페이지 공통 스크립트 추가
 */


// ─── 유틸리티 함수 ───

/**
 * children 중 type과 className이 일치하는 요소를 필터링
 * @param {cpr.controls.UIControl[]} children
 * @param {String} type
 * @param {#css-class} className
 * @returns {cpr.controls.UIControl[]}
 */
function filterByTypeAndClass(children, type, className) {
	return children.filter(function(each) {
		return each.type === type && each.style.hasClass(className);
	});
}

/**
 * 여러 배열/값을 하나의 배열로 합치면서 null/undefined 제거
 * @returns {Array}
 */
function mergeExtensions() {
	var result = [];
	for (var i = 0; i < arguments.length; i++) {
		var item = arguments[i];
		if (item == null) continue;
		if (Array.isArray(item)) {
			for (var j = 0; j < item.length; j++) {
				if (item[j] != null) {
					result.push(item[j]);
				}
			}
		}
		else {
			result.push(item);
		}
	}
	return result;
}

// ─── 언어별 매핑 테이블 ───

var LANG_CONFIG = {
	"javascript": { beautify: "js", lang: "javascript" },
	"js": { beautify: "js", lang: "javascript" },
	"json": { beautify: "js", lang: "json" },
	"html": { beautify: "html", lang: "html" },
	"xml": { beautify: "html", lang: "xml" },
	"css": { beautify: "css", lang: "css" },
	"less": { beautify: "css", lang: "less" },
	"java": { beautify: "js", lang: "java" },
	"markdown": { beautify: null, lang: "markdown" }
};

// ─── 코드블록 포맷팅 ───

var BEAUTIFY_OPTIONS = {
	indent_size: 2,
	indent_char: " ",
	max_preserve_newlines: 2,
	preserve_newlines: true,
	keep_array_indentation: false,
	break_chained_methods: false,
	end_with_newline: false
};

/**
 * 언어 타입에 따라 코드를 포맷팅하고 언어 확장을 반환
 * @param {string} rawCode
 * @param {string} langType
 * @returns {{ formatted: string, langExtension: * }}
 */
function formatCode(rawCode, langType) {
	var config = LANG_CONFIG[langType];
	
	if (!config) {
		return { formatted: rawCode, langExtension: null };
	}
	
	var formatted = rawCode;
	var langExtension = null;
	
	try {
		if (config.beautify && CM.beautify[config.beautify]) {
			formatted = CM.beautify[config.beautify](rawCode, BEAUTIFY_OPTIONS);
		}
		if (config.lang && CM.langs[config.lang]) {
			langExtension = CM.langs[config.lang]();
		}
	}
	catch (e) {
		formatted = rawCode;
	}
	
	return { formatted: formatted, langExtension: langExtension };
}

/**
 * EditorView에 사용할 확장 배열 조립
 * @param {*} langExtension
 * @returns {Array}
 */
function buildExtensions(langExtension) {
	var base = (CM.baseExtensions || []);
	var theme = (CM.themes && CM.themes.tokyo) ? CM.themes.tokyo : [];
	return mergeExtensions(base, langExtension, theme);
}

// ─── 코드블록 로드 핸들러 ───

/**
 * 개별 코드블록(uicontrolshell.cm)의 load 이벤트 처리
 * @param {cpr.controls.UIControlShell} block
 */
function initCodeBlock(block) {
	block.addEventListener("load", function(e) {
		var content = e.content;
		var rawCode = block.userAttr("cm-doc") || "";
		var langType = (block.userAttr("cm-lang") || "js").toLowerCase();
		
		var result = formatCode(rawCode, langType);
		var extensions = buildExtensions(result.langExtension);
		
		var view = new CM.EditorView({
			doc: result.formatted,
			extensions: extensions,
			parent: content
		});
		
		block._code = view;
	});
}

// ─── .pb-code 컨테이너 초기화 ───

/**
 * 복사 버튼에 클릭 이벤트 바인딩
 * @param {cpr.controls.Container} toolbar
 * @param {cpr.controls.Container} codeWrap
 */
function bindCopyButton(toolbar, codeWrap) {
	filterByTypeAndClass(toolbar.getAllRecursiveChildren(false), "button", "pb-copy-btn")
		.forEach(function(button) {
			button.addEventListener("click", function() {
				var targets = codeWrap.getChildren().filter(function(each) {
					return each.visible;
				});
				if (targets.length > 0 && targets[0]._code) {
					// 코드 미러 번들 내 선언한 함수 호출
					CM.copyToClipboard(targets[0]._code);
				}
			});
		});
}

/**
 * 탭 리스트 전환 로직 바인딩
 * @param {cpr.controls.Container} toolbar
 * @param {cpr.controls.Container} codeWrap
 */
function bindTabSwitch(toolbar, codeWrap) {
	var tablist = toolbar.getFirstChild();
	tablist.getChildren().forEach(function(/* cpr.controls.Button */ button) {
		button.bind("fieldLabel").toExpression("value");
		button.addEventListener("click", function(e) {
			var target = e.control;
			var targetIndex = tablist.getChildren().indexOf(target);
			
			tablist.getChildren().forEach(function(btn, idx) {
				var codeblock = codeWrap.getChildren()[idx];
				if (idx === targetIndex) {
					btn.style.addClass("active");
					if (codeblock) codeblock.visible = true;
				}
				else {
					btn.style.removeClass("active");
					if (codeblock) codeblock.visible = false;
				}
			});
		});
	});
	
	var firstTab = tablist.getFirstChild();
	if (firstTab) firstTab.click();
}

/**
 * .pb-code 컨테이너 하나를 초기화 (오버레이, 복사, 탭)
 * @param {cpr.controls.Container} wrap
 */
function initCodeContainer(wrap) {
	if (wrap.getParent().getLastChild() !== wrap) {
		wrap.style.addClass("has-overlay");
	}
	
	var toolbar = wrap.getFirstChild();
	var codeWrap = wrap.getLastChild();
	
	bindCopyButton(toolbar, codeWrap);
	bindTabSwitch(toolbar, codeWrap);
}

// ─── 코드 토글 버튼 ───

/**
 * .pb-codeblock-btn 버튼 하나에 토글 로직 바인딩
 * @param {cpr.controls.Button} button
 */
function initToggleButton(button) {
	button.bind("value").toExpression("this.style.hasClass('active') ? '코드 숨기기' : '코드 보기'");
	button.addEventListener("click", function(e) {
		var target = e.control;
		var siblings = button.getParent().getChildren();
		// 코드 래퍼는 마지막에서 두 번째 자식
		var codeWrap = siblings[siblings.length - 2];
		
		if (!target.style.hasClass("active")) {
			target.style.addClass("active");
			codeWrap.style.removeClass("has-overlay");
		}
		else {
			target.style.removeClass("active");
			codeWrap.style.addClass("has-overlay");
		}
	});
}

// ─── 메인 진입점 ───

cpr.events.EventBus.INSTANCE.addFilter("init", function(e) {
	var control = e.control;
	if (!(control instanceof cpr.core.AppInstance)) return;
	
	/** @type cpr.core.AppInstance */
	var appInstance = control;
	var container = appInstance.getContainer();
	if (!container.style.hasClass("pb-guide-page")) return;
	
	var allChildren = container.getAllRecursiveChildren(false);
	
	// IE11 판별: CM 로드 없이 코드블록 숨김
	var isIE = (navigator.userAgent.indexOf("Trident") > -1);
	if (isIE) {
		filterByTypeAndClass(allChildren, "container", "pb-code").forEach(function(wrap) {
			wrap.visible = false;
		});
		filterByTypeAndClass(allChildren, "button", "pb-codeblock-btn").forEach(function(btn) {
			btn.visible = false;
		});
		return;
	}
	
	// 코드미러 로드 및 코드블록 초기화
	cpr.core.ResourceLoader.loadScript("pb/asset/js/cm-bundle.js").then(function() {
		filterByTypeAndClass(
			container.getAllRecursiveChildren(false), "uicontrolshell", "cm"
		).forEach(initCodeBlock);
	}).then(function() {
		container.redraw();
	});
	
	// .pb-code 컨테이너 초기화
	filterByTypeAndClass(allChildren, "container", "pb-code").forEach(initCodeContainer);
	
	// 토글 버튼 초기화
	filterByTypeAndClass(allChildren, "button", "pb-codeblock-btn").forEach(initToggleButton);
});