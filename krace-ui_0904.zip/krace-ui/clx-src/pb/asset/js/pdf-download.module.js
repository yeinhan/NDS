/************************************************
 * @file      pdf-download.module.js
 * @desc      클라이언트 사이드 PDF 다운로드 모듈 (ES5 호환)
 * @author    ryu
 * @created   2026. 4. 16. 오후 3:33:42
 * * [Dependencies]
 * - clx-src/pb/asset/js/html2canvas.min.js
 * - clx-src/pb/asset/js/jspdf.umd.min.js
 * * [History]
 * - 2026. 4. 16. : 최초 생성 (ryu)
 ************************************************/
/**
 * pdfDownload.js  v3.0
 * 클라이언트 사이드 PDF 다운로드 모듈 (ES5 호환)
 *
 * 변경 이력:
 *   v3.0 - 코드블럭 복수 탭 전체 처리 / pb-page-title 기준 페이지 분리 /
 *           pb-playground 캡처 / pb-callout 처리 / KRDS 색상 적용
 *   v2.0 - DOM 클론 → 텍스트 추출 재조립 방식 / 인라인 스타일 주입
 *   v1.0 - 초기 구현
 *
 * 의존성 (로컬 파일로 포함 필요):
 *   lib/html2canvas.min.js  (v1.4.1+)
 *   lib/jspdf.umd.min.js    (v2.5.1+)
 */

//var PdfDownload = (function() {
//	'use strict';
//	
//	/* ================================================================
//	 * 1. 설정
//	 * ================================================================ */
//	var DEFAULT_CONFIG = {
//		contentTargetAttr: 'guide-content', // data-usr-pdf-target 속성값
//		filename: 'guide.pdf',
//		pageMarginMm: 10,
//		scale: 1, // 1 고정 (width 깨짐 방지)
//		pageFormat: 'a4',
//		popupId: 'pdf-preview-popup',
//		overlayId: 'pdf-preview-overlay'
//	};
//	
//	/* KRDS 토큰 기반 색상 상수 */
//	var C = {
//		primary5: '#ecf2fe',
//		primary10: '#d8e5fd',
//		primary50: '#256ef4',
//		primary60: '#0b50d0',
//		gray0: '#ffffff',
//		gray5: '#f4f5f6',
//		gray10: '#e6e8ea',
//		gray20: '#cdd1d5',
//		gray50: '#6d7882',
//		gray70: '#464c53',
//		gray80: '#33363d',
//		gray90: '#1e2124',
//		success10: '#d8eedd',
//		success70: '#285d33',
//		warning10: '#ffe0a3',
//		warning70: '#614100',
//		danger10: '#fcdfd9',
//		danger60: '#bd2c0f',
//		info10: '#d3ebfd',
//		info60: '#096ab3'
//	};
//	
//	var _cfg = DEFAULT_CONFIG;
//	
//	/* ================================================================
//	 * 2. 공개 API
//	 * ================================================================ */
//	function init(userConfig) {
//		_cfg = _merge(DEFAULT_CONFIG, userConfig || {});
//	}
//	
//	function start() {
//		if (!_checkDeps()) { return; }
//		
//		var sourceEl = document.querySelector('[data-usr-pdf-target="' + _cfg.contentTargetAttr + '"]')
//			|| document.getElementById(_cfg.contentTargetAttr);
//		
//		if (!sourceEl) {
//			_log('콘텐츠 영역을 찾을 수 없습니다: ' + _cfg.contentTargetAttr, 'error');
//			return;
//		}
//		_showPopup(sourceEl);
//	}
//	
//	/* ================================================================
//	 * 3. 팝업 UI
//	 * ================================================================ */
//	function _showPopup(sourceEl) {
//		_removePopup();
//		_injectStyles();
//		
//		var overlay = _el('div', { id: _cfg.overlayId });
//		_css(overlay, {
//			position: 'fixed',
//			top: '0',
//			left: '0',
//			width: '100%',
//			height: '100%',
//			background: 'rgba(0,0,0,0.65)',
//			zIndex: '99998',
//			display: 'flex',
//			alignItems: 'center',
//			justifyContent: 'center'
//		});
//		
//		var popup = _el('div', { id: _cfg.popupId });
//		_css(popup, {
//			position: 'relative',
//			background: C.gray0,
//			borderRadius: '8px',
//			boxShadow: '0 8px 40px rgba(0,0,0,0.35)',
//			width: '92vw',
//			maxWidth: '960px',
//			maxHeight: '88vh',
//			overflow: 'hidden',
//			display: 'flex',
//			flexDirection: 'column',
//			zIndex: '99999'
//		});
//		
//		var header = _buildHeader();
//		var statusObj = _buildStatusBar('콘텐츠 변환 중...');
//		var scrollArea = _el('div');
//		_css(scrollArea, { overflowY: 'auto', flex: '1', padding: '24px', background: '#e8e8e8' });
//		
//		var printEl = _el('div', { id: 'pdf-print-area' });
//		_css(printEl, {
//			background: C.gray0,
//			width: '100%',
//			boxSizing: 'border-box',
//			padding: '40px 48px',
//			boxShadow: '0 2px 16px rgba(0,0,0,0.15)'
//		});
//		
//		var footerObj = _buildFooter(function() {
//			statusObj.setText('PDF 생성 중...');
//			_generatePdf(printEl);
//		});
//		
//		scrollArea.appendChild(printEl);
//		popup.appendChild(header);
//		popup.appendChild(statusObj.el);
//		popup.appendChild(scrollArea);
//		popup.appendChild(footerObj.el);
//		overlay.appendChild(popup);
//		document.body.appendChild(overlay);
//		
//		header.querySelector('.pdf-close-btn').addEventListener('click', _removePopup);
//		overlay.addEventListener('click', function(e) {
//			if (e.target === overlay) { _removePopup(); }
//		});
//		
//		/* 콘텐츠 구성 → playground 캡처 → 버튼 활성화 */
//		_buildPrintContent(sourceEl, printEl, function() {
//			statusObj.hide(); /* 상태바 숨김 */
//			footerObj.enablePrint();
//		});
//	}
//	
//	function _buildHeader() {
//		var header = _el('div');
//		_css(header, {
//			display: 'flex',
//			alignItems: 'center',
//			justifyContent: 'space-between',
//			padding: '14px 20px',
//			borderBottom: '1px solid ' + C.gray10,
//			background: C.gray0,
//			flexShrink: '0'
//		});
//		var title = _el('span');
//		title.textContent = '📄 PDF 미리보기';
//		_css(title, { fontSize: '14px', fontWeight: '600', color: C.gray90 });
//		
//		var btn = _el('button', { className: 'pdf-close-btn' });
//		btn.innerHTML = '&times;';
//		_css(btn, {
//			background: 'none',
//			border: 'none',
//			cursor: 'pointer',
//			fontSize: '22px',
//			color: C.gray50,
//			padding: '0 2px',
//			lineHeight: '1'
//		});
//		header.appendChild(title);
//		header.appendChild(btn);
//		return header;
//	}
//	
//	function _buildStatusBar(text) {
//		var bar = _el('div');
//		_css(bar, {
//			padding: '9px 20px',
//			background: C.primary5,
//			borderBottom: '1px solid ' + C.primary10,
//			fontSize: '13px',
//			color: C.primary60,
//			display: 'flex',
//			alignItems: 'center',
//			gap: '8px',
//			flexShrink: '0'
//		});
//		var spinner = _el('span');
//		_css(spinner, {
//			display: 'inline-block',
//			width: '13px',
//			height: '13px',
//			border: '2px solid ' + C.primary10,
//			borderTopColor: C.primary60,
//			borderRadius: '50%',
//			animation: 'pdf-spin 0.8s linear infinite'
//		});
//		var textEl = _el('span');
//		textEl.textContent = text;
//		bar.appendChild(spinner);
//		bar.appendChild(textEl);
//		return {
//			el: bar,
//			setText: function(t) { textEl.textContent = t; },
//			hide: function() { bar.style.display = 'none'; } /* ★ 추가 */
//		};
//	}
//	
//	function _buildFooter(onPrint) {
//		var footer = _el('div');
//		_css(footer, {
//			display: 'flex',
//			alignItems: 'center',
//			justifyContent: 'flex-end',
//			gap: '10px',
//			padding: '12px 20px',
//			borderTop: '1px solid ' + C.gray10,
//			background: C.gray5,
//			flexShrink: '0'
//		});
//		
//		var cancelBtn = _el('button');
//		cancelBtn.textContent = '닫기';
//		_css(cancelBtn, {
//			padding: '8px 18px',
//			border: '1px solid ' + C.gray20,
//			borderRadius: '6px',
//			background: C.gray0,
//			fontSize: '13px',
//			cursor: 'pointer',
//			color: C.gray70
//		});
//		cancelBtn.addEventListener('click', _removePopup);
//		
//		var printBtn = _el('button', { className: 'pdf-print-btn' });
//		printBtn.textContent = '📄 PDF 인쇄';
//		printBtn.disabled = true;
//		_css(printBtn, {
//			padding: '8px 20px',
//			border: 'none',
//			borderRadius: '6px',
//			background: C.primary60,
//			color: C.gray0,
//			fontSize: '13px',
//			fontWeight: '600',
//			cursor: 'pointer',
//			opacity: '0.4'
//		});
//		printBtn.addEventListener('click', function() {
//			if (printBtn.disabled) { return; }
//			printBtn.disabled = true;
//			printBtn.style.opacity = '0.4';
//			printBtn.textContent = '생성 중...';
//			onPrint();
//		});
//		
//		footer.appendChild(cancelBtn);
//		footer.appendChild(printBtn);
//		return {
//			el: footer,
//			enablePrint: function() {
//				printBtn.disabled = false;
//				printBtn.style.opacity = '1';
//			}
//		};
//	}
//	
//	/* ================================================================
//	 * 4. 콘텐츠 추출 · 재조립
//	 * ================================================================ */
//	function _buildPrintContent(sourceEl, printEl, onDone) {
//		var guidePages = sourceEl.querySelectorAll('.pb-guide-page');
//		if (!guidePages.length) { guidePages = [sourceEl]; }
//		
//		var htmlParts = [];
//		var playgrounds = []; // { id, sourceEl }
//		var i, j, guidePage, wraps, result;
//		
//		for (i = 0; i < guidePages.length; i++) {
//			guidePage = guidePages[i];
//			if (i > 0) { htmlParts.push('<div class="pdf-page-break"></div>'); }
//			
//			wraps = _getDirectLayoutWraps(guidePage);
//			for (j = 0; j < wraps.length; j++) {
//				result = _processWrap(wraps[j], playgrounds);
//				if (result) { htmlParts.push(result); }
//			}
//		}
//		
//		printEl.innerHTML = htmlParts.join('\n');
//		_capturePlaygrounds(printEl, playgrounds, onDone);
//	}
//	
//	/** guidePage 직계 자식 cl-layout-wrap 목록 반환 (중첩 제외) */
//	function _getDirectLayoutWraps(guidePage) {
//		var all = guidePage.querySelectorAll('.cl-layout-wrap');
//		var result = [],
//			i, el, p, nested;
//		
//		for (i = 0; i < all.length; i++) {
//			el = all[i];
//			p = el.parentNode;
//			nested = false;
//			while (p && p !== guidePage) {
//				if (p.classList && (
//						p.classList.contains('cl-layout-wrap')
//						|| p.classList.contains('pb-playground') /* ★ 추가 */
//					)) { nested = true; break; }
//				p = p.parentNode;
//			}
//			if (!nested) { result.push(el); }
//		}
//		return result;
//	}
//	
//	/** wrap → PDF용 HTML 문자열 */
//	function _processWrap(wrap, playgrounds) {
//		/* H1 → 페이지 구분 마커 + 제목 */
//		var h1 = wrap.querySelector('h1, .pb-page-title');
//		if (h1) {
//			return '<div class="pdf-page-break"></div><h1 class="pdf-h1">' + _text(h1) + '</h1>';
//		}
//		
//		var h2 = wrap.querySelector('h2, .pb-title-h2');
//		if (h2) { return '<h2 class="pdf-h2">' + _text(h2) + '</h2>'; }
//		
//		var h3 = wrap.querySelector('h3, .pb-title-h3');
//		if (h3) { return '<h3 class="pdf-h3">' + _text(h3) + '</h3>'; }
//		
//		var h4 = wrap.querySelector('h4, .pb-title-h4');
//		if (h4) { return '<h4 class="pdf-h4">' + _text(h4) + '</h4>'; }
//		
//		var subtitle = wrap.querySelector('.pb-page-subtitle');
//		if (subtitle) { return '<p class="pdf-subtitle">' + _inline(subtitle) + '</p>'; }
//		
//		var para = wrap.querySelector('.pb-p');
//		if (para) { return '<p class="pdf-p">' + _inline(para) + '</p>'; }
//		
//		var list = wrap.querySelector('.pb-list');
//		if (list) { return _buildList(list); }
//		
//		var table = wrap.querySelector('.pb-table');
//		if (table) { return _buildTable(table); }
//		
//		var callout = wrap.querySelector('.pb-callout');
//		if (callout) { return _buildCallout(callout); }
//		
//		/* playground — 플레이스홀더 + 나중에 이미지로 교체 */
//		var pg = wrap.querySelector('.pb-playground');
//		if (pg) {
//			var parts = [];
//			
//			/* ★ pb-playground-in 이 있을 때만 캡처 */
//			var pgIn = pg.querySelector('.pb-playground-in');
//			if (pgIn) {
//				var pid = 'pdf-pg-' + playgrounds.length;
//				playgrounds.push({ id: pid, sourceEl: pgIn });
//				parts.push(
//					'<div class="pdf-playground-wrap" id="' + pid + '">'
//					+ '<div class="pdf-playground-label">컨트롤 예시</div>'
//					+ '<div class="pdf-playground-img-slot"></div>'
//					+ '</div>'
//				);
//			}
//			
//			/* 코드블럭은 있을 때만 처리 */
//			var codeBlocks = pg.querySelectorAll('.pb-code');
//			if (codeBlocks.length) {
//				/* ★ 이 조건 추가 */
//				var k;
//				for (k = 0; k < codeBlocks.length; k++) {
//					parts.push(_buildCodeBlock(codeBlocks[k]));
//				}
//			}
//			
//			/* parts 가 비어있어도 빈 문자열 반환으로 안전 */
//			return parts.length ? parts.join('\n') : '';
//		}
//		
//		/* 토글 리스트 */
//		var toggleList = wrap.querySelector('.pb-toggle-list');
//		if (toggleList) {
//			/* 헤더 텍스트 + 본문 텍스트 펼쳐서 표시 */
//			var toggleParts = [];
//			var toggleHeaders = toggleList.querySelectorAll('.cl-accordion-header');
//			var toggleContents = toggleList.querySelectorAll('.cl-accordion-content');
//			var t;
//			for (t = 0; t < toggleHeaders.length; t++) {
//				toggleParts.push('<div class="pdf-toggle-header">' + _text(toggleHeaders[t]) + '</div>');
//				if (toggleContents[t]) {
//					toggleParts.push('<div class="pdf-toggle-content">' + _inline(toggleContents[t]) + '</div>');
//				}
//			}
//			return '<div class="pdf-toggle-list">' + toggleParts.join('') + '</div>';
//		}
//
//		/* 기타 텍스트 */
//		var clText = wrap.querySelector('.cl-text');
//		if (clText && clText.textContent.trim()) {
//			return '<p class="pdf-p">' + _inline(wrap) + '</p>';
//		}
//		
//		return '';
//	}
//	
//	function _buildList(el) {
//		var cls = el.className || '';
//		var isDash = cls.indexOf('dash') !== -1;
//		var isDecimal = cls.indexOf('decimal') !== -1;
//		var isOrder = cls.indexOf('order') !== -1;
//		var indent = cls.indexOf('indent') !== -1 ? ' pdf-indent' : '';
//		
//		var typeClass = isDash ? ' li-dash'
//			: isDecimal ? ' li-decimal'
//			: isOrder ? ' li-order'
//			: ''; /* 타입 없으면 마커 없음 */
//		
//		return '<div class="pdf-list' + typeClass + indent + '">'
//			+ _inline(el) + '</div>';
//	}
//	
//	function _buildCallout(el) {
//		var cls = el.className || '';
//		var type = cls.indexOf('callout-success') !== -1 ? 'success'
//			: cls.indexOf('callout-warning') !== -1 ? 'warning'
//			: cls.indexOf('callout-danger') !== -1 ? 'danger'
//			: cls.indexOf('callout-info') !== -1 ? 'info'
//			: 'default';
//		
//		var parts = [];
//		
//		var callout = document.querySelector('.pb-callout');
//		console.log('callout HTML:', callout.innerHTML.substring(0, 2000));
//		
//		// pb-p 직접 탐색
//		var pbp = callout.querySelectorAll('.pb-p');
//		console.log('pb-p 개수:', pbp.length);
//		
//		// cl-text 탐색
//		var clTexts = callout.querySelectorAll('.cl-text');
//		console.log('cl-text 개수:', clTexts.length);
//		clTexts.forEach(function(el, i) {
//		  console.log('cl-text[' + i + ']:', el.textContent.trim());
//		});
//		
//		/* 제목 */
//		var titleEl = el.querySelector('.pb-title-h4');
//		if (titleEl) {
//			parts.push('<div class="pdf-callout-title">' + _text(titleEl) + '</div>');
//		}
//		
//		/* ★ 내용: cl-layout-wrap 단위로 순회하여 pb-p 처리 */
//		var wraps = el.querySelectorAll('.cl-layout-wrap');
//		var i, wrap, para;
//		if (wraps.length) {
//			for (i = 0; i < wraps.length; i++) {
//				wrap = wraps[i];
//				para = wrap.querySelector('.pb-p');
//				if (para) {
//					parts.push('<p class="pdf-callout-p">' + _inline(para) + '</p>');
//				}
//			}
//		}
//		else {
//			/* fallback: cl-layout-wrap 없는 단순 구조 */
//			var paras = el.querySelectorAll('.pb-p');
//			for (i = 0; i < paras.length; i++) {
//				parts.push('<p class="pdf-callout-p">' + _inline(paras[i]) + '</p>');
//			}
//		}
//		
//		return '<div class="pdf-callout pdf-callout-' + type + '">'
//			+ parts.join('') + '</div>';
//	}
//	
//	/**
//	 * 코드 블럭 처리
//	 * — .pb-codeblock 안의 모든 .code.cm 을 순회 (탭 개수 = 코드 개수)
//	 * — 탭 버튼 aria-label 로 섹션 헤더 생성
//	 */
//	function _buildCodeBlock(pbCodeEl) {
//		var tabBtns = pbCodeEl.querySelectorAll('.pb-tab-btn');
//		
//		/* .pb-codeblock > .code.cm 우선, 없으면 직접 .code.cm */
//		var codeEls = pbCodeEl.querySelectorAll('.pb-codeblock .code.cm');
//		if (!codeEls.length) { return ''; } // fallback 제거
//		
//		var parts = ['<div class="pdf-code-section">'];
//		var i, label, codeText;
//		
//		for (i = 0; i < codeEls.length; i++) {
//			label = tabBtns[i]
//				? (tabBtns[i].getAttribute('aria-label') || tabBtns[i].textContent.trim() || ('코드 ' + (i + 1)))
//				: ('코드 ' + (i + 1));
//			
//			codeText = _extractCmText(codeEls[i]);
//			
//			parts.push(
//				'<div class="pdf-tab-label">' + _esc(label) + '</div>'
//				+ '<pre class="pdf-pre">' + _esc(codeText) + '</pre>'
//			);
//		}
//		
//		parts.push('</div>');
//		return parts.join('\n');
//	}
//	
//	function _buildTable(container) {
//		var cells = container.querySelectorAll('.pb-th, .pb-td');
//		if (!cells.length) { return ''; }
//		
//		var data = [],
//			i, cell, style, m;
//		for (i = 0; i < cells.length; i++) {
//			cell = cells[i];
//			style = cell.getAttribute('style') || '';
//			m = style.match(/grid-area:\s*(\d+)\s*\/\s*(\d+)/);
//			if (m) {
//				data.push({
//					row: parseInt(m[1], 10),
//					col: parseInt(m[2], 10),
//					th: cell.classList.contains('pb-th'),
//					text: _inline(cell)
//				});
//			}
//		}
//		if (!data.length) { return ''; }
//		
//		data.sort(function(a, b) { return a.row !== b.row ? a.row - b.row : a.col - b.col; });
//		
//		var rows = {},
//			k, rn;
//		for (k = 0; k < data.length; k++) {
//			rn = data[k].row;
//			if (!rows[rn]) { rows[rn] = []; }
//			rows[rn].push(data[k]);
//		}
//		
//		var html = ['<table class="pdf-table"><tbody>'];
//		var keys = Object.keys(rows).sort(function(a, b) { return +a - +b; });
//		var r, rowCells, c, tag;
//		
//		for (r = 0; r < keys.length; r++) {
//			rowCells = rows[keys[r]];
//			html.push('<tr>');
//			for (c = 0; c < rowCells.length; c++) {
//				tag = rowCells[c].th ? 'th' : 'td';
//				html.push('<' + tag + '>' + rowCells[c].text + '</' + tag + '>');
//			}
//			html.push('</tr>');
//		}
//		html.push('</tbody></table></div>');
//		return '<div class="pdf-table-wrap">' + html.join('');
//	}
//	
//	/* ================================================================
//	 * 5. playground 캡처
//	 * ================================================================ */
//	function _capturePlaygrounds(printEl, playgrounds, onDone) {
//		if (!playgrounds.length) { onDone(); return; }
//		
//		var idx = 0;
//		
//		function next() {
//			if (idx >= playgrounds.length) { onDone(); return; }
//			
//			(function(info) {
//				info.sourceEl.scrollIntoView({ block: 'center' });
//				
//				setTimeout(function() {
//					html2canvas(info.sourceEl, {
//						scale: _cfg.scale,
//						useCORS: true,
//						allowTaint: true,
//						logging: false,
//						width: info.sourceEl.offsetWidth,
//						height: info.sourceEl.offsetHeight
//					}).then(function(canvas) {
//						var slot = printEl.querySelector('#' + info.id + ' .pdf-playground-img-slot');
//						if (slot) {
//							var img = document.createElement('img');
//							img.src = canvas.toDataURL('image/png');
//							img.style.width = '100%';
//							img.style.display = 'block';
//							img.style.borderRadius = '0 0 6px 6px';
//							slot.appendChild(img);
//						}
//						idx++;
//						next();
//					}).catch(function(err) {
//						_log('playground 캡처 오류: ' + err, 'error');
//						idx++;
//						next();
//					});
//				}, 150);
//			}(playgrounds[idx]));
//		}
//		
//		next();
//	}
//	
//	/* ================================================================
//	 * 6. PDF 생성 (전체 1회 캡처 → 캔버스 슬라이싱)
//	 * ================================================================ */
//	function _generatePdf(printEl) {
//		/* ★ 캡처 전 그림자·배경 임시 제거 */
//		var origBoxShadow = printEl.style.boxShadow;
//		var origBg = printEl.parentNode.style.background;
//		printEl.style.boxShadow = 'none';
//		printEl.parentNode.style.background = '#fff';
//  
//		var jsPDFCtor = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
//		var pdf = new jsPDFCtor({ orientation: 'portrait', unit: 'mm', format: _cfg.pageFormat });
//		
//		var pageW = pdf.internal.pageSize.getWidth();
//		var pageH = pdf.internal.pageSize.getHeight();
//		var margin = _cfg.pageMarginMm;
//		var contentW = pageW - margin * 2;
//		var contentH = pageH - margin * 2;
//		
//		html2canvas(printEl, {
//			scale: _cfg.scale,
//			useCORS: true,
//			allowTaint: true,
//			logging: false,
//			width: printEl.scrollWidth,
//			height: printEl.scrollHeight,
//			windowWidth: printEl.scrollWidth,
//			scrollX: 0,
//			scrollY: 0
//		}).then(function(fullCanvas) {
//			/* ★ 스타일 복원 */
//			printEl.style.boxShadow = origBoxShadow;
//			printEl.parentNode.style.background = origBg;
//    
//			/* 캔버스 px ↔ mm 비율 */
//			var pxPerMm = fullCanvas.width / contentW;
//			/* 한 페이지 높이(캔버스 px) */
//			var pageHpx = Math.floor(contentH * pxPerMm);
//			var totalH = fullCanvas.height;
//			
//			/* pdf-page-break 마커의 Y 좌표(캔버스 px) 수집 */
//			var breakPoints = _collectBreakPoints(printEl, _cfg.scale);
//			var avoidBreaks = _collectAvoidBreakElements(printEl, _cfg.scale);
//			
//			var slice = document.createElement('canvas');
//			slice.width = fullCanvas.width;
//			var ctx = slice.getContext('2d');
//			var offsetY = 0;
//			var pageIdx = 0;
//			
//			while (offsetY < totalH) {
//				var idealEnd = offsetY + pageHpx;
//				var sliceEnd = Math.min(idealEnd, totalH);
//				
//				/* 1) pdf-page-break 마커 우선 처리 */
//				var b;
//				for (b = 0; b < breakPoints.length; b++) {
//					if (breakPoints[b] > offsetY && breakPoints[b] < sliceEnd) {
//						sliceEnd = breakPoints[b];
//						break;
//					}
//				}
//				
//				/* 2) 구획 잘림 방지 — 요소가 페이지 경계에 걸치면 요소 시작 직전에서 분리
//				      단, 요소가 한 페이지보다 크면 그냥 통과 (무한루프 방지) */
//				for (b = 0; b < avoidBreaks.length; b++) {
//					var elTop = avoidBreaks[b].top;
//					var elBottom = avoidBreaks[b].bottom;
//					var elHeight = elBottom - elTop;
//					
//					if (elTop > offsetY /* 요소 시작이 현재 페이지 안 */
//						&& elTop < sliceEnd /* 요소 시작이 페이지 끝 안 */
//						&& elBottom > sliceEnd /* 요소 끝이 페이지를 넘음 */
//						&& elHeight < pageHpx /* ★ 요소가 한 페이지보다 작을 때만 */
//						&& elTop > offsetY + 20) {
//						/* ★ 페이지 최상단에 붙어있으면 그냥 진행 */
//						sliceEnd = elTop;
//						break;
//					}
//				}
//				
//				sliceEnd = Math.min(sliceEnd, totalH);
//				var sliceH = sliceEnd - offsetY;
//				if (sliceH <= 0) { offsetY++; continue; } /* ★ 무한루프 방지 */
//				
//				slice.height = sliceH;
//				ctx.clearRect(0, 0, slice.width, sliceH);
//				ctx.drawImage(fullCanvas,
//					0, offsetY, fullCanvas.width, sliceH,
//					0, 0, fullCanvas.width, sliceH
//				);
//				
//				var imgData = slice.toDataURL('image/jpeg', 0.95);
//				var aspect = sliceH / fullCanvas.width;
//				var imgW = contentW;
//				var imgH = imgW * aspect;
//				if (imgH > contentH) { imgH = contentH;
//					imgW = imgH / aspect; }
//				
//				if (pageIdx > 0) { pdf.addPage(); }
//				pdf.addImage(imgData, 'JPEG', margin, margin, imgW, imgH);
//				
//				offsetY = sliceEnd;
//				pageIdx++;
//			}
//			
//			pdf.save(_cfg.filename);
//			_removePopup();
//			_log('저장 완료 (' + pageIdx + '페이지): ' + _cfg.filename);
//			
//		}).catch(function(err) {
//			_log('PDF 생성 오류: ' + err, 'error');
//		});
//	}
//	
//	/**
//	 * .pdf-page-break 요소들의 printEl 기준 Y 좌표를 캔버스 픽셀로 반환
//	 */
//	function _collectBreakPoints(printEl, scale) {
//		var markers = printEl.querySelectorAll('.pdf-page-break');
//		var parentTop = printEl.getBoundingClientRect().top;
//		var points = [],
//			i, r;
//		for (i = 0; i < markers.length; i++) {
//			r = markers[i].getBoundingClientRect();
//			points.push(Math.floor((r.top - parentTop) * scale));
//		}
//		return points;
//	}
//	
//	function _collectAvoidBreakElements(printEl, scale) {
//		var selector = '.pdf-code-section, .pdf-table, .pdf-playground-wrap';
//		var nodes = printEl.querySelectorAll(selector);
//		var parentTop = printEl.getBoundingClientRect().top;
//		var result = [],
//			i, r;
//		for (i = 0; i < nodes.length; i++) {
//			r = nodes[i].getBoundingClientRect();
//			result.push({
//				top: Math.floor((r.top - parentTop) * scale),
//				bottom: Math.floor((r.bottom - parentTop) * scale)
//			});
//		}
//		return result;
//	}
//	
//	/* ================================================================
//	 * 7. 텍스트 추출
//	 * ================================================================ */
//	
//	/** .cl-text 순수 텍스트 (이스케이프) */
//	function _text(el) {
//		var t = el.querySelector('.cl-text');
//		return _esc((t || el).textContent.trim());
//	}
//	
//	/** .cl-text 안의 인라인 HTML 재구성 (span.pb-point / span.pb-code / span.strong 보존) */
//	function _inline(el) {
//		var src = el.querySelector('.cl-text') || el;
//		return _walkNodes(src.childNodes);
//	}
//	
//	function _walkNodes(nodes) {
//		var result = [],
//			i, node, tag, cls, text; /* ★ text 선언 추가 */
//		for (i = 0; i < nodes.length; i++) {
//			node = nodes[i];
//			if (node.nodeType === 3) {
//				result.push(_esc(node.textContent));
//			}
//			else if (node.nodeType === 1) {
//				tag = node.tagName.toLowerCase();
//				cls = node.className || '';
//				
//				if (tag === 'br') {
//					result.push('<br>');
//				}
//				else if (tag === 'div' || tag === 'span') {
//					text = _esc(node.textContent); /* ★ 선언된 text 사용 */
//					if (cls.indexOf('pb-point') !== -1) {
//						result.push('<span class="pdf-point">' + text + '</span>');
//					}
//					else if (cls.indexOf('pb-code') !== -1) {
//						/* ★ 'code' 단독 조건 제거 */
//						result.push('<code class="pdf-code-inline">' + text + '</code>');
//					}
//					else if (cls.indexOf('strong') !== -1) {
//						result.push('<strong>' + text + '</strong>');
//					}
//					else if (cls.indexOf('prop') !== -1) {
//						result.push('<span class="pdf-prop">' + text + '</span>');
//					}
//					else if (cls.indexOf('type') !== -1) {
//						result.push('<span class="pdf-type">' + text + '</span>');
//					}
//					else if (cls.indexOf(' em') !== -1 || cls === 'em') {
//						/* ★ em 정확히 매칭 */
//						result.push('<em class="pdf-em">' + text + '</em>');
//					}
//					else {
//						result.push(_walkNodes(node.childNodes)); /* 재귀 */
//					}
//				}
//				else {
//					result.push(_walkNodes(node.childNodes));
//				}
//			}
//		}
//		return result.join('');
//	}
//	
//	/** CodeMirror .cm-line 기준 코드 텍스트 추출 */
//	function _extractCmText(codeEl) {
//		var lines = codeEl.querySelectorAll('.cm-line');
//		var arr = [],
//			i;
//		for (i = 0; i < lines.length; i++) { arr.push(lines[i].textContent); }
//		return arr.length ? arr.join('\n') : codeEl.textContent;
//	}
//	
//	function _esc(str) {
//		return String(str)
//			.replace(/&/g, '&amp;')
//			.replace(/</g, '&lt;')
//			.replace(/>/g, '&gt;')
//			.replace(/"/g, '&quot;');
//	}
//	
//	/* ================================================================
//	 * 8. 스타일 주입 (KRDS 색상 기반)
//	 * ================================================================ */
//	function _injectStyles() {
//		if (document.getElementById('_pdf-styles-v3')) { return; }
//		var s = document.createElement('style');
//		s.id = '_pdf-styles-v3';
//		s.textContent = [
//			'@keyframes pdf-spin{to{transform:rotate(360deg)}}',
//			
//			'#pdf-print-area{font-family:"Malgun Gothic","Apple SD Gothic Neo","Noto Sans KR",sans-serif;'
//			+ 'font-size:13px;line-height:1.75;color:' + C.gray90 + ';word-break:break-word;width:100%;box-sizing:border-box;}',
//			
//			/* 페이지 구분 마커 (렌더링 없음) */
//			'#pdf-print-area .pdf-page-break{display:block;height:0;margin:0;padding:0;border:none;overflow:hidden;}',
//			
//			/* 제목 */
//			'#pdf-print-area .pdf-h1{font-size:20px;font-weight:700;color:' + C.gray90 + ';'
//			+ 'margin:20px 0 10px;padding-bottom:8px;border-bottom:2px solid ' + C.primary50 + ';line-height:1.3;}',
//			'#pdf-print-area .pdf-h2{font-size:16px;font-weight:700;color:' + C.gray80 + ';'
//			+ 'margin:18px 0 7px;padding-bottom:4px;border-bottom:1px solid ' + C.gray20 + ';}',
//			'#pdf-print-area .pdf-h3{font-size:14px;font-weight:600;color:' + C.gray80 + ';margin:14px 0 5px;}',
//			'#pdf-print-area .pdf-h4{font-size:13px;font-weight:600;color:' + C.gray70 + ';margin:10px 0 4px;}',
//			
//			/* 본문 */
//			'#pdf-print-area .pdf-subtitle{font-size:13px;color:' + C.gray70 + ';margin:0 0 14px;line-height:1.8;}',
//			'#pdf-print-area .pdf-p{margin:0 0 8px;line-height:1.8;}',
//			
//			/* 리스트 */
//			'#pdf-print-area .pdf-list{position:relative;padding-left:16px;margin:3px 0 5px;line-height:1.75;}',
//			'#pdf-print-area .pdf-list.pdf-indent{padding-left:40px;}',
//			'#pdf-print-area .pdf-list.li-dash.pdf-indent::before{left:20px;}',
//			'#pdf-print-area .pdf-list.li-decimal.pdf-indent::before{left:20px;}',
//			'#pdf-print-area .pdf-list.li-dash::before{content:"-";position:absolute;left:0;color:' + C.gray70 + ';}',
//			'#pdf-print-area .pdf-list.li-decimal::before{content:"•";position:absolute;left:0;color:' + C.gray70 + ';}',
//			'#pdf-print-area .pdf-em{color:#a92027;font-style:normal;}',
//			
//			/* 인라인 강조 — pb-point / pb-code 통일 (KRDS primary 색상) */
//			'#pdf-print-area .pdf-point{display:inline;color:#a92027;text-decoration:underline;'
//			+ 'text-decoration-color:rgba(169,32,39,0.3);text-underline-offset:3px;}',
//			+'padding:1px 5px;border-radius:3px;font-size:12px;'
//			+ 'font-family:"Consolas","D2Coding",monospace;border:1px solid ' + C.primary10 + ';}',
//				'#pdf-print-area code.pdf-code-inline{'
//				+ 'display:inline;font-family:"Consolas","Monaco",monospace;'
//				+ 'font-size:inherit;background:rgba(169,32,39,0.08);'
//				+ 'border-radius:4px;color:#a92027;padding:2px 4px;border:none;}',
//			
//			/* 코드 블럭 */
//			'#pdf-print-area .pdf-code-section{margin:10px 0 16px;}',
//			'#pdf-print-area .pdf-tab-label{'
//			+ 'display:inline-block;margin:12px 0 0;padding:3px 10px;'
//			+ 'background:' + C.primary60 + ';color:' + C.gray0 + ';'
//			+ 'font-size:11px;font-weight:600;border-radius:4px 4px 0 0;}',
//			'#pdf-print-area .pdf-pre{'
//			+ 'display:block;margin:0 0 6px;padding:12px 14px;'
//			+ 'background:' + C.gray90 + ';color:' + C.gray5 + ';'
//			+ 'font-family:"Consolas","D2Coding","Malgun Gothic",monospace;'
//			+ 'font-size:12px;line-height:1.6;border-radius:0 6px 6px 6px;'
//			+ 'white-space:pre-wrap;word-break:break-all;overflow:visible;max-height:none;height:auto;}',
//			
//			/* 테이블 */
//			'#pdf-print-area .pdf-table-wrap{'
//			+ 'border:1px solid #e6e8ea;border-radius:4px;overflow:hidden;margin:6px 0 10px;}',
//			'#pdf-print-area .pdf-table{'
//			+ 'width:100%;border-collapse:collapse;font-size:12px;}',
//			'#pdf-print-area .pdf-table th{'
//			+ 'background:#f4f5f6;color:#1e2124;font-weight:500;font-size:12px;'
//			+ 'padding:5px 8px;text-align:left;'
//			+ 'border-bottom:1px solid #e6e8ea;border-right:1px solid #e6e8ea;}',
//			'#pdf-print-area .pdf-table th:last-child{border-right:none;}',
//			'#pdf-print-area .pdf-table td{'
//			+ 'color:#33363d;padding:5px 8px;text-align:left;vertical-align:top;'
//			+ 'border-bottom:1px solid #e6e8ea;border-right:1px solid #e6e8ea;line-height:1.4;}',
//			'#pdf-print-area .pdf-table td:last-child{border-right:none;}',
//			'#pdf-print-area .pdf-table tr:last-child td{border-bottom:none;}',
//			'#pdf-print-area .pdf-table tr:nth-child(even) td{background:#fafafa;}',
//			
//			/* callout */
//			'#pdf-print-area .pdf-callout{margin:8px 0 12px;padding:12px;border-radius:8px;'
//			+ 'border:1px solid #cdd1d5;background:#f4f5f6;font-size:14px;}',
//			'#pdf-print-area .pdf-callout-title{font-weight:500;font-size:15px;color:#1e2124;margin-bottom:4px;'
//			+ 'padding-left:20px;position:relative;}',
//			'#pdf-print-area .pdf-callout-title::before{content:"!";position:absolute;left:0;top:3px;'
//			+ 'width:16px;height:16px;border:1.5px solid #464c53;border-radius:50%;'
//			+ 'display:flex;justify-content:center;align-items:center;font-size:12px;}',
//			'#pdf-print-area .pdf-callout-info{background:#e7f4fe;border-color:#9ed2fa;}',
//			'#pdf-print-area .pdf-callout-info .pdf-callout-title{color:#0b78cb;}',
//			'#pdf-print-area .pdf-callout-info .pdf-callout-title::before{border-color:#0b78cb;}',
//			'#pdf-print-area .pdf-callout-success{background:#eaf6ec;border-color:#a9dab4;}',
//			'#pdf-print-area .pdf-callout-success .pdf-callout-title{color:#267337;}',
//			'#pdf-print-area .pdf-callout-success .pdf-callout-title::before{border-color:#228738;}',
//			'#pdf-print-area .pdf-callout-warning{background:#fff3db;border-color:#ffc95c;}',
//			'#pdf-print-area .pdf-callout-warning .pdf-callout-title{color:#8a5c00;}',
//			'#pdf-print-area .pdf-callout-warning .pdf-callout-title::before{border-color:#9e6a00;}',
//			'#pdf-print-area .pdf-callout-danger{background:#fdefec;border-color:#f7afa1;}',
//			'#pdf-print-area .pdf-callout-danger .pdf-callout-title{color:#bd2c0f;}',
//			'#pdf-print-area .pdf-callout-danger .pdf-callout-title::before{border-color:#de3412;}',
//			'#pdf-print-area .pdf-callout-p{font-size:14px;margin:0 0 4px;color:inherit;}',
//			
//			/* playground (컨트롤 예시) */
//			'#pdf-print-area .pdf-playground-wrap{margin:10px 0 14px;border:1px solid ' + C.gray10 + ';border-radius:6px;overflow:hidden;}',
//			'#pdf-print-area .pdf-playground-label{padding:5px 12px;background:' + C.gray5 + ';'
//			+ 'font-size:11px;font-weight:600;color:' + C.gray50 + ';border-bottom:1px solid ' + C.gray10 + ';}',
//			'#pdf-print-area .pdf-playground-img-slot{padding:0;background:' + C.gray0 + ';}',
//			
//			/* 토글 리스트 */
//			'#pdf-print-area .pdf-toggle-list{margin:4px 0 8px;}',
//			'#pdf-print-area .pdf-toggle-header{font-size:15px;font-weight:500;color:#1e2124;'
//			+ 'padding-left:20px;position:relative;margin-bottom:4px;}',
//			'#pdf-print-area .pdf-toggle-content{padding-left:20px;color:#33363d;font-size:14px;margin-bottom:8px;}',
//		].join('\n');
//		
//		document.head.appendChild(s);
//	}
//	
//	/* ================================================================
//	 * 9. 팝업 제거
//	 * ================================================================ */
//	function _removePopup() {
//		var ov = document.getElementById(_cfg.overlayId);
//		if (ov && ov.parentNode) { ov.parentNode.removeChild(ov); }
//	}
//	
//	/* ================================================================
//	 * 10. 공통 유틸
//	 * ================================================================ */
//	function _el(tag, props) {
//		var el = document.createElement(tag),
//			k;
//		if (props) {
//			for (k in props) {
//				if (!props.hasOwnProperty(k)) { continue; }
//				if (k === 'className') { el.className = props[k]; }
//				else { el.setAttribute(k, props[k]); }
//			}
//		}
//		return el;
//	}
//	
//	function _css(el, styles) {
//		var k;
//		for (k in styles) {
//			if (styles.hasOwnProperty(k)) { el.style[k] = styles[k]; }
//		}
//	}
//	
//	function _merge(a, b) {
//		var r = {},
//			k;
//		for (k in a) { if (a.hasOwnProperty(k)) { r[k] = a[k]; } }
//		for (k in b) { if (b.hasOwnProperty(k)) { r[k] = b[k]; } }
//		return r;
//	}
//	
//	function _checkDeps() {
//		if (typeof html2canvas === 'undefined') { _log('html2canvas 미로드', 'error'); return false; }
//		if (typeof window.jspdf === 'undefined' && typeof jsPDF === 'undefined') { _log('jsPDF 미로드', 'error'); return false; }
//		return true;
//	}
//	
//	function _log(msg, lvl) {
//		if (typeof console === 'undefined') { return; }
//		if (lvl === 'error') { console.error('[PdfDownload] ' + msg); }
//		else { console.log('[PdfDownload] ' + msg); }
//	}
//	
//	return { init: init, start: start };
//	
//}());
//
//exports.PdfDownload = PdfDownload;

/**
 * pb-pdf-core.es5.js
 * PDF 내보내기 핵심 로직 (ES5 / IE 호환)
 *
 * ── 사전 준비 사항 ─────────────────────────────────────────────
 *
 * 1. html2canvas 로드 (playground 스냅샷에 필요)
 *    → 페이지 <head> 또는 버튼 클릭 전 시점에 미리 로드 권장
 *    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
 *
 * 2. 퍼블리싱 가이드 HTML에 아래 속성이 있어야 함
 *    - PDF 대상 루트:  data-usr-pdf-target="guide-content"
 *    - 섹션 단위:      class에 "pb-guide-page" 포함
 *
 * 3. 아래 Print <style> 블록을 페이지에 삽입해야 함
 *    (파일 하단 주석 참고)
 *
 * ── 사용법 ────────────────────────────────────────────────────
 *
 *  버튼 클릭 핸들러 안에서:
 *
 *  setTimeout(function() {
 *    pbPdfExport().then(function() {
 *      // 완료 후 버튼 복원 등 처리
 *    });
 *  }, 0);
 *
 * ──────────────────────────────────────────────────────────────
 */

/* ════════════════════════════════════════════════════════════
   메인 진입 함수 — setTimeout 안에서 호출
════════════════════════════════════════════════════════════ */
exports.pbPdfExport = pbPdfExport;

function pbPdfExport() {
	var SELECTOR_TARGET = '.pb-preview';
	var SELECTOR_PAGE = '.pb-preview .pb-guide-page';
	
	/* ── 대상 요소 및 섹션 수집 ── */
	var target = document.querySelector(SELECTOR_TARGET);
	if (!target) {
		console.error('[pb-pdf] .pb-preview 요소를 찾을 수 없습니다.');
		return Promise.resolve();
	}
	
	// 스타일 주입
	_injectStyle();
	
	var pageNodeList = target.querySelectorAll(SELECTOR_PAGE);
	var pageEls = [].slice.call(pageNodeList); // IE: Array.from 미지원
	
	// pb-guide-page의 부모 구조 확인
	console.log('[pb-pdf] ① 섹션 수집:', pageEls.length);
	var firstPage = document.querySelector('.pb-guide-page');
	var node = firstPage;
	var depth = 0;
	while (node && node !== document.body && depth < 10) {
		console.log(depth, node.tagName, node.className.substring(0, 60));
		node = node.parentNode;
		depth++;
	}
	
	if (pageEls.length === 0) {
		console.error('[pb-pdf] .pb-guide-page 섹션을 찾을 수 없습니다.');
		return Promise.resolve();
	}
	
	/* ── print-root 컨테이너 준비 ── */
	var old = document.getElementById('pb-print-root');
	if (old) old.parentNode.removeChild(old);
	
	var printRoot = document.createElement('div');
	printRoot.id = 'pb-print-root';
	printRoot.style.display = 'none';
	document.body.appendChild(printRoot);
	
	/* ── 전체 섹션 cloneNode ── */
	for (var i = 0; i < pageEls.length; i++) {
		// 기존: pageEls[i] (pb-guide-page) 그대로 클론
		var clone = pageEls[i].cloneNode(true);
		clone.className += ' pb-print-section';
		clone.style.cssText = '';
		printRoot.appendChild(clone);
	}
	
	/* ── 아이콘 처리 ── */
	_resolveIcons(target, printRoot);
	console.log('[pb-pdf] ③ 아이콘 처리 완료');
	
	/* ── 나머지 처리 (Promise 체이닝) ── */
	return _snapshotPlaygrounds(pageEls, printRoot)
		.then(function() {
			/* ── 테이블 변환 ── */
			_fixTables(printRoot);
			console.log('[pb-pdf] ⑦ 테이블 변환 완료');
			
			/* ── 코드 탭 정리 ── */
			_flattenCodeTabs(printRoot);
			console.log('[pb-pdf] ④ playground 스냅샷 완료');
			
			/* ── 레이아웃 경량화 ── */
			// 2. cloneNode 후 print-root 안에서도 있는지 확인
			// (PDF 버튼 클릭 직후, _slimDOM 실행 직전 시점에 추가)
			var root = document.getElementById('pb-print-root'); // 디버그용 별칭
			if (root) {
				console.log('[clone] pb-p 수:', root.querySelectorAll('.pb-p').length);
				console.log('[clone] pb-title-h2 수:', root.querySelectorAll('.pb-title-h2').length);
				console.log('[clone] pb-layout-margin 수:', root.querySelectorAll('.cl-layout-margin').length);
				console.log('[clone] innerHTML 길이:', root.innerHTML.length);
			}
			
			_slimDOM(printRoot);
			
			/* ── 레이아웃 보정 ── */
			_fixLayout(printRoot);
			console.log('[pb-pdf] ⑥ 레이아웃 보정 완료');
			
			/* ── 인쇄 실행 ── */
			printRoot.style.display = 'block';
			// body 직계 자식 중 pb-print-root 제외하고 모두 숨김
			var bodyChildren = [].slice.call(document.body.children);
			var hiddenEls = [];
			for (var h = 0; h < bodyChildren.length; h++) {
				if (bodyChildren[h].id !== 'pb-print-root') {
					hiddenEls.push({
						el: bodyChildren[h],
						display: bodyChildren[h].style.display
					});
					bodyChildren[h].style.display = 'none';
				}
			}
			console.log('[pb-pdf] ⑧ print-root 표시, print() 직전');
			
			function onAfterPrint() {
				// 숨겼던 요소 복원
				for (var r = 0; r < hiddenEls.length; r++) {
					hiddenEls[r].el.style.display = hiddenEls[r].display;
				}
				// print-root 제거
				if (printRoot.parentNode) {
					printRoot.parentNode.removeChild(printRoot);
				}
				if (window.removeEventListener) {
					window.removeEventListener('afterprint', onAfterPrint);
				}
				else if (window.detachEvent) {
					window.detachEvent('onafterprint', onAfterPrint);
				}
			}
			
			if (window.addEventListener) {
				window.addEventListener('afterprint', onAfterPrint);
			}
			else if (window.attachEvent) {
				window.attachEvent('onafterprint', onAfterPrint);
			}
			
			if (window.addEventListener) {
				window.addEventListener('afterprint', onAfterPrint);
			}
			else if (window.attachEvent) {
				// IE8 이하
				window.attachEvent('onafterprint', onAfterPrint);
			}
			
			return new Promise(function(resolve) {
				setTimeout(function() {
					window.print();
					resolve();
				}, 120);
			});
		});
}

/* ════════════════════════════════════════════════════════════
   내부 전처리 함수
════════════════════════════════════════════════════════════ */

/**
 * 아이콘 처리
 * cl-icon의 background-image 가상경로(pb/guide/controls/0)를
 * 원본 DOM getComputedStyle로 읽어 clone에 적용. 복원 불가 시 숨김.
 */
function _resolveIcons(origTarget, printRoot) {
	var origIcons = [].slice.call(origTarget.querySelectorAll('.cl-icon'));
	var cloneIcons = [].slice.call(printRoot.querySelectorAll('.cl-icon'));
	
	for (var i = 0; i < cloneIcons.length; i++) {
		var cloneIcon = cloneIcons[i];
		var origIcon = origIcons[i];
		
		if (!origIcon) {
			cloneIcon.style.display = 'none';
			continue;
		}
		
		var bg = '';
		if (window.getComputedStyle) {
			bg = window.getComputedStyle(origIcon).backgroundImage;
		}
		else if (origIcon.currentStyle) {
			// IE8 이하
			bg = origIcon.currentStyle.backgroundImage;
		}
		
		if (!bg || bg === 'none' || bg.indexOf('pb/guide') !== -1) {
			cloneIcon.style.backgroundImage = 'none';
			cloneIcon.style.display = 'none';
		}
		else {
			cloneIcon.style.backgroundImage = bg;
		}
	}
}

/**
 * playground 스냅샷
 * 원본 DOM의 pb-playground를 html2canvas로 캡처 후
 * clone 안의 pb-playground를 <img>로 교체.
 * Promise 반환 (IE에서 async/await 미지원).
 */
function _snapshotPlaygrounds(origPageEls, printRoot) {
	// flatMap 미지원(IE) → reduce로 대체
	var origPgs = origPageEls.reduce(function(acc, el) {
		var pgs = [].slice.call(el.querySelectorAll('.pb-playground'));
		return acc.concat(pgs);
	}, []);
	
	var clonePgs = [].slice.call(printRoot.querySelectorAll('.pb-playground'));
	console.log('[pb-pdf] playground 수:', origPgs.length);
	
	if (origPgs.length === 0) {
		return Promise.resolve();
	}
	
	if (!window.html2canvas) {
		for (var f = 0; f < clonePgs.length; f++) {
			if (clonePgs[f].parentNode) {
				clonePgs[f].parentNode.replaceChild(
					_makeFallbackWrapper('미리보기 (html2canvas 미로드)'),
					clonePgs[f]
				);
			}
		}
		return Promise.resolve();
	}
	
	// 캡처 사이마다 setTimeout(0) 으로 메인 스레드 양보
	function _yieldTick() {
		return new Promise(function(resolve) {
			setTimeout(resolve, 0);
		});
	}
	
	// 단일 playground 캡처
	function _captureOne(orig, clone, idx, total) {
		if (!orig || !clone || !clone.parentNode) {
			return Promise.resolve();
		}
		
		var pgIn = orig.querySelector('.pb-playground-in') || orig;
		var prevOverflow = pgIn.style.overflow;
		pgIn.style.overflow = 'visible';
		
		return window.html2canvas(pgIn, {
			useCORS: true,
			allowTaint: true,
			scale: 1, // 멈춤 방지: scale 2 → 1 (메모리 1/4 절감)
			backgroundColor: '#ffffff',
			logging: false,
			removeContainer: true
		}).then(function(canvas) {
			pgIn.style.overflow = prevOverflow;
			
			var img = document.createElement('img');
			img.src = canvas.toDataURL('image/png');
			img.style.cssText = 'max-width:100%;height:auto;display:block;border-radius:3px;';
			
			var wrapper = document.createElement('div');
			wrapper.className = 'pb-playground-wrapper';
			
			var label = document.createElement('span');
			label.className = 'pb-playground-label';
			label.appendChild(document.createTextNode('미리보기'));
			
			wrapper.appendChild(label);
			wrapper.appendChild(img);
			
			if (clone.parentNode) {
				clone.parentNode.replaceChild(wrapper, clone);
			}
			
			console.log('[pb-pdf] playground 캡처 완료:', idx + 1, '/', total);
			
		}).catch(function(e) {
			console.warn('[pb-pdf] playground 캡처 실패 (' + (idx + 1) + '):', e);
			pgIn.style.overflow = prevOverflow;
			if (clone.parentNode) {
				clone.parentNode.replaceChild(
					_makeFallbackWrapper('미리보기 (캡처 실패)'),
					clone
				);
			}
		});
	}
	
	// 순차 실행: 캡처 → yield → 캡처 → yield ...
	 var chain = Promise.resolve();
	 var total = origPgs.length;
	 
	 for (var i = 0; i < total; i++) {
	 	(function(idx) {
	 		chain = chain
	 			.then(function() {
	 				return _captureOne(origPgs[idx], clonePgs[idx], idx, total);
	 			})
	 			.then(function() {
	 				// 캡처 완료 후 메인 스레드 양보 — 브라우저 멈춤 방지 핵심
	 				return _yieldTick();
	 			});
	 	})(i);
	 }
	 
	 return chain;
}

function _makeFallbackWrapper(text) {
	var w = document.createElement('div');
	w.className = 'pb-playground-wrapper';
	
	var l = document.createElement('span');
	l.className = 'pb-playground-label';
	l.appendChild(document.createTextNode(text));
	
	w.appendChild(l);
	return w;
}

/**
 * 코드 탭 정리
 * 탭 UI 제거 + 코드 블록 언어 레이블 삽입
 */
function _flattenCodeTabs(container) {
	// pb-codeblock 단위로 먼저 처리 (탭 UI 제거 전에 레이블 수집)
	var blocks = [].slice.call(container.querySelectorAll('.pb-codeblock'));
	for (var b = 0; b < blocks.length; b++) {
		var block = blocks[b];
		
		// 1. 탭 버튼 레이블 먼저 수집 (제거 전)
		var tabBtns = [].slice.call(block.querySelectorAll('.pb-tab-btn'));
		var tabLabels = tabBtns.map(function(btn) {
			return btn.getAttribute('aria-label') || btn.textContent.trim();
		});
		
		// 2. code.cm 수집
		var codeCms = [].slice.call(block.querySelectorAll('.code.cm'));
		if (codeCms.length === 0) continue;
		
		// 3. 각 code.cm에서 텍스트 미리 추출
		var codeItems = [];
		for (var c = 0; c < codeCms.length; c++) {
			var cm = codeCms[c];
			var langEl = cm.querySelector('[data-language]');
			var lang = tabLabels[c]
				? tabLabels[c].toUpperCase()
				: (langEl ? langEl.getAttribute('data-language').toUpperCase() : ('코드 ' + (c + 1)));
			
			var lines = [].slice.call(cm.querySelectorAll('.cm-line'));
			var codeText = lines.map(function(line) {
				return line.textContent;
			}).join('\n');
			
			codeItems.push({ lang: lang, text: codeText });
		}
		
		// 4. block 전체 내용 교체
		block.innerHTML = '';
		
		for (var ci = 0; ci < codeItems.length; ci++) {
			var label = document.createElement('span');
			label.className = 'pdf-code-lang-label';
			label.appendChild(document.createTextNode(codeItems[ci].lang));
			
			var pre = document.createElement('pre');
			pre.className = 'pdf-code-pre';
			pre.appendChild(document.createTextNode(codeItems[ci].text));
			
			var wrapper = document.createElement('div');
			wrapper.className = 'pdf-codeblock-item';
			wrapper.appendChild(label);
			wrapper.appendChild(pre);
			
			block.appendChild(wrapper);
		}
	}
	
	// 5. pb-codeblock 외부의 탭 UI / Copy 버튼 제거
	var removeSelectors = [
		'.pb-tablist', '.pb-toolbar-actions',
		'.pb-copy-btn', '.pb-codeblock-btn', '.pb-code-toolbar'
	];
	for (var s = 0; s < removeSelectors.length; s++) {
		var els = [].slice.call(container.querySelectorAll(removeSelectors[s]));
		for (var e = 0; e < els.length; e++) {
			if (els[e].parentNode) {
				els[e].parentNode.removeChild(els[e]);
			}
		}
	}
}

/**
 * 인라인 style 전체 제거 (렌더러 과부하 방지)
 *
 * [변경 이유]
 * eXBuilder6는 모든 레이아웃을 인라인 style로 제어함.
 * 속성별 수정으로는 누락이 발생하고 3.6MB DOM이 그대로 인쇄 렌더러에 전달되어 브라우저 멈춤 발생.
 * 인라인 style을 전체 제거하면 @media print CSS가 레이아웃을 전담하여 렌더러 부하 최소화.
 *
 * [주의]
 * _fixTables()가 반드시 이 함수 이전에 실행되어야 함.
 * (grid-area 인라인 값을 읽어 <table>로 변환한 뒤 style 제거)
 */
function _fixLayout(container) {
	// 모든 인라인 style 제거
	var allEls = [].slice.call(container.querySelectorAll('[style]'));
	for (var i = 0; i < allEls.length; i++) {
		allEls[i].removeAttribute('style');
	}
	
	// ── 추가: pb-print-section 자체 레이아웃 강제 블록화 ──
	var sections = [].slice.call(container.querySelectorAll('.pb-print-section'));
	for (var s = 0; s < sections.length; s++) {
		sections[s].style.cssText = 'display:block !important; position:static !important; width:100% !important; height:auto !important; overflow:visible !important;';
	}
}

/**
 * CSS Grid 테이블 → <table> 변환
 * grid-area 속성을 파싱해 행/열 구조를 분석, <table>로 재생성
 */
function _fixTables(container) {
	var tables = [].slice.call(container.querySelectorAll('.pb-table'));
	
	for (var t = 0; t < tables.length; t++) {
		var table = tables[t];
		var content = table.querySelector('.cl-layout-content');
		if (!content) continue;
		
		var cellEls = [].slice.call(content.querySelectorAll('.pb-th, .pb-td'));
		var cells = [];
		
		for (var c = 0; c < cellEls.length; c++) {
			var cell = cellEls[c];
			var style = cell.getAttribute('style') || '';
			var m = style.match(
				/grid-area:\s*(\d+)\s*\/\s*(\d+)\s*\/\s*span\s*(\d+)\s*\/\s*span\s*(\d+)/
			);
			if (!m) continue;
			
			cells.push({
				el: cell,
				rowStart: parseInt(m[1], 10),
				colStart: parseInt(m[2], 10),
				rowSpan: parseInt(m[3], 10),
				colSpan: parseInt(m[4], 10),
				isTh: (cell.className.indexOf('pb-th') !== -1)
			});
		}
		
		if (cells.length === 0) continue;
		
		// 행 그룹핑
		var rows = {};
		for (var ci = 0; ci < cells.length; ci++) {
			var key = cells[ci].rowStart;
			if (!rows[key]) rows[key] = [];
			rows[key].push(cells[ci]);
		}
		
		// 행 정렬
		var rowKeys = Object.keys(rows).sort(function(a, b) {
			return parseInt(a, 10) - parseInt(b, 10);
		});
		
		// <table> 생성
		var tbl = document.createElement('table');
		tbl.className = 'pb-table-print';
		tbl.style.cssText = 'width:100%;border-collapse:collapse;margin:6pt 0;font-size:9.5pt;';
		
		for (var ri = 0; ri < rowKeys.length; ri++) {
			var rowCells = rows[rowKeys[ri]].sort(function(a, b) {
				return a.colStart - b.colStart;
			});
			
			var tr = document.createElement('tr');
			
			for (var rci = 0; rci < rowCells.length; rci++) {
				var cell2 = rowCells[rci];
				var td = document.createElement(cell2.isTh ? 'th' : 'td');
				var textEl = cell2.el.querySelector('.cl-text');
				td.innerHTML = textEl ? textEl.innerHTML : '';
				
				if (cell2.colSpan > 1) td.colSpan = cell2.colSpan;
				if (cell2.rowSpan > 1) td.rowSpan = cell2.rowSpan;
				
				td.style.cssText = cell2.isTh
					? 'background:#f0f1f8;font-weight:700;color:#1a1a2e;padding:6pt 10pt;border:1pt solid #d4d6e8;vertical-align:middle;text-align:left;'
					: 'padding:5pt 10pt;border:1pt solid #e0e2ee;vertical-align:top;color:#333;';
				
				tr.appendChild(td);
			}
			
			tbl.appendChild(tr);
		}
		
		if (table.parentNode) {
			table.parentNode.replaceChild(tbl, table);
		}
	}
}

/**
 * DOM 경량화
 * eXBuilder6의 과도한 중첩 wrapper div를 제거하고
 * pb-* 콘텐츠 요소를 의미있는 HTML로 직접 변환.
 * 4MB+ DOM → 수백KB 수준으로 축소하여 인쇄 렌더러 부하 해소.
 *
 * 변환 규칙:
 *   pb-page-title  → <h1>텍스트</h1>
 *   pb-page-subtitle → <p class="pb-page-subtitle">텍스트</p>
 *   pb-title-h2    → <h2>텍스트</h2>
 *   pb-title-h3    → <h3>텍스트</h3>
 *   pb-title-h4    → <h4>텍스트</h4>
 *   pb-p           → <p>innerHTML</p>
 *   pb-list        → <p class="pb-list [타입]">innerHTML</p>
 *   pb-callout     → <div class="pb-callout [타입]">텍스트</div>
 *   pb-codeblock   → 내부 유지 (cm-editor 구조 필요)
 *   cl-aside / cl-layout-margin / cm-announced → 제거
 */
function _slimDOM(container) {
	
	// 1. 완전 제거 대상 (콘텐츠 없는 구조용 요소)
	var removeSelectors = [
		'.cl-aside',
		'.cl-layout-margin',
		'.cm-announced',
		'.pb-tablist',
		'.pb-toolbar-actions',
		'.pb-copy-btn',
		'.pb-codeblock-btn',
		'.pb-code-toolbar',
		'.cl-icon'
	];
	for (var rs = 0; rs < removeSelectors.length; rs++) {
		var toRemove = [].slice.call(container.querySelectorAll(removeSelectors[rs]));
		for (var r = 0; r < toRemove.length; r++) {
			if (toRemove[r].parentNode) {
				toRemove[r].parentNode.removeChild(toRemove[r]);
			}
		}
	}
	
	// 텍스트 추출 헬퍼 — .cl-text 내부 innerHTML 반환
	function _getInner(el) {
		var clText = el.querySelector('.cl-text');
		return clText ? clText.innerHTML : el.textContent || '';
	}
	
	// 요소 교체 헬퍼
	function _replace(orig, newEl) {
		if (orig.parentNode) {
			orig.parentNode.replaceChild(newEl, orig);
		}
	}
	
	// 2. pb-page-title → <h1>
	var pageTitles = [].slice.call(container.querySelectorAll('.pb-page-title'));
	for (var i = 0; i < pageTitles.length; i++) {
		var h1 = document.createElement('h1');
		h1.className = 'pb-page-title';
		h1.innerHTML = _getInner(pageTitles[i]);
		_replace(pageTitles[i], h1);
	}
	
	// 3. pb-page-subtitle → <p>
	var subtitles = [].slice.call(container.querySelectorAll('.pb-page-subtitle'));
	for (var i = 0; i < subtitles.length; i++) {
		var p = document.createElement('p');
		p.className = 'pb-page-subtitle';
		p.innerHTML = _getInner(subtitles[i]);
		_replace(subtitles[i], p);
	}
	
	// 4. pb-title-h2 → <h2>
	var h2s = [].slice.call(container.querySelectorAll('.pb-title-h2'));
	for (var i = 0; i < h2s.length; i++) {
		var h2 = document.createElement('h2');
		h2.className = 'pb-title-h2';
		h2.innerHTML = _getInner(h2s[i]);
		_replace(h2s[i], h2);
	}
	
	// 5. pb-title-h3 → <h3>
	var h3s = [].slice.call(container.querySelectorAll('.pb-title-h3'));
	for (var i = 0; i < h3s.length; i++) {
		var h3 = document.createElement('h3');
		h3.className = 'pb-title-h3';
		h3.innerHTML = _getInner(h3s[i]);
		_replace(h3s[i], h3);
	}
	
	// 6. pb-title-h4 → <h4>
	var h4s = [].slice.call(container.querySelectorAll('.pb-title-h4'));
	for (var i = 0; i < h4s.length; i++) {
		var h4 = document.createElement('h4');
		h4.className = 'pb-title-h4';
		h4.innerHTML = _getInner(h4s[i]);
		_replace(h4s[i], h4);
	}
	
	// 7. pb-p → <p>
	var pEls = [].slice.call(container.querySelectorAll('.pb-p'));
	for (var i = 0; i < pEls.length; i++) {
		var p = document.createElement('p');
		p.className = 'pb-p';
		p.innerHTML = _getInner(pEls[i]);
		_replace(pEls[i], p);
	}
	
	// 8. pb-list → <p class="pb-list [decimal/dash] [indent]">
	var listEls = [].slice.call(container.querySelectorAll('.pb-list'));
	for (var i = 0; i < listEls.length; i++) {
		var orig = listEls[i];
		var p = document.createElement('p');
		// 타입 클래스 보존 (decimal, dash, indent)
		var cls = 'pb-list';
		if (orig.className.indexOf('decimal') !== -1) cls += ' decimal';
		if (orig.className.indexOf('dash') !== -1) cls += ' dash';
		if (orig.className.indexOf('indent') !== -1) cls += ' indent';
		p.className = cls;
		p.innerHTML = _getInner(orig);
		_replace(orig, p);
	}
	
	// 9. pb-callout → 타이틀/본문 구분
	var callouts = [].slice.call(container.querySelectorAll('.pb-callout'));
	for (var i = 0; i < callouts.length; i++) {
		var orig = callouts[i];
		var div = document.createElement('div');
		var cls = 'pb-callout';
		if (orig.className.indexOf('callout-success') !== -1) cls += ' callout-success';
		if (orig.className.indexOf('callout-info') !== -1) cls += ' callout-info';
		if (orig.className.indexOf('callout-warning') !== -1) cls += ' callout-warning';
		if (orig.className.indexOf('indent') !== -1) cls += ' callout-indent';
		div.className = cls;
		
		// 타이틀 (pb-title-h4)
		var titleEl = orig.querySelector('.pb-title-h4');
		if (titleEl) {
			var titleDiv = document.createElement('div');
			titleDiv.className = 'pdf-callout-title';
			var titleText = titleEl.querySelector('.cl-text');
			titleDiv.innerHTML = titleText ? titleText.innerHTML : titleEl.textContent.trim();
			div.appendChild(titleDiv);
		}
		
		// 본문 (pb-p 단위로 분리)
		var paras = [].slice.call(orig.querySelectorAll('.pb-p'));
		if (paras.length > 0) {
			for (var pt = 0; pt < paras.length; pt++) {
				var paraDiv = document.createElement('p');
				paraDiv.className = 'pdf-callout-p';
				var paraText = paras[pt].querySelector('.cl-text');
				paraDiv.innerHTML = paraText ? paraText.innerHTML : paras[pt].textContent.trim();
				div.appendChild(paraDiv);
			}
		}
		else {
			// fallback: cl-text 전체 수집
			var texts = [].slice.call(orig.querySelectorAll('.cl-text'));
			for (var t = 0; t < texts.length; t++) {
				var pEl = document.createElement('p');
				pEl.className = 'pdf-callout-p';
				pEl.innerHTML = texts[t].innerHTML;
				div.appendChild(pEl);
			}
		}
		
		_replace(orig, div);
	}
	
	console.log('[pb-pdf] DOM 경량화 완료');
}
/**
 * PDF 인쇄용 스타일(CSS)을 문서의 <head>에 동적 추가 (IE11 호환)
 */
function _injectStyle() {
	var styleId = 'pb-pdf-print-styles';
	
	// 이미 동일한 ID의 스타일 태그가 존재하면 중복 추가하지 않고 종료
	if (document.getElementById(styleId)) return;
	
	var styleEl = document.createElement('style');
	styleEl.id = styleId;
	styleEl.type = 'text/css';
	
	// IE11 호환을 위해 배열의 join 메서드로 멀티라인 문자열 처리 및 호환 CSS 적용
	var cssText = [
		"@media print {",
		"",
		"  @page { size: A4 portrait; margin: 18mm 16mm; }",
		"",
		"  /* ========================================= */",
		"  /* 2. pb-print-root 내부 레이아웃 및 위치 해제 */",
		"  /* ========================================= */",
		"  #pb-print-root { display: block !important; width: 100%; background: #fff; }",
		"  #pb-print-root {",
		"    display: block !important;",
		"    visibility: visible !important;",
		"    position: fixed !important;",
		"    top: 0 !important;",
		"    left: 0 !important;",
		"    width: 100% !important;",
		"    background: #fff !important;",
		"    z-index: 99999 !important;",
		"  }",
		"",
		"  /* Grid 해제 — 전체가 아닌 cl-* 클래스만 대상 */",
		"  #pb-print-root .cl-layout,",
		"  #pb-print-root .cl-layout-content,",
		"  #pb-print-root .cl-layout-wrap,",
		"  #pb-print-root .cl-control,",
		"  #pb-print-root .cl-embeddedapp {",
		"    display: block !important;",
		"    position: static !important;",
		"    width: 100% !important;",
		"    height: auto !important;",
		"    overflow: visible !important;",
		"    grid-area: auto !important;",
		"    grid-template-columns: none !important;",
		"    grid-template-rows: none !important;",
		"  }",
		"",
		"  /* pb-guide-page 및 pb-print-section 위치 완전 초기화 */",
		"  #pb-print-root .pb-guide-page,",
		"  #pb-print-root .pb-print-section {",
		"    position: static !important;",
		"    /* IE11 호환: inset unset은 제외하고 개별 방향 auto 적용 */",
		"    top: auto !important;",
		"    left: auto !important;",
		"    right: auto !important;",
		"    bottom: auto !important;",
		"    width: 100% !important;",
		"    height: auto !important;",
		"    display: block !important;",
		"    overflow: visible !important;",
		"    z-index: auto !important;",
		"  }",
		"",
		"  /* span, img는 원래대로 */",
		"  #pb-print-root span { display: inline !important; }",
		"  #pb-print-root img { display: block !important; max-width: 100% !important; }",
		"",
		"  /* ========================================= */",
		"  /* 3. 개별 요소 인쇄/숨김 및 세부 스타일 지정 */",
		"  /* ========================================= */",
		"  #pb-print-root .pb-print-section { break-before: page; page-break-before: always; }",
		"  #pb-print-root .pb-print-section:first-child { break-before: auto; page-break-before: auto; }",
		"",
		"  #pb-print-root .pb-table-print, #pb-print-root .pb-callout, #pb-print-root .pb-playground-wrapper { break-inside: avoid; page-break-inside: avoid; }",
		"  #pb-print-root h1, #pb-print-root h2, #pb-print-root h3, #pb-print-root h4 { break-after: avoid; page-break-after: avoid; }",
		"",
		"  #pb-print-root .pb-tablist, #pb-print-root .pb-tab-btn, ",
		"  #pb-print-root .pb-toolbar-actions, #pb-print-root .pb-copy-btn, ",
		"  #pb-print-root .pb-codeblock-btn, #pb-print-root .pb-code-toolbar, ",
		"  #pb-print-root .cl-icon { display: none !important; }",
		"",
		"  /* 부가적인 레이어 속성 초기화 (IE11 호환) */",
		"  #pb-print-root .cl-layout, #pb-print-root .cl-layout-content, ",
		"  #pb-print-root .cl-layout-wrap, #pb-print-root .cl-control, ",
		"  #pb-print-root .cl-embeddedapp {",
		"    z-index: auto !important;",
		"    top: auto !important; right: auto !important; bottom: auto !important; left: auto !important;",
		"  }",
		"",
		"  #pb-print-root .cl-layout-content, #pb-print-root .cl-layout-wrap, ",
		"  #pb-print-root [style*='grid-area'], #pb-print-root [role='presentation'], ",
		"  #pb-print-root .cl-text { display: block !important; }",
		"",
		"  /* 텍스트/리스트 스타일 */",
		"  #pb-print-root .pb-page-title .cl-text { font-size: 22pt; font-weight: 700; color: #111; display: block; border-bottom: 2pt solid #1a1a2e; padding-bottom: 8pt; margin-bottom: 14pt; }",
		"  #pb-print-root .pb-page-subtitle .cl-text { font-size: 10.5pt; color: #555; line-height: 1.65; display: block; margin-bottom: 14pt; }",
		"  #pb-print-root .pb-title-h2 .cl-text { font-size: 14pt; font-weight: 700; color: #1a1a2e; display: block; margin-top: 18pt; margin-bottom: 6pt; padding-bottom: 3pt; border-bottom: 1pt solid #e0e2f0; }",
		"  #pb-print-root .pb-title-h3 .cl-text { font-size: 12pt; font-weight: 600; color: #2a2a3e; display: block; margin-top: 12pt; margin-bottom: 4pt; }",
		"  #pb-print-root .pb-title-h4 .cl-text { font-size: 10.5pt; font-weight: 600; color: #444; display: block; margin-top: 8pt; margin-bottom: 3pt; }",
		"  #pb-print-root .pb-p .cl-text { font-size: 10pt; color: #333; line-height: 1.7; display: block; margin-bottom: 5pt; }",
		"  #pb-print-root .pb-list .cl-text { font-size: 10pt; color: #333; line-height: 1.7; display: block; margin-bottom: 3pt; }",
		"  #pb-print-root .pb-list.decimal .cl-text::before { content: '· '; color: #5c6bff; font-weight: 700; }",
		"  #pb-print-root .pb-list.dash .cl-text::before { content: '— '; color: #999; }",
		"  #pb-print-root .pb-list.indent { padding-left: 14pt !important; }",
		"  #pb-print-root span.pb-point { color: #3a4fd8; font-weight: 600; }",
		"  #pb-print-root span.pb-code { font-family: 'Consolas','Courier New',monospace; font-size: 9pt; background: #f3f4f8; padding: 1pt 4pt; border-radius: 3pt; color: #d63864; }",
		"  #pb-print-root span.strong { font-weight: 700; }",
		"",
		"  /* Callout 스타일 */",
		"  #pb-print-root .pb-callout { padding: 9pt 13pt; border-radius: 5pt; margin: 7pt 0; font-size: 10pt; line-height: 1.6; }",
		"  #pb-print-root .callout-success { background: #f0faf4; border-left: 4pt solid #2a9d5c; }",
		"  #pb-print-root .callout-info { background: #f0f4ff; border-left: 4pt solid #5c6bff; }",
		"  #pb-print-root .callout-warning { background: #fff8f0; border-left: 4pt solid #e07a00; }",
		"  #pb-print-root .callout-indent { background: #f8f8f8; border-left: 3pt solid #ccc; }",
		"",
		"  /* 코드블록 공통 및 신규 스타일 */",
		"  #pb-print-root .pb-codeblock { margin: 5pt 0 9pt; border: 1pt solid #e0e2ee; border-radius: 5pt; overflow: hidden; background: #fafafa; break-inside: avoid; page-break-inside: avoid; }",
		"  #pb-print-root .pdf-codeblock-item { margin-bottom: 4pt; }",
		"  #pb-print-root .pdf-code-lang-label { display: block !important; font-size: 8.5pt; font-weight: 700; color: #5c6bff; background: #f0f1f8; padding: 4pt 10pt; border-bottom: 1pt solid #e0e2ee; letter-spacing: 0.6px; text-transform: uppercase; font-family: -apple-system, sans-serif; }",
		"  #pb-print-root .pdf-code-pre { display: block; margin: 0; padding: 8pt 12pt; font-family: 'Consolas', 'D2Coding', 'Courier New', monospace; font-size: 8.5pt; line-height: 1.55; white-space: pre-wrap; word-break: break-all; color: #1e1e1e; background: #fafafa; }",
		"",
		"  /* 기존 CodeMirror 스타일 (필요시 병행 사용) */",
		"  #pb-print-root .cm-editor, #pb-print-root .cm-scroller, #pb-print-root .cm-content { overflow: visible !important; height: auto !important; max-height: none !important; background: transparent !important; }",
		"  #pb-print-root .cm-content { font-family: 'Consolas','D2Coding','Courier New',monospace !important; font-size: 8.5pt !important; line-height: 1.55 !important; padding: 8pt 12pt !important; white-space: pre-wrap !important; word-break: break-all !important; color: #1e1e1e !important; }",
		"  #pb-print-root .cm-line { display: block !important; min-height: 0 !important; }",
		"  #pb-print-root .cm-announced { display: none !important; }",
		"  #pb-print-root .ͼh { color: #0070c1 !important; }",
		"  #pb-print-root .ͼd { color: #a31515 !important; }",
		"  #pb-print-root .ͼl { color: #6a9955 !important; font-style: italic; }",
		"  #pb-print-root .ͼi { color: #001080 !important; }",
		"  #pb-print-root .cm-matchingBracket { color: #0070c1 !important; background: none !important; }",
		"",
		"  #pb-print-root .pb-playground-wrapper { margin: 7pt 0; border: 1pt solid #d0d4e8; border-radius: 5pt; background: #f8f9fc; padding: 10pt; break-inside: avoid; page-break-inside: avoid; }",
		"  #pb-print-root .pb-playground-wrapper img { max-width: 100%; height: auto; display: block; border-radius: 3pt; }",
		"  #pb-print-root .pb-playground-label { font-size: 8.5pt; font-weight: 600; color: #8890cc; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 7pt; display: block; font-family: -apple-system, sans-serif; }",
		"}"
	].join('\n');
	
	// 구형 브라우저(IE 포함) 스타일 주입 방어 로직
	if (styleEl.styleSheet) {
		styleEl.styleSheet.cssText = cssText;
	}
	else {
		styleEl.appendChild(document.createTextNode(cssText));
	}
	
	// head 태그 검색 및 주입
	var head = document.head || document.getElementsByTagName('head')[0];
	head.appendChild(styleEl);
}