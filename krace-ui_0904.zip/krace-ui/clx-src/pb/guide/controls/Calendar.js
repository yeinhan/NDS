/************************************************
 * @file      _Template.js
 * @author    ryu
 * @created   2026. 4. 6. 오후 2:02:12
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/

/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyLoad(e){
	
	// 기간선택 캘린더
	var calendar = app.lookup("calRange");
	calendar.values = [moment().subtract(-2, "day").format("YYYYMMDD"), moment().subtract(-5, "day").format("YYYYMMDD")];
	
	// 일정 캘린더
	var scheduler = app.lookup("calAnny");
	scheduler.addItem(new cpr.controls.CalendarItem("일정1", moment().subtract(-2, "day"), moment().subtract(-2, "day"), 'item1'));
	scheduler.addItem(new cpr.controls.CalendarItem("일정2", moment().subtract(-2, "day"), moment().subtract(-4, "day"), 'item2'));
	scheduler.addItem(new cpr.controls.CalendarItem("일정3", moment().subtract(-4, "day"), moment().subtract(-4, "day"), 'item3'));
	scheduler.addAnniversary({date: moment().subtract(-4, "day").format("YYYYMMDD"), label: "공휴일", unselectable: false});
}
