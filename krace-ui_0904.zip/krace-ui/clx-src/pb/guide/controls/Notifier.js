/************************************************
 * @file      Notifier.js
 * @author    ryu
 * @created   2026. 4. 6. 오후 2:02:12
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/

/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyLoad(e){
	var notifier = new cpr.controls.Notifier("notifier");
	notifier.scope = "app";
	//notifier.maxNotifyCount = 1;
	notifier.close = true;
	notifier.delay = 2147483647;
	notifier.infoClose = true;
	notifier.infoDelay = 2147483647;
	notifier.successClose = true;
	notifier.successDelay = 2147483647;
	notifier.warningClose = true;
	notifier.warningDelay = 2147483647;
	notifier.dangerClose = true;
	notifier.dangerDelay = 2147483647;
	
	app.floatControl(notifier, {
		"top": "24px",
		"right": "24px",
		"width": "360px",
		"height": "40px"
	});
}

/**
 * @function 
 * @desc    "알림 표시" 버튼(post)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onPostClick(e){
	/** @type cpr.controls.Notifier */
	var notifier = app.lookup("notifier");
	
	var type = e.control.userAttr("type");
	if (type === "info") {
		notifier.info("메세지를 표시합니다");
	} else if (type === "success") {
		notifier.success("메세지를 표시합니다");
	} else if (type === "warning") {
		notifier.warning("메세지를 표시합니다");
	} else if (type === "danger") {
		notifier.danger("메세지를 표시합니다");
	} else {
		notifier.notify("메세지를 표시합니다");
	}
}
