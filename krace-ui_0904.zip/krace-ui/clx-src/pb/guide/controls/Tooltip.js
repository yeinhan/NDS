/************************************************
 * @file      Tooltip.js
 * @author    ryu
 * @created   2026. 4. 6. 오후 2:02:12
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/



/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyLoad(e){
	// 특정 컨트롤에 툴팁 매니저 적용
	cpr.core.Platform.INSTANCE.tooltipManager.registerTooltip(app.lookup("tooltip"), function(tooltipOwner) {
		var output = new cpr.controls.Output();
		output.value = tooltipOwner.tooltip;
		return output;
	});
	
	// 모든 컨트롤에 툴팁 매니저 적용
//	cpr.core.Platform.INSTANCE.tooltipManager.setDefaultTooltip(function(tooltipOwner) {
//		var output = new cpr.controls.Output();
//		output.value = tooltipOwner.tooltip;
//		return output;
//	});
}

/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 언로드되기 전에 발생하는 이벤트 입니다. 취소할 수 있습니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyBeforeUnload(e){
	// 특정 컨트롤에 연결된 툴팁 제거
	cpr.core.Platform.INSTANCE.tooltipManager.unregisterTooltip(app.lookup("tooltip"));
}
