/************************************************
 * @file      UITemplate.js
 * @author    ryu
 * @created   2026. 4. 20. 오전 9:41:31
 * * [History]
 * - 2026. 4. 20. : 최초 생성 (ryu)
 ************************************************/

/**
 * @function 
 * @desc    루트 컨테이너에서 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 * @param   {cpr.events.CEvent} e 이벤트 객체
 */
function onBodyLoad(e) {
	app.getContainer().style.css({ "max-width": "unset", "padding": "24px" });
}