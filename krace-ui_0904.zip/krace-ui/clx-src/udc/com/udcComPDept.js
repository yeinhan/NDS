/************************************************
 * udcCmnPParty.js
 * Created at 2019. 1. 17.
 *
 ************************************************/
var util = createCommonUtil();

var openedByChange = false;

/**
 * UDC 컨트롤이 그리드의 뷰 모드에서 표시할 텍스트를 반환합니다.
 */
exports.getText = function(){
	return app.lookup("ipbDeptCd").value;
};

/*
 * Body에서 property-change 이벤트 발생 시 호출.
 * 앱의 속성이 변경될 때 발생하는 이벤트 입니다.
 */
function onBodyPropertyChange(/* cpr.events.CPropertyChangeEvent */ e){
	if(e.property == "required"){
		var vcIpbCode = app.lookup("ipbDeptCd");
		//필수 입력 체크 조건 설정
		if(app.getAppProperty("required") === "Y"){
			vcIpbCode.fieldLabel = app.getHost().fieldLabel;
			vcIpbCode.userAttr("required","Y");
		} else {
			vcIpbCode.userAttr("required","");
		}
	}
}

/*
 * 구성원ID 조회 [btnPopParty] 버튼에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onBtnPopPartyClick(/* cpr.events.CMouseEvent */ e){
	// 검색어를 입력하고 팝업버튼을 누른경우, 이미 change 이벤트에 의해 팝업이 떠있기 때문에 다시 띄우지 않는다.
	if(openedByChange == true) {
		return false;
	}
	
	//팝업 호출
	doOpenPartyPopup(app.lookup("ipbDeptCd").value);
}

/*
 * 인풋 박스에서 value-change 이벤트 발생 시 호출.
 * 변경된 value가 저장된 후에 발생하는 이벤트.
 */
function onIpbPartyIdValueChange(/* cpr.events.CValueChangeEvent */ e){
	// 팝업호출 중인 경우에는 이벤트 Skip...
	if(openedByChange == true){
		return false;
	}
	
	// 변경된 값
	var vsDeptCd = e.newValue;
	// 입력내용 삭제시 팝업없이 관련내용 삭제 -> 삭제인데도, 아래의 체크처리가 이루워짐에 따라 불필요한 메시지 호출됨으로 막아준다.
	if(vsDeptCd == ""){
		// 데이터 Clear
		clearCallback();
		// 사용자 이벤트 Dispatch
		app.dispatchEvent(new cpr.events.CUIEvent("search"));
		return false;
	}
	
	// 검색 파라메터 셋팅
	var voDmParam = app.lookup("dmParam");
	voDmParam.setValue("strDeptCd", vsDeptCd);
	voDmParam.setValue("strDeptDiv", app.getAppProperty("iDeptDiv"));
	voDmParam.setValue("strDeptNm", app.getAppProperty("iName"));
	
	util.Submit.send(app, "subList",  function(pbSuccess){
		if(pbSuccess) {
			var dsDept = app.lookup("dsDept");
			// 검색결과가 1건이면 팝업없이 바로 값세팅
			if(dsDept.getRowCount() == 1){

				AppUtil.setAppProperty(app, "oDeptCd", dsDept.getValue(0, "DEPT_CD"));
				AppUtil.setAppProperty(app, "oDeptNm", dsDept.getValue(0, "DEPT_NM"));
				AppUtil.setAppProperty(app, "oUpDeptCd", dsDept.getValue(0, "UP_DEPT_CD"));
				AppUtil.setAppProperty(app, "oUpDeptNm", dsDept.getValue(0, "UP_DEPT_NM"));
				AppUtil.setAppProperty(app, "oShortNm", dsDept.getValue(0, "SHORT_NM"));
				AppUtil.setAppProperty(app, "oStDt", dsDept.getValue(0, "ST_DT"));
				AppUtil.setAppProperty(app, "oEndDt", dsDept.getValue(0, "END_DT"));
				AppUtil.setAppProperty(app, "oDeptDivRcd", dsDept.getValue(0, "DEPT_DIV_RCD"));
				AppUtil.setAppProperty(app, "oDeptDivNm", dsDept.getValue(0, "DEPT_DIV_NM"));
				AppUtil.setAppProperty(app, "oMngItem1", dsDept.getValue(0, "MNG_ITEM_1"));
				AppUtil.setAppProperty(app, "oMngItem2", dsDept.getValue(0, "MNG_ITEM_2"));
				AppUtil.setAppProperty(app, "oMngItem3", dsDept.getValue(0, "MNG_ITEM_3"));
				AppUtil.setAppProperty(app, "oMngItem4", dsDept.getValue(0, "MNG_ITEM_4"));
				AppUtil.setAppProperty(app, "oMngItem5", dsDept.getValue(0, "MNG_ITEM_5"));
				
				app.lookup("ipbDeptCd").putValue(dsDept.getValue(0, "DEPT_CD"));
				
				app.dispatchEvent(new cpr.events.CUIEvent("search"));
			}else{
				// 검색결과가 여러건이면... 팝업 호출
				clearCallback();
				doOpenPartyPopup(vsDeptCd);
			}
		}
	});
}

/**
 * 팝업을 호출한다.
 */
function doOpenPartyPopup(psDeptCd){
	openedByChange = true;
	
	//초기 파라메터 셋팅
	var initValue = {
		strDeptCd: psDeptCd,
		strDeptDiv: app.getAppProperty("iDeptDiv"),
		strDeptNm: app.getAppProperty("iName")
	};
	
	util.Dialog.open(app, "app/com/comPDept", 750, 560, function(/**@type cpr.events.CUIEvent */e){
		/**@type cpr.controls.Dialog*/
		var dialog = e.control;
		var returnValue = dialog.returnValue;
		if(returnValue != null){
			
			AppUtil.setAppProperty(app, "oDeptCd", returnValue.DEPT_CD);
			AppUtil.setAppProperty(app, "oDeptNm", returnValue.DEPT_NM);
			AppUtil.setAppProperty(app, "oUpDeptCd", returnValue.UP_DEPT_CD);
			AppUtil.setAppProperty(app, "oUpDeptNm", returnValue.UP_DEPT_NM);
			AppUtil.setAppProperty(app, "oShortNm", returnValue.SHORT_NM);
			AppUtil.setAppProperty(app, "oStDt", returnValue.ST_DT);
			AppUtil.setAppProperty(app, "oEndDt", returnValue.END_DT);
			AppUtil.setAppProperty(app, "oDeptDivRcd", returnValue.DEPT_DIV_RCD);
			AppUtil.setAppProperty(app, "oDeptDivNm", returnValue.DEPT_DIV_NM);
			AppUtil.setAppProperty(app, "oMngItem1", returnValue.MNG_ITEM_1);
			AppUtil.setAppProperty(app, "oMngItem2", returnValue.MNG_ITEM_2);
			AppUtil.setAppProperty(app, "oMngItem3", returnValue.MNG_ITEM_3);
			AppUtil.setAppProperty(app, "oMngItem4", returnValue.MNG_ITEM_4);
			AppUtil.setAppProperty(app, "oMngItem5", returnValue.MNG_ITEM_5);
			
			app.lookup("ipbDeptCd").value = returnValue.DEPT_NM;
			
			app.dispatchEvent(new cpr.events.CUIEvent("search"));
		}
		
		openedByChange = false;
		
	}, initValue);
}

//App 속성값 Clear
function clearCallback(){
	app.lookup("ipbDeptCd").putValue("");
	
	AppUtil.setAppProperty(app, "oDeptCd", "");
	AppUtil.setAppProperty(app, "oDeptNm", "");
	AppUtil.setAppProperty(app, "oUpDeptCd", "");
	AppUtil.setAppProperty(app, "oUpDeptNm", "");
	AppUtil.setAppProperty(app, "oShortNm", "");
	AppUtil.setAppProperty(app, "oStDt", "");
	AppUtil.setAppProperty(app, "oEndDt", "");
	AppUtil.setAppProperty(app, "oDeptDivRcd", "");
	AppUtil.setAppProperty(app, "oDeptDivNm", "");
	AppUtil.setAppProperty(app, "oMngItem1", "");
	AppUtil.setAppProperty(app, "oMngItem2", "");
	AppUtil.setAppProperty(app, "oMngItem3", "");
	AppUtil.setAppProperty(app, "oMngItem4", "");
	AppUtil.setAppProperty(app, "oMngItem5", "");
}

/*
 * 인풋 박스에서 keydown 이벤트 발생 시 호출.
 * 사용자가 키를 누를 때 발생하는 이벤트.
 */
function onIpbPartyIdKeydown(/* cpr.events.CKeyboardEvent */ e){
	if(e.keyCode == cpr.events.KeyCode.ENTER){
		e.preventDefault();
	}
}
