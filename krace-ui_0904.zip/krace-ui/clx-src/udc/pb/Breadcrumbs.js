/************************************************
 * Breadcrumbs.js
 * Created at 2022. 5. 26. 오전 10:25:58.
 *
 * @author ryu
 ************************************************/

/**
 * 내비게이션 구분자
 * @type {String}
 */
var msSeparator = ",";

var util = createCommonUtil();

/**
 * 섹션 네비게이션을 부모의 루트 컨테이너의 섹션 타이틀을 토대로 동적으로 생성합니다.
 */
function createSectionNavigation() {
	var voHostAppIns = app.getHostAppInstance();
	if (voHostAppIns){
		var vcGrpHostCont = voHostAppIns.getContainer();
		var vcGrpSctNav = app.lookup("grpSctNav");
		vcGrpHostCont.getAllRecursiveChildren(false).filter(function(each){
			return each instanceof udc.pb.SectionTitle;
		}).forEach(function(each){
			var vcSectionNav = new cpr.controls.Button();
			vcSectionNav.value = each.title;
			vcSectionNav.style.setClasses(["btn", "btn-at"]);
			vcSectionNav.addEventListener("click", function(e){
			    // 메인 top영역 + mdi 영역 + 스크롤 버튼 영역 제외
			    var sTop = each.getActualRect().top - 80;
				vcGrpHostCont.scrollTo(0, sTop);
			});
			vcGrpSctNav.addChild(vcSectionNav, {
				autoSize: "width",
				height: "34px"
			});
		});
	}
}

/*
 * 루트 컨테이너에서 load 이벤트 발생 시 호출.
 * 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 */
function onBodyLoad(e){
	//어플리케이션 메뉴 정보
	var voMenuInfo = util.Main.getMenuInfo(app);
	var vsMenuNm = voMenuInfo.get("MENU_NM");
	if(!ValueUtil.isNull(vsMenuNm)) {
		app.lookup("optTitle").value = vsMenuNm;
	}
		
	cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function(){
		createSectionNavigation();
	});
}

/*
 * 체크 박스에서 value-change 이벤트 발생 시 호출.
 * CheckBox의 value를 변경하여 변경된 값이 저장된 후에 발생하는 이벤트.
 */
function onCbxBkmrkValueChange(e){
	var cbxBkmrk = e.control;
	app.setAppProperty("bookmark", cbxBkmrk.checked, false);
}

/*
 * "앱열기" 버튼(btnPrvw)에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onBtnPrvwClick(e){
	util.procEb6Privew(app);
}

/*
 * "PDF다운" 버튼(btnPdfDown)에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onBtnPdfDownClick(e){
	var btnPdfDown = e.control;
	
	var voResourceLoader = new cpr.core.ResourceLoader();
	voResourceLoader.addScript("thirdparty/html2pdf/dist/html2pdf.bundle.min.js");
	voResourceLoader.addScript("thirdparty/jsPdf/jspdf.min.js");
	voResourceLoader.load().then(function(input) {
		util.showLoadMask(app);
		
		var hostAppInst = app.getHostAppInstance();
		if(hostAppInst.hasAppMethod("changeLayoutAuto")) {
			hostAppInst.callAppMethod("changeLayoutAuto", "none");
		}
		
		cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
			var vsGrpIds = app.getAppProperty("exportPdfGrpIds");

			if(ValueUtil.isNull(vsGrpIds)){
				var hostContainer = hostAppInst.getContainer();
				hostContainer.htmlAttr("uuid", hostContainer.uuid);
				cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function(){
					exportPdf(hostContainer);
				});
			} else {
				var vaGrpIds = vsGrpIds.split(",");
				vaGrpIds.forEach(function(each, idx){
					if(vaGrpIds.length-1 == idx){
						var pbLastIdx = true;
					}
					
					var hostCtrl = hostAppInst.lookup(each.trim());
					hostCtrl.htmlAttr("uuid", hostCtrl.uuid);
					cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function(){
						exportPdf(hostCtrl, true, pbLastIdx);
					});
				});
			}
		});
	});
	
}


/**
 * 앱 컨텐츠를 pdf 내보내기한다.<br>
 * <br>
 * 참고 url
 * https://developer.mozilla.org/ko/docs/Web/HTML/Element/canvas<br>
 * https://github.com/eKoopmans/html2pdf.js/projects/5<br>
 * https://ekoopmans.github.io/html2pdf.js<br>
 * https://rawgit.com/MrRio/jsPDF/master/docs/jspdf.js.html
 * @param {cpr.controls.UIControl} control
 */
function exportPdf(control, isMultiple, isLastIdx){
	var voHostAppIns = app.getHostAppInstance();
	var targetDOM = document.querySelector("div[data-usr-uuid = \""+control.htmlAttr("uuid") + "\"]");
	if(targetDOM) {
		// PDf 저장 시, 로드마스크가 포함되지 않도록 UI 즉시 실행
		util.hideLoadMask(app);
		cpr.core.DeferredUpdateManager.INSTANCE.update();
		
		html2pdf().from(targetDOM).set({
			margin: 10,
			filename: voHostAppIns.app.title + '.pdf',
			html2canvas: {
				scale: 1
			},
			jsPDF: {
				orientation: 'portrait',
				unit: 'mm',
				format: 'a4',
				compressPDF: true
			}
		}).save().then(function(){
			if(isMultiple){
				if(isLastIdx){
					if(voHostAppIns.hasAppMethod("changeLayoutAuto")) {
						voHostAppIns.callAppMethod("changeLayoutAuto", "height");
					}
				}
			} else {
				if(voHostAppIns.hasAppMethod("changeLayoutAuto")) {
					voHostAppIns.callAppMethod("changeLayoutAuto", "height");
				}
			}
		});
	} else {
		console.warn("Can't find PDF Element!!");
		util.hideLoadMask(app);
	}
}

