/************************************************
 * @file      Dialog.js
 * @author    ryu
 * @created   2026. 4. 6. 오후 2:02:12
 * * [History]
 * - 2026. 4. 6. : 최초 생성 (ryu)
 ************************************************/

var util = createCommonUtil();

/**
 * @function 
 * @desc    "다이얼로그 열기" 버튼(open)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onOpenClick(e){
	var newApp = new cpr.core.App("__guide_tmp__", {
		onCreate: function(app, exports){
			var container = app.getContainer();
		}
	});
	
	util.Dialog.open(app, "pb/guide/controls/Untitled", 800, -1, null);
	
	
//	app.getRootAppInstance().dialogManager.openDialog(newApp, "__pop__", {width: 1024, height: 600}, function(dialog) {
//		dialog.headerTitle = "타이틀";
//	});
}

/**
 * @function 
 * @desc    "다이얼로그 열기" 버튼(confirm)에서 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 * @param   {cpr.events.CMouseEvent} e 이벤트 객체
 */
function onConfirmClick(e){
	var newApp = new cpr.core.App("__guide_tmp__", {
		onCreate: function(app, exports){
			var container = app.getContainer();
		}
	});
	
	app.getRootAppInstance().dialogManager.openDialog(newApp, "__pop__", {width: 360, height: 200}, function(dialog) {
		dialog.headerTitle = "알림";
		dialog.style.addClass("modal");
	});
}
