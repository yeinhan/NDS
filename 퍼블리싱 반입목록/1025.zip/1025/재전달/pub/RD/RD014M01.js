/************************************************
 * RD014M01.js
 * @프로그램설명 :
 *
 * @작성일자 :  2026. 10. 18..
 * @작성자 : yein
 *
 * @수정이력 : 수정일자 (수정자) 수정내용
 ************************************************/

/************************************************
 ** 글로벌 변수, 상수변수
 ************************************************/
/** 차트 색상 (범례 sub-badge의 square-dot 색상과 동일) */
var CHART_COLOR = {
  SALES : "#2B7FFF", // 매출총계
  AXIS  : "#90A1B9", // 축 라벨
  LINE  : "#E2E8F0"  // 그리드 라인
};

/** 매출 단위 (억원) */
var SALES_UNIT = 100000000;


/************************************************
 ** 글로벌 함수
 ************************************************/


/************************************************
 ** 파일내 로컬변수 선언
 ************************************************/
var util = createCommonUtil();

/** echarts 인스턴스 */
var moChart = null;

/** echarts 라이브러리 로드 Promise (화면 내 1회만 로드) */
var moEchartsLoader = null;

/**
 * 차트 영역 크기 변화 감지.
 * window resize 만으로는 LNB 접기/펼치기 등 컨테이너만 바뀌는 경우를 감지하지 못하므로
 * 쉘 컨텐츠 DOM 자체의 크기 변화를 감지해 차트를 리사이즈한다.
 */
var moResizeObserver = new ResizeObserver(function(paEntries) {
  if (app.disposed) {
    moResizeObserver.disconnect();
    return;
  }
  paEntries.forEach(function(each) {
    var voChart = echarts.getInstanceByDom(each.target);
    // 숨김 상태(0 크기)에서는 리사이즈하지 않음 - 다시 보일 때 감지됨
    if (voChart && each.contentRect.width > 0 && each.contentRect.height > 0) {
      voChart.resize();
    }
  });
});

/************************************************
 ** 사용자 정의 자바스크립트 함수를 기술
 ************************************************/

/**
 * echarts 라이브러리를 지연 로드합니다.
 * @return {Promise}
 */
function loadEcharts() {
  if (window.echarts) {
    return Promise.resolve();
  }
  if (!moEchartsLoader) {
    moEchartsLoader = cpr.core.ResourceLoader.loadScript("thirdparty/echarts/echarts.min.js");
  }
  return moEchartsLoader;
}

/**
 * 매출추이 꺾은선 차트 옵션 (가로축 일자 · 세로축 매출총계(억원))
 * @return {Object}
 */
function getSalesTrendOption() {
  /** @type cpr.data.DataSet */
  var vcDs = app.lookup("ds1");
  var vaXData = vcDs.getColumnData("column1").map(function(each) {
    var vsYmd = String(each);
    return vsYmd.substr(0, 4) + "-" + vsYmd.substr(4, 2) + "-" + vsYmd.substr(6, 2);
  });
  var vaYData = vcDs.getColumnData("column2").map(function(each) {
    return Math.round(Number(each) / SALES_UNIT);
  });
  var voTextStyle = {
    fontFamily : "Pretendard, sans-serif",
    fontSize : 13,
    color : CHART_COLOR.AXIS
  };

  return {
    // 범례는 타이틀 우측 sub-badge 로 표시하므로 차트 범례는 숨김
    legend : { show : false },
    grid : { top : 28, right : 24, bottom : 8, left : 8, containLabel : true },
    tooltip : {
      trigger : "axis",
      valueFormatter : function(pnValue) {
        return Number(pnValue).toLocaleString() + "억";
      }
    },
    xAxis : {
      type : "category",
      data : vaXData,
      axisLine : { lineStyle : { color : CHART_COLOR.LINE } },
      axisTick : { show : false },
      axisLabel : { fontFamily : voTextStyle.fontFamily, fontSize : 14, color : "#45556C", margin : 14 }
    },
    yAxis : {
      type : "value",
      axisLabel : {
        fontFamily : voTextStyle.fontFamily,
        fontSize : voTextStyle.fontSize,
        color : voTextStyle.color,
        formatter : function(pnValue) {
          return pnValue == 0 ? "0" : Number(pnValue).toLocaleString() + "억";
        }
      },
      splitLine : { lineStyle : { color : CHART_COLOR.LINE, type : "dashed" } }
    },
    series : [{
      name : "매출총계",
      type : "line",
      data : vaYData,
      color : CHART_COLOR.SALES,
      symbol : "none",
      lineStyle : { width : 2 },
      // 각 점 위에 값 표시
      label : {
        show : true,
        position : "top",
        fontFamily : voTextStyle.fontFamily,
        fontSize : 13,
        color : "#0F172B",
        formatter : function(poParam) {
          return Number(poParam.value).toLocaleString();
        }
      }
    }]
  };
}

/**
 * 쉘 컨텐츠 영역에 차트를 그립니다.
 * @param {HTMLElement} poContent 쉘 컨텐츠 DOM
 */
function drawChart(poContent) {
  loadEcharts().then(function() {
    if (app.disposed) {
      return;
    }
    if (moChart) {
      moResizeObserver.unobserve(moChart.getDom());
      moChart.dispose();
    }
    // 쉘은 레이아웃 아이템이라 min-width:auto 기본값 때문에 내부 캔버스 너비 이하로 줄어들지 않음.
    // overflow:hidden 으로 최소너비를 0 으로 만들어 영역이 줄어들 때 ResizeObserver 가 감지할 수 있게 한다.
    poContent.style.overflow = "hidden";
    moChart = echarts.init(poContent);
    moChart.setOption(getSalesTrendOption());
    moResizeObserver.observe(poContent);
  });
}

/**
 * 데이터 변경 후 차트를 다시 그립니다. (조회 서브미션 receive 등에서 호출)
 */
function refreshChart() {
  if (moChart) {
    moChart.setOption(getSalesTrendOption(), true);
  }
}


/************************************************
 ** 자동으로 생성되는 이벤트 자바스크립트 함수를 배치
 ** (이벤트 생성시 자동으로 스크립트 함수 하위에 표시)
 ************************************************/


/*
 * 쉘에서 load 이벤트 발생 시 호출.
 * 쉘이 그려진 후 내용을 작성하는 이벤트.
 */
function onShlSalesTrendLoad(e) {
  drawChart(e.content);
}

/*
 * 쉘에서 init 이벤트 발생 시 호출.
 * 쉘 컨트롤의 내용이 그려지기 전 초기화 하는 이벤트.
 * (탭 전환 등으로 쉘이 다시 그려질 때 기존 차트를 다시 그림)
 */
function onShlSalesTrendInit(e) {
  if (e.content && moChart) {
    e.preventDefault();
    cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
      drawChart(e.content);
    });
  }
}
