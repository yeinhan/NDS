/************************************************
 * ZH021T01.js
 * @프로그램설명 : 
 *
 * @작성일자 :  2026. 10. 10..
 * @작성자 : yein
 *
 * @수정이력 : 수정일자 (수정자) 수정내용
 ************************************************/

/************************************************
 ** 글로벌 변수, 상수변수
 ************************************************/ 
/** 차트 색상 (범례 sub-badge의 square-dot 색상과 동일) */
var CHART_COLOR = {
  INQ  : "#2B7FFF", // 조회 건수
  SAVE : "#00D492", // 저장 건수
  AXIS : "#90A1B9", // 축 라벨
  LINE : "#E2E8F0"  // 그리드 라인
};


/************************************************
 ** 글로벌 함수
 ************************************************/ 


/************************************************
 ** 파일내 로컬변수 선언  
 ************************************************/ 
var util = createCommonUtil();

/** echarts 인스턴스 (쉘 ID → 차트) */
var moCharts = {};

/** echarts 라이브러리 로드 Promise (화면 내 1회만 로드) */
var moEchartsLoader = null;

/**
 * 차트 영역 크기 변화 감지.
 * window resize 만으로는 LNB 접기/펼치기, 탭 전환 등 컨테이너만 바뀌는 경우를 감지하지 못하므로
 * 쉘 컨텐츠 DOM 자체의 크기 변화를 감지해 차트를 리사이즈한다.
 */
var moResizeObserver = new ResizeObserver(function(paEntries) {
  if (app.disposed) {
    moResizeObserver.disconnect();
    return;
  }
  paEntries.forEach(function(each) {
    var voChart = echarts.getInstanceByDom(each.target);
    // 숨김 상태(0 크기)에서는 리사이즈하지 않음 - 다시 보일 때 감지됨
    if (voChart && each.contentRect.width > 0 && each.contentRect.height > 0) {
      voChart.resize();
    }
  });
});

/************************************************
 ** 사용자 정의 자바스크립트 함수를 기술 
 ************************************************/ 

/**
 * echarts 라이브러리를 지연 로드합니다.
 * @return {Promise}
 */
function loadEcharts() {
  if (window.echarts) {
    return Promise.resolve();
  }
  if (!moEchartsLoader) {
    moEchartsLoader = cpr.core.ResourceLoader.loadScript("thirdparty/echarts/echarts.min.js");
  }
  return moEchartsLoader;
}

/**
 * 차트 공통 옵션(그리드/범례/툴팁/축 스타일)을 반환합니다.
 * @param {Array} paXData x축 카테고리
 * @return {Object}
 */
function getBaseOption(paXData) {
  var voTextStyle = {
    fontFamily : "Pretendard, sans-serif",
    fontSize : 13,
    color : CHART_COLOR.AXIS
  };
  
  return {
    // 범례는 타이틀 우측 sub-badge 로 표시하므로 차트 범례는 숨김
    legend : { show : false },
    grid : { top : 12, right : 8, bottom : 8, left : 8, containLabel : true },
    tooltip : {
      trigger : "axis",
      valueFormatter : function(pnValue) {
        return Number(pnValue).toLocaleString() + "건";
      }
    },
    xAxis : {
      type : "category",
      data : paXData,
      axisLine : { lineStyle : { color : CHART_COLOR.LINE } },
      axisTick : { show : false },
      axisLabel : { fontFamily : voTextStyle.fontFamily, fontSize : 14, color : "#1D293D", lineHeight : 20, margin : 14 }
    },
    yAxis : {
      type : "value",
      axisLabel : {
        fontFamily : voTextStyle.fontFamily,
        fontSize : voTextStyle.fontSize,
        color : voTextStyle.color,
        formatter : function(pnValue) {
          return Number(pnValue).toLocaleString();
        }
      },
      splitLine : { lineStyle : { color : CHART_COLOR.LINE, type : "dashed" } }
    }
  };
}

/**
 * 조회/저장 건수 Top 5 막대 차트 옵션
 * @return {Object}
 */
function getTop5Option() {
  /** @type cpr.data.DataSet */
  var vcDs = app.lookup("dsTop5");
  var vaXData = vcDs.getRowDataRanged().map(function(each) {
    return each.SCRN_ID + "\n" + each.SCRN_NM;
  });
  var voBar = {
    type : "bar",
    barWidth : 20,
    barGap : "20%",
    itemStyle : { borderRadius : 4 }
  };
  
  var voOption = getBaseOption(vaXData);
  voOption.tooltip.axisPointer = { type : "shadow" };
  voOption.xAxis.axisLabel.interval = 0;  // 겹쳐도 라벨 생략하지 않음 (5건 전부 표시)
  voOption.series = [
    Object.assign({ name : "조회 건수", data : vcDs.getColumnData("INQ_CNT"), color : CHART_COLOR.INQ }, voBar),
    Object.assign({ name : "저장 건수", data : vcDs.getColumnData("SAVE_CNT"), color : CHART_COLOR.SAVE }, voBar)
  ];
  
  return voOption;
}

/**
 * 시간대별 조회/저장 건수 추이 라인 차트 옵션
 * @return {Object}
 */
function getTimeTrendOption() {
  /** @type cpr.data.DataSet */
  var vcDs = app.lookup("dsTimeTrend");
  var voLine = {
    type : "line",
    symbol : "none",
    lineStyle : { width : 3 }
  };
  
  var voOption = getBaseOption(vcDs.getColumnData("TIME_ZONE"));
  voOption.xAxis.boundaryGap = false;
  voOption.xAxis.axisLine.show = false;
  voOption.series = [
    Object.assign({ name : "조회 건수", data : vcDs.getColumnData("INQ_CNT"), color : CHART_COLOR.INQ }, voLine),
    Object.assign({ name : "저장 건수", data : vcDs.getColumnData("SAVE_CNT"), color : CHART_COLOR.SAVE }, voLine)
  ];
  
  return voOption;
}

/**
 * 쉘 컨텐츠 영역에 차트를 그립니다.
 * @param {String} psShellId 쉘 ID
 * @param {HTMLElement} poContent 쉘 컨텐츠 DOM
 * @param {Function} pfGetOption 차트 옵션 생성 함수
 */
function drawChart(psShellId, poContent, pfGetOption) {
  loadEcharts().then(function() {
    if (app.disposed) {
      return;
    }
    if (moCharts[psShellId]) {
      moResizeObserver.unobserve(moCharts[psShellId].getDom());
      moCharts[psShellId].dispose();
    }
    // 쉘은 그리드 레이아웃 아이템이라 min-width:auto 기본값 때문에 내부 캔버스 너비 이하로 줄어들지 않음.
    // overflow:hidden 으로 최소너비를 0 으로 만들어 영역이 줄어들 때 ResizeObserver 가 감지할 수 있게 한다.
    poContent.style.overflow = "hidden";
    var voChart = echarts.init(poContent);
    voChart.setOption(pfGetOption());
    moCharts[psShellId] = voChart;
    moResizeObserver.observe(poContent);
  });
}

/**
 * 데이터 변경 후 차트를 다시 그립니다. (조회 서브미션 receive 등에서 호출)
 */
function refreshCharts() {
  if (moCharts["shlTop5"]) {
    moCharts["shlTop5"].setOption(getTop5Option(), true);
  }
  if (moCharts["shlTimeTrend"]) {
    moCharts["shlTimeTrend"].setOption(getTimeTrendOption(), true);
  }
}

/**
 * 쉘 init 공통 처리 - 이미 그려진 차트가 있으면 다시 그립니다.
 * (탭 전환 등으로 쉘이 다시 그려질 때 기존 DOM 재사용)
 * @param {cpr.events.CUIEvent} e
 * @param {Function} pfGetOption
 */
function initChartShell(e, pfGetOption) {
  var vsShellId = e.control.id;
  if (e.content && moCharts[vsShellId]) {
    e.preventDefault();
    cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
      drawChart(vsShellId, e.content, pfGetOption);
    });
  }
}


/************************************************
 ** 자동으로 생성되는 이벤트 자바스크립트 함수를 배치
 ** (이벤트 생성시 자동으로 스크립트 함수 하위에 표시) 
 ************************************************/


/*
 * 쉘에서 load 이벤트 발생 시 호출.
 * 쉘이 그려진 후 내용을 작성하는 이벤트.
 */
function onShlTop5Load(e) {
  drawChart(e.control.id, e.content, getTop5Option);
}

/*
 * 쉘에서 init 이벤트 발생 시 호출.
 * 쉘 컨트롤의 내용이 그려지기 전 초기화 하는 이벤트.
 */
function onShlTop5Init(e) {
  initChartShell(e, getTop5Option);
}

/*
 * 쉘에서 load 이벤트 발생 시 호출.
 * 쉘이 그려진 후 내용을 작성하는 이벤트.
 */
function onShlTimeTrendLoad(e) {
  drawChart(e.control.id, e.content, getTimeTrendOption);
}

/*
 * 쉘에서 init 이벤트 발생 시 호출.
 * 쉘 컨트롤의 내용이 그려지기 전 초기화 하는 이벤트.
 */
function onShlTimeTrendInit(e) {
  initChartShell(e, getTimeTrendOption);
}
