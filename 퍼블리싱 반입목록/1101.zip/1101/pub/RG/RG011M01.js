/************************************************
 * RG011M01.js
 * @프로그램설명 :
 *
 * @작성일자 :  2026. 10. 22..
 * @작성자 : yein
 *
 * @수정이력 : 수정일자 (수정자) 수정내용
 ************************************************/

/************************************************
 ** 글로벌 변수, 상수변수
 ************************************************/
/** 차트 색상 (범례 sub-badge의 square-dot 색상과 동일) */
var CHART_COLOR = {
  JOIN  : "#2B7FFF", // 가입건수
  AXIS  : "#90A1B9", // 축 라벨
  LINE  : "#E2E8F0", // 그리드 라인
  TRACK : "#F1F5F9", // 스크롤바 트랙
  THUMB : "#CAD5E2"  // 스크롤바 손잡이
};

/** 막대 배치(px) - 막대 너비 / 막대 사이 간격 / 그래프 시작·끝 여백(첫·마지막 막대 바깥쪽까지) */
var BAR_LAYOUT = {
  WIDTH : 20,
  GAP   : 50,
  EDGE  : 80
};

/** 가로축 라벨 최소 간격(px) - 이보다 좁으면 라벨을 건너뛰어 표시 */
var LABEL_MIN_PITCH = 60;

/** 확대·축소 1회당 배율 */
var ZOOM_FACTOR = 1.25;

/** 최대 확대 배율 (막대 간격 기준) */
var ZOOM_MAX_SCALE = 3;


/************************************************
 ** 글로벌 함수
 ************************************************/


/************************************************
 ** 파일내 로컬변수 선언
 ************************************************/
var util = createCommonUtil();

/** echarts 인스턴스 */
var moChart = null;

/** echarts 라이브러리 로드 Promise (화면 내 1회만 로드) */
var moEchartsLoader = null;

/** 가로축 라벨 (막대 index → 추천지점명) */
var maXNames = [];

/** 현재 확대 배율 (1 = 막대 간격 BAR_LAYOUT.GAP) */
var mnZoomScale = 1;

/** 현재 막대 너비(px) - 간격이 좁아지면 줄어듦 */
var mnBarWidth = BAR_LAYOUT.WIDTH;

/**
 * 차트 영역 크기 변화 감지.
 * window resize 만으로는 LNB 접기/펼치기 등 컨테이너만 바뀌는 경우를 감지하지 못하므로
 * 쉘 컨텐츠 DOM 자체의 크기 변화를 감지해 차트를 리사이즈한다.
 */
var moResizeObserver = new ResizeObserver(function(paEntries) {
  if (app.disposed) {
    moResizeObserver.disconnect();
    return;
  }
  paEntries.forEach(function(each) {
    var voChart = echarts.getInstanceByDom(each.target);
    // 숨김 상태(0 크기)에서는 리사이즈하지 않음 - 다시 보일 때 감지됨
    if (voChart && each.contentRect.width > 0 && each.contentRect.height > 0) {
      voChart.resize();
      // 폭이 바뀌면 막대 간격(px)이 유지되도록 표시 구간을 다시 계산
      if (voChart === moChart) {
        applyZoomWindow();
      }
    }
  });
});

/************************************************
 ** 사용자 정의 자바스크립트 함수를 기술
 ************************************************/

/**
 * echarts 라이브러리를 지연 로드합니다.
 * @return {Promise}
 */
function loadEcharts() {
  if (window.echarts) {
    return Promise.resolve();
  }
  if (!moEchartsLoader) {
    moEchartsLoader = cpr.core.ResourceLoader.loadScript("thirdparty/echarts/echarts.min.js");
  }
  return moEchartsLoader;
}

/**
 * 추천지사별 가입건수 막대 차트 옵션 (가로축 추천지사 · 세로축 가입건수)
 * @return {Object}
 */
function getJoinBranchOption() {
  /** @type cpr.data.DataSet */
  var vcDs = app.lookup("ds1");
  maXNames = vcDs.getColumnData("column1");
  // 막대 간격을 px 단위로 고정하기 위해 가로축을 값 축(막대 index)으로 사용
  var vaYData = vcDs.getColumnData("column2").map(function(each, idx) {
    return [idx, Number(each)];
  });
  var vnPad = getEdgePad();
  var voTextStyle = {
    fontFamily : "Pretendard, sans-serif",
    fontSize : 13,
    color : CHART_COLOR.AXIS
  };

  return {
    // 범례는 타이틀 우측 sub-badge 로 표시하므로 차트 범례는 숨김
    legend : { show : false },
    // left: 세로축 이름("가입건수 (건)")이 라벨보다 넓어 잘리지 않도록 여유 확보 (containLabel 은 축 이름을 계산하지 않음)
    // bottom: 가로축 라벨을 custom 시리즈로 그리므로(containLabel 미적용) 라벨 높이만큼 포함
    grid : { top : 36, right : 16, bottom : 82, left : 40, containLabel : true },
    tooltip : {
      trigger : "axis",
      axisPointer : { type : "line", snap : true, lineStyle : { color : CHART_COLOR.LINE } },
      formatter : function(paParams) {
        var voParam = paParams.filter(function(each) {
          return each.seriesName == "가입건수";
        })[0];
        return maXNames[voParam.value[0]] + "<br/>"
          + voParam.marker + voParam.seriesName + " " + Number(voParam.value[1]).toLocaleString() + "건";
      }
    },
    xAxis : {
      type : "value",
      min : -vnPad,
      max : maXNames.length - 1 + vnPad,
      interval : 1,
      splitLine : { show : false },
      // 오른쪽 끝 기준으로 라벨 아래에 오른쪽 정렬
      name : "추천지사",
      nameLocation : "end",
      nameGap : 0,
      nameTextStyle : {
        fontFamily : voTextStyle.fontFamily,
        fontSize : voTextStyle.fontSize,
        color : "#62748E",
        align : "right",
        verticalAlign : "top",
        padding : [40, 0, 0, 0]
      },
      axisLine : { lineStyle : { color : CHART_COLOR.LINE } },
      axisTick : { show : false },
      // 값 축 눈금은 축 시작점 기준으로 생겨 막대 위치와 어긋나므로, 라벨은 getAxisLabelSeries 로 그림
      axisLabel : { show : false }
    },
    yAxis : {
      type : "value",
      name : "가입건수 (건)",
      nameLocation : "end",
      nameGap : 16,
      nameTextStyle : {
        fontFamily : voTextStyle.fontFamily,
        fontSize : 12,
        color : "#62748E",
        // 세로축 라벨과 오른쪽 끝을 맞춤 (padding 우측 = axisLabel 기본 margin 8)
        align : "right",
        padding : [0, 8, 0, 0]
      },
      axisLabel : {
        fontFamily : voTextStyle.fontFamily,
        fontSize : voTextStyle.fontSize,
        color : voTextStyle.color,
        formatter : function(pnValue) {
          return Number(pnValue).toLocaleString();
        }
      },
      // 가로축이 값 축이면 세로축이 x=0(첫 막대) 위치로 붙어(onZero) 축 이름이 그쪽으로 밀리므로 그래프 왼쪽에 고정하고, 축 선은 숨김
      axisLine : { show : false, onZero : false },
      axisTick : { show : false },
      splitLine : { lineStyle : { color : CHART_COLOR.LINE, type : "dashed" } }
    },
    // 가로 스크롤바(slider) + 마우스 휠·드래그(inside). 확대·축소 버튼은 dispatchAction 으로 제어
    dataZoom : [{
      type : "slider",
      xAxisIndex : 0,
      // 표시 구간은 applyZoomWindow 에서 막대 간격(px) 기준으로 계산
      filterMode : "none",
      // 시안 스타일: 회색 트랙 + 손잡이 막대만 표시 (기본 핸들·데이터 그림자·범위 숫자 숨김)
      height : 10,
      bottom : 4,
      left : 16,
      right : 16,
      showDetail : false,
      showDataShadow : false,
      brushSelect : false,
      zoomLock : true,
      handleSize : 0,
      moveHandleSize : 0,
      borderColor : "transparent",
      backgroundColor : CHART_COLOR.TRACK,
      fillerColor : CHART_COLOR.THUMB
    }, {
      type : "inside",
      xAxisIndex : 0,
      filterMode : "none",
      zoomOnMouseWheel : false,
      moveOnMouseWheel : true,
      moveOnMouseMove : true
    }],
    series : [getBarSeries(vaYData), getAxisLabelSeries(voTextStyle.fontFamily)]
  };
}

/**
 * 가입건수 막대를 그리는 custom 시리즈.
 * echarts 5.0.3 bar 시리즈는 스크롤 시 그래프 영역 밖(세로축 라벨 위)으로 막대가 넘쳐 그려지므로,
 * 막대를 직접 그리고 그래프 영역(coordSys)으로 잘라냅니다.
 * @param {Array} paData [막대 index, 가입건수] 목록
 * @return {Object}
 */
function getBarSeries(paData) {
  return {
    name : "가입건수",
    type : "custom",
    data : paData,
    encode : { x : 0, y : 1, tooltip : 1 },
    color : CHART_COLOR.JOIN,
    renderItem : function(poParams, poApi) {
      var voRect = poParams.coordSys;
      var vaBase = poApi.coord([poApi.value(0), 0]);
      var vaTop = poApi.coord([poApi.value(0), poApi.value(1)]);
      var voShape = echarts.graphic.clipRectByRect({
        x : vaBase[0] - mnBarWidth / 2,
        y : vaTop[1],
        width : mnBarWidth,
        height : vaBase[1] - vaTop[1]
      }, {
        x : voRect.x,
        y : voRect.y,
        width : voRect.width,
        height : voRect.height
      });
      if (!voShape) {
        return null;
      }
      voShape.r = 4;
      return {
        type : "rect",
        shape : voShape,
        style : { fill : CHART_COLOR.JOIN }
      };
    }
  };
}

/**
 * 막대 아래 가로축 라벨(추천지점명)을 그리는 custom 시리즈.
 * 막대 index 위치에 라벨을 두고, 간격이 좁으면 LABEL_MIN_PITCH 기준으로 건너뜁니다.
 * @param {String} psFontFamily 폰트
 * @return {Object}
 */
function getAxisLabelSeries(psFontFamily) {
  return {
    type : "custom",
    name : "axisLabel",
    silent : true,
    tooltip : { show : false },
    data : maXNames.map(function(each, idx) {
      return [idx, 0];
    }),
    encode : { x : 0, y : 1 },
    renderItem : function(poParams, poApi) {
      var vnIdx = poApi.value(0);
      var voRect = poParams.coordSys;
      var vnX = poApi.coord([vnIdx, 0])[0];
      if (vnX < voRect.x || vnX > voRect.x + voRect.width) {
        return null;
      }
      var vnStep = Math.max(1, Math.ceil(LABEL_MIN_PITCH / poApi.size([1, 0])[0]));
      if (vnIdx % vnStep != 0) {
        return null;
      }
      return {
        type : "text",
        style : {
          text : maXNames[vnIdx],
          x : vnX,
          y : voRect.y + voRect.height + 14,
          align : "center",
          verticalAlign : "top",
          font : "14px " + psFontFamily,
          fill : "#1D293D"
        }
      };
    }
  };
}

/**
 * 쉘 컨텐츠 영역에 차트를 그립니다.
 * @param {HTMLElement} poContent 쉘 컨텐츠 DOM
 */
function drawChart(poContent) {
  loadEcharts().then(function() {
    if (app.disposed) {
      return;
    }
    if (moChart) {
      moResizeObserver.unobserve(moChart.getDom());
      moChart.dispose();
    }
    // 쉘은 레이아웃 아이템이라 min-width:auto 기본값 때문에 내부 캔버스 너비 이하로 줄어들지 않음.
    // overflow:hidden 으로 최소너비를 0 으로 만들어 영역이 줄어들 때 ResizeObserver 가 감지할 수 있게 한다.
    poContent.style.overflow = "hidden";
    moChart = echarts.init(poContent);
    moChart.setOption(getJoinBranchOption());
    applyZoomWindow();
    moResizeObserver.observe(poContent);
  });
}

/**
 * 데이터 변경 후 차트를 다시 그립니다. (조회 서브미션 receive 등에서 호출)
 */
function refreshChart() {
  if (moChart) {
    moChart.setOption(getJoinBranchOption(), true);
    applyZoomWindow();
  }
}

/**
 * 가로축 양끝 여백을 막대 index 단위로 환산합니다.
 * (첫 막대 왼쪽 끝 ~ 그래프 시작 = EDGE px → 막대 중심 기준 EDGE + WIDTH/2)
 * @return {Number}
 */
function getEdgePad() {
  return (BAR_LAYOUT.EDGE + BAR_LAYOUT.WIDTH / 2) / (BAR_LAYOUT.WIDTH + BAR_LAYOUT.GAP);
}

/**
 * 현재 배율에서 막대 간격이 BAR_LAYOUT.GAP × 배율(px)이 되도록 표시 구간을 맞춥니다.
 * @param {Number} pnCenter (옵션) 구간 중심 index. 없으면 현재 시작 위치를 유지
 */
function applyZoomWindow(pnCenter) {
  if (!moChart || maXNames.length == 0) {
    return;
  }
  var voZoom = moChart.getOption().dataZoom[0];
  var vnPad = getEdgePad();
  var vnMin = -vnPad;
  var vnMax = maXNames.length - 1 + vnPad;
  var vnStart = voZoom.startValue != null ? voZoom.startValue : vnMin;
  var vnEnd = voZoom.endValue != null ? voZoom.endValue : vnMax;
  // 현재 표시 구간의 그래프 영역 폭(px)
  var vnPlotWidth = moChart.convertToPixel({ xAxisIndex : 0 }, vnEnd) - moChart.convertToPixel({ xAxisIndex : 0 }, vnStart);
  if (!(vnPlotWidth > 0)) {
    return;
  }
  var vnTotalSpan = vnMax - vnMin;
  var vnUnitPx = (BAR_LAYOUT.WIDTH + BAR_LAYOUT.GAP) * mnZoomScale;
  var vnSpan = vnPlotWidth / vnUnitPx;
  // 전체가 한 화면에 들어오면 더 축소하지 않음
  if (vnSpan >= vnTotalSpan) {
    vnSpan = vnTotalSpan;
    vnUnitPx = vnPlotWidth / vnTotalSpan;
    mnZoomScale = vnUnitPx / (BAR_LAYOUT.WIDTH + BAR_LAYOUT.GAP);
  }
  var vnNewStart = pnCenter != null ? pnCenter - vnSpan / 2 : vnStart;
  vnNewStart = Math.max(vnMin, Math.min(vnMax - vnSpan, vnNewStart));

  // 간격이 좁아지면 막대가 겹치지 않도록 너비를 줄임
  mnBarWidth = Math.min(BAR_LAYOUT.WIDTH, vnUnitPx * 0.6);
  moChart.dispatchAction({
    type : "dataZoom",
    dataZoomIndex : 0,
    startValue : vnNewStart,
    endValue : vnNewStart + vnSpan
  });
}

/**
 * 현재 표시 구간 중심을 기준으로 확대·축소합니다.
 * @param {Number} pnFactor 배율 변화 (1보다 크면 확대 - 더 적게 보임, 작으면 축소 - 더 많이 보임)
 */
function zoomChart(pnFactor) {
  if (!moChart) {
    return;
  }
  var voZoom = moChart.getOption().dataZoom[0];
  mnZoomScale = Math.min(ZOOM_MAX_SCALE, mnZoomScale * pnFactor);
  applyZoomWindow((voZoom.startValue + voZoom.endValue) / 2);
}


/************************************************
 ** 자동으로 생성되는 이벤트 자바스크립트 함수를 배치
 ** (이벤트 생성시 자동으로 스크립트 함수 하위에 표시)
 ************************************************/


/*
 * 쉘에서 load 이벤트 발생 시 호출.
 * 쉘이 그려진 후 내용을 작성하는 이벤트.
 */
function onShlChartLoad(e) {
  drawChart(e.content);
}

/*
 * 쉘에서 init 이벤트 발생 시 호출.
 * 쉘 컨트롤의 내용이 그려지기 전 초기화 하는 이벤트.
 * (탭 전환 등으로 쉘이 다시 그려질 때 기존 차트를 다시 그림)
 */
function onShlChartInit(e) {
  if (e.content && moChart) {
    e.preventDefault();
    cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
      drawChart(e.content);
    });
  }
}

/*
 * "-" 버튼에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onBtnZoomOutClick(e) {
  zoomChart(1 / ZOOM_FACTOR);
}

/*
 * "+" 버튼에서 click 이벤트 발생 시 호출.
 * 사용자가 컨트롤을 클릭할 때 발생하는 이벤트.
 */
function onBtnZoomInClick(e) {
  zoomChart(ZOOM_FACTOR);
}
