/************************************************
 * comMainHome.js
 * @프로그램설명 : 홈 대시보드 — 스크롤 없음, 화면 크기에 맞춰 전체 배율 조정
 *
 * @작성일자 :  2026. 11. 4..
 * @작성자 : yein
 *
 * @수정이력 : 수정일자 (수정자) 수정내용
 ************************************************/

/************************************************
 ** 글로벌 변수, 상수변수
 ************************************************/ 

/* 배율 기준 논리 크기 — 디자인팀 데모(홈 1920x1200)에서 상단 헤더(64)·탭바(52)를 뺀 콘텐츠 영역.
 * 데모는 k = min(창높이 / 1200, 창너비 / 1600) 로 배율을 정하고, 논리 크기를 (창 / k) 로 키워 가로를 채운다.
 * 사이드바(80)는 메인 프레임 몫이라 너비 기준은 1600 - 80 = 1520. 높이 기준은 페이지 헤더 92 + 모니터링 566 +
 * 간격 10 + 하단 카드 최소 399.5 + 하단 여백 16 = 1083.5 */
var HOME_BASE_H = 1084;
var HOME_BASE_MIN_W = 1520;

var util = createCommonUtil();

/* 화면 배율용 style 태그 id */
var HOME_SCALE_STYLE_ID = "home-scale-style";


/************************************************
 ** 글로벌 함수
 ************************************************/ 


/************************************************
 ** 파일내 로컬변수 선언  
 ************************************************/ 

/* 호스트(화면 영역) 크기 감시 — 화면 종료 시 해제 */
var moResizeObserver = null;

/* 화면 크기 변경 후 배율 재계산 대기 타이머 */
var moScaleTimer = null;

/** 테마(data-xb-color) 변경 감시 — 차트는 캔버스라 CSS가 따라 바뀌지 않아 다시 그린다 */
var moThemeObserver = null;

/* 로드 애니메이션 재생 순번 — 다시 재생하면 이전 루프를 멈추는 데 쓴다 */
var moAnimSeq = 0;

/* 진행 중인 애니메이션을 끝값으로 마무리하는 함수 — 다른 범위를 새로 재생할 때 이전 것이 중간값에 멈추지 않게 한다 */
var moAnimStop = null;

/** 그리드(dsGoal) 최종값 { rate: 달성률[], amt: 매출액[] } — 애니메이션이 값을 0으로 내리기 전에 처음 읽은 값 */
var moGoalFinal = null;

/** 막대(progress)·숫자(output) 컨트롤별 최종값 [{ctrl, to, prefix, suffix, dec}] — 애니메이션이 value를 0으로 내리기 전에 처음 읽은 값 */
var maAnimFinal = [];

/** echarts 라이브러리 로드 Promise (화면 내 1회만 로드) */
var moEchartsLoader = null;

/** 원형 게이지 echarts 인스턴스 (쉘 id → 인스턴스) */
var moGauges = {};

/** 원형 게이지 설정 (쉘 id → 값·두께·글자) — rate는 데이터 연동 전 가데이터 */
var GAUGE_CFG = {
	shlGoalDonut: { rate: 90, width: 10, fontSize: 24, unit: "%", dec: 0 },
	shlPerfRing0: { rate: 92.0, width: 6, fontSize: 16, dec: 1 },
	shlPerfRing1: { rate: 92.0, width: 6, fontSize: 16, dec: 1 },
	shlPerfRing2: { rate: 92.0, width: 6, fontSize: 16, dec: 1 },
	shlPerfTile0: { rate: 91.0, width: 6, fontSize: 18, dec: 1 },
	shlPerfTile1: { rate: 90.5, width: 6, fontSize: 18, dec: 1 },
	shlPerfTile2: { rate: 89.0, width: 6, fontSize: 18, dec: 1 },
	shlPerfTile3: { rate: 92.1, width: 6, fontSize: 18, dec: 1 },
	shlPerfTile4: { rate: 0, width: 6, fontSize: 18, dec: 0 },
	shlPerfTile5: { rate: 92.0, width: 6, fontSize: 18, dec: 1 }
};

/** 쉘 컨텐츠 DOM 보관 (쉘 id → DOM) — 보기 전환 시 다시 그리는 데 쓴다 */
var moGaugeDoms = {};


/************************************************
 ** 사용자 정의 자바스크립트 함수를 기술 
 ************************************************/ 

/**
 * 메인의 화면 확대/축소 비율(%)을 구한다. Main.setScreenScale 이 루트 앱 인스턴스의 _scaleRate 앱 속성에 보관한다.
 * 메인 안이 아니거나 아직 지정되지 않았으면 100.
 * @return {Number}
 */
function getMainZoomRate() {
	var vnRate = Number(app.getRootAppInstance().getAppProperty("_scaleRate"));
	return vnRate > 0 ? vnRate : 100;
}

/**
 * 배율을 화면에 건다. 대상은 루트 안쪽 그룹(grpHomeScale) — 루트(app.getContainer())는 메인의 확대/축소가
 * 인라인으로 transform·크기를 쓰는 영역이라 건드리지 않는다. 인라인 스타일은 eXBuilder가 레이아웃 때마다 다시 쓰므로 클래스 + CSS 변수로 건다.
 * @param {Number} pnScale 자동 맞춤 배율
 * @param {Number} pnWidth 그룹의 논리 너비(px) — 배율을 곱한 크기가 화면에 보이는 크기
 * @param {Number} pnHeight 그룹의 논리 높이(px)
 * @param {Boolean} pbScroll 메인 확대(100% 초과)라 내용이 영역을 넘는 경우 true — 이때만 스크롤을 허용한다
 */
function applyHomeScale(pnScale, pnWidth, pnHeight, pbScroll) {
	if (!document.getElementById(HOME_SCALE_STYLE_ID)) {
		var voStyle = document.createElement("style");
		voStyle.id = HOME_SCALE_STYLE_ID;
		voStyle.textContent = ".home-scale.home-scaled{transform:scale(var(--home-scale)) !important;transform-origin:0 0 !important;" +
			"width:var(--home-w) !important;height:var(--home-h) !important;" +
			/* transform은 레이아웃 크기를 바꾸지 않아 스크롤 범위가 배율 전 크기로 잡히므로, 줄어든(늘어난) 만큼 음수 여백으로 맞춘다 */
			"margin-right:calc(var(--home-w) * (var(--home-scale) - 1)) !important;margin-bottom:calc(var(--home-h) * (var(--home-scale) - 1)) !important;}" +
			/* 스크롤은 루트 바로 아래 레이아웃 요소가 가진다(루트 자체는 스크롤 영역이 아님) */
			"._home.home-zoomed > .cl-layout{overflow:auto !important;}";
		document.head.appendChild(voStyle);
	}
	var voRoot = document.documentElement;
	voRoot.style.setProperty("--home-scale", pnScale);
	voRoot.style.setProperty("--home-w", pnWidth + "px");
	voRoot.style.setProperty("--home-h", pnHeight + "px");

	app.lookup("grpHomeScale").style.addClass("home-scaled");
	var vcRoot = app.getContainer();
	if (pbScroll) {
		vcRoot.style.addClass("home-zoomed");
	} else {
		vcRoot.style.removeClass("home-zoomed");
	}
}

/**
 * 화면 전체 배율을 정한다. 데모와 같은 기준 — 높이 기준(HOME_BASE_H)과 최소 너비(HOME_BASE_MIN_W) 중 더 작은 쪽.
 * 메인의 확대/축소는 그 위에 곱해진다.
 *  - 루트의 clientWidth/Height 는 메인이 정한 논리 크기, 실제로 보이는 크기는 거기에 확대/축소 비율을 곱한 값이다.
 *  - 100% 이하: 그룹을 루트 크기에 맞춰 채운다(축소하면 내용이 작아지고 여백만큼 더 담긴다).
 *  - 100% 초과: 그룹을 기준 크기로 두어 내용이 영역을 넘고, 루트에 스크롤을 허용한다.
 */
function fitHomeScale() {
	/* 루트 컨테이너의 논리 크기 — 메인이 정한 크기이고, 안쪽 그룹의 transform에는 영향받지 않는다 */
	var voRect = app.getContainer().getActualRect();
	var vnRootW = voRect.width;
	var vnRootH = voRect.height;
	if (vnRootW < 1 || vnRootH < 1) return;

	var vnRate = getMainZoomRate();
	var vnVisW = vnRootW * vnRate / 100;
	var vnVisH = vnRootH * vnRate / 100;

	var vnScale = Math.min(vnVisH / HOME_BASE_H, vnVisW / HOME_BASE_MIN_W);
	applyHomeScale(vnScale, Math.max(vnRootW, vnVisW) / vnScale, Math.max(vnRootH, vnVisH) / vnScale, vnRate > 100);
}

/**
 * 최초 로드 애니메이션 — 막대(progress)와 숫자(output)를 컨트롤의 value로 0에서 최종값까지 올린다.
 * 컨트롤은 getAllRecursiveChildren()으로 찾고(DOM 조회 없음), style.hasClass로 종류를 가른다.
 *  - 막대: 1초, 막대마다 시작을 0.05초씩 늦춘다 (easeOutQuint)
 *  - 숫자(stat-value, bar-value, kpi-value, branch-value): datatype=number인 output의 value를 1.2초 동안 올린다 (easeOutCubic)
 * 그리드 셀 컨트롤은 lookup할 수 없으므로, 바인딩된 데이터셋(dsGoal)의 달성률·매출액 값을 올린다.
 * 도넛·원형 게이지는 echarts(drawGauge)가 자체 애니메이션으로 처리한다.
 * 최종값은 처음 읽은 값을 보관해 두어, 다시 호출하면 처음부터 다시 재생한다.
 * @param {cpr.controls.Container} pcRoot? 재생 범위. 생략하면 화면 전체(그리드 포함)
 */
function playHomeAnim(pcRoot) {
	/* 이전 재생이 아직 진행 중이면 끝값으로 마무리한 뒤 새로 시작한다 */
	if (moAnimStop) moAnimStop();
	var vcRoot = pcRoot || app.getContainer();
	var vnSeq = ++moAnimSeq;
	var vbReduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	var vaItem = [];
	var vnBarIdx = 0;

	/** 처음 읽은 값을 보관하고 돌려준다 */
	function getFinal(pcCtrl, pfRead) {
		var voFinal = maAnimFinal.filter(function(item) { return item.ctrl === pcCtrl; })[0];
		if (!voFinal) {
			voFinal = pfRead();
			voFinal.ctrl = pcCtrl;
			maAnimFinal.push(voFinal);
		}
		return voFinal;
	}

	vcRoot.getAllRecursiveChildren().forEach(function(each) {
		if (each.type == "progress") {
			var voBar = getFinal(each, function() { return { to: Number(each.value) }; });
			vaItem.push({
				set: function(pnVal) { each.value = pnVal; },
				to: voBar.to, delay: 150 + (vnBarIdx++) * 50, dur: 1000, pow: 5
			});
		} else if (each.type == "output" && ["stat-value", "bar-value", "kpi-value", "branch-value"].some(function(cls) { return each.style.hasClass(cls); })) {
			/* 숫자 타입 output — 콤마 서식은 컨트롤(format)이 처리하고, 숫자가 아니면 건너뛴다 */
			var voNum = getFinal(each, function() { return { to: Number(each.value) }; });
			if (isNaN(voNum.to)) return;
			vaItem.push({
				set: function(pnVal) { each.value = Math.round(pnVal); },
				to: voNum.to, delay: 200, dur: 1200, pow: 3
			});
		}
	});

	/* 그리드 안 막대·숫자 — 바인딩된 데이터셋 값을 올린다. 화면 전체 또는 그리드(grdGoal)가 든 범위를 재생할 때 포함 */
	var vcDs = app.lookup("dsGoal");
	var vbGoal = vcDs && (!pcRoot || isInside(app.lookup("grdGoal"), pcRoot));
	if (vbGoal) {
		if (moGoalFinal == null) {
			moGoalFinal = {
				rate: vcDs.getColumnData("ACHV_RATE").map(Number),
				amt: vcDs.getColumnData("SALE_AMT").map(Number)
			};
		}
		/* 옆의 % 글자가 같은 값에 바인딩되어 소수가 보이지 않도록 둘 다 정수로 올리고, 끝에서만 최종값을 그대로 넣는다 */
		moGoalFinal.rate.forEach(function(pnTo, idx) {
			vaItem.push({
				set: function(pnVal) { vcDs.setValue(idx, "ACHV_RATE", pnVal >= pnTo ? pnTo : Math.round(pnVal)); },
				to: pnTo, delay: 150 + (vnBarIdx++) * 50, dur: 1000, pow: 5
			});
		});
		moGoalFinal.amt.forEach(function(pnTo, idx) {
			vaItem.push({
				set: function(pnVal) { vcDs.setValue(idx, "SALE_AMT", pnVal >= pnTo ? pnTo : Math.round(pnVal)); },
				to: pnTo, delay: 200, dur: 1200, pow: 3
			});
		});
	}

	function finish() {
		moAnimStop = null;
		/* 데이터셋을 건드렸으니 변경 상태를 되돌린다 */
		if (vbGoal) vcDs.commit();
	}

	if (vbReduced) {
		vaItem.forEach(function(each) { each.set(each.to); });
		finish();
		return;
	}

	moAnimStop = function() {
		moAnimSeq++;
		vaItem.forEach(function(each) { each.set(each.to); });
		finish();
	};
	vaItem.forEach(function(each) { each.set(0); });
	var vnStart = performance.now();
	function tick(pnNow) {
		/* 다시 재생이 시작됐거나 화면이 닫히면 중단 */
		if (vnSeq != moAnimSeq || app.disposed) return;
		var vbDone = true;
		vaItem.forEach(function(each) {
			var vnP = Math.min(Math.max((pnNow - vnStart - each.delay) / each.dur, 0), 1);
			each.set(each.to * (1 - Math.pow(1 - vnP, each.pow)));
			if (vnP < 1) vbDone = false;
		});
		if (vbDone) finish();
		else requestAnimationFrame(tick);
	}
	requestAnimationFrame(tick);
}

/**
 * 컨트롤이 범위(컨테이너) 안에 있는지 부모를 거슬러 올라가며 확인한다.
 * @param {cpr.controls.UIControl} pcCtrl 확인할 컨트롤
 * @param {cpr.controls.Container} pcRoot 범위
 * @return {Boolean}
 */
function isInside(pcCtrl, pcRoot) {
	var vcCur = pcCtrl;
	while (vcCur) {
		if (vcCur === pcRoot) return true;
		vcCur = vcCur.getParent();
	}
	return false;
}

/**
 * 홈 카드(home-card) 하나의 막대 · 숫자 · 원형 게이지를 0부터 다시 채운다.
 * 탭 전환이나 조회 후 값이 바뀌었을 때 부르면 된다. 렌더링이 끝난 뒤 재생하므로 값을 먼저 바꾸고 불러도 된다.
 *   예) refillHomeCard(app.lookup("grpCardGoal"));   // 매출목표 카드
 *       refillHomeCard(e.control);                    // 카드 안 컨트롤을 넘겨도 카드를 찾아 재생
 * @param {cpr.controls.UIControl} pcCtrl 카드 또는 카드 안의 컨트롤
 */
function refillHomeCard(pcCtrl) {
	var vcCard = pcCtrl;
	while (vcCard && !vcCard.style.hasClass("home-card")) vcCard = vcCard.getParent();
	if (!vcCard) return;

	cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
		if (app.disposed) return;
		playHomeAnim(vcCard);
		/* 카드 안에서 보이는 게이지만 다시 그린다(숨은 쪽은 0 크기라 보이게 될 때 쉘 load에서 그려짐) */
		Object.keys(moGaugeDoms).forEach(function(psId) {
			if (moGaugeDoms[psId].clientWidth > 0 && isInside(app.lookup(psId), vcCard)) drawGauge(psId, moGaugeDoms[psId]);
		});
	});
}

/**
 * echarts 라이브러리를 지연 로드합니다.
 * @return {Promise}
 */
function loadEcharts() {
	if (window.echarts) return Promise.resolve();
	if (!moEchartsLoader) {
		moEchartsLoader = cpr.core.ResourceLoader.loadScript("thirdparty/echarts/echarts.min.js");
	}
	return moEchartsLoader;
}

/**
 * 원형 게이지(도넛) 옵션 — 게이지 시리즈로 둥근 끝(roundCap)과 값 카운트업(valueAnimation)을 쓴다.
 * 트랙 색은 테마 변수(--home-ring-track)에서 읽어 라이트/다크를 따른다.
 * @param {Number} pnRate 값(0~100)
 * @param {Object} poOpt {width: 고리 두께, fontSize: 가운데 글자 크기, unit: 값 뒤 문자, dec: 소수 자릿수}
 * @return {Object}
 */
function getGaugeOption(pnRate, poOpt) {
	var vsTrack = getComputedStyle(document.body).getPropertyValue("--home-ring-track").trim() || "#E2E8F0";
	var vbZero = pnRate <= 0;
	return {
		animationDuration: 1400,
		animationDelay: 200,
		animationEasing: "cubicOut",
		series: [{
			type: "gauge",
			startAngle: 90,
			endAngle: -270,
			min: 0,
			max: 100,
			radius: "100%",
			center: ["50%", "50%"],
			pointer: { show: false },
			axisTick: { show: false },
			splitLine: { show: false },
			axisLabel: { show: false },
			axisLine: { roundCap: true, lineStyle: { width: poOpt.width, color: [[1, vsTrack]] } },
			progress: {
				/* 0이면 둥근 끝 점이 남지 않게 숨긴다 */
				show: !vbZero,
				roundCap: true,
				width: poOpt.width,
				itemStyle: {
					color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
						{ offset: 0, color: "#55C4AE" },
						{ offset: 1, color: "#2B7FFF" }
					])
				}
			},
			detail: {
				valueAnimation: true,
				offsetCenter: [0, 0],
				fontSize: poOpt.fontSize,
				fontWeight: 800,
				fontFamily: "Pretendard, sans-serif",
				color: vbZero ? "#62748E" : "#155DFC",
				formatter: function(pnVal) {
					return (poOpt.dec ? pnVal.toFixed(poOpt.dec) : Math.round(pnVal)) + (poOpt.unit || "");
				}
			},
			data: [{ value: pnRate }]
		}]
	};
}

/**
 * 원형 게이지 쉘 load 공통 처리 — 컨텐츠 DOM을 보관하고 그린다.
 * @param {String} psId 쉘 id
 * @param {HTMLElement} poContent 쉘 컨텐츠 DOM
 */
function onGaugeShellLoad(psId, poContent) {
	moGaugeDoms[psId] = poContent;
	/* clx 리스너와 아래 코드 연결이 겹쳐 두 번 불려도 이미 그려진 쉘은 다시 그리지 않는다 */
	if (window.echarts && echarts.getInstanceByDom(poContent)) return;
	drawGauge(psId, poContent);
}

/**
 * 쉘 컨텐츠 영역에 원형 게이지를 그립니다. 이미 그려져 있으면 처음부터 다시 그려 애니메이션을 재생한다.
 * @param {String} psId 쉘 id
 * @param {HTMLElement} poContent 쉘 컨텐츠 DOM
 */
function drawGauge(psId, poContent) {
	var voCfg = GAUGE_CFG[psId];
	if (!voCfg) return;
	loadEcharts().then(function() {
		if (app.disposed) return;
		if (moGauges[psId]) moGauges[psId].dispose();
		moGauges[psId] = echarts.init(poContent);
		moGauges[psId].setOption(getGaugeOption(voCfg.rate, voCfg));
	});
}

/**
 * 그리드를 다시 그린다. 그리드는 그릴 때의 폭으로 컬럼을 맞추기 때문에, 화면 배율로 그룹의 논리 크기가 바뀐 뒤에는
 * 다시 그려야 한다. 안 그러면 컬럼이 처음(작았던) 폭에 머물러 오른쪽이 비고 가로 스크롤이 생긴다.
 */
function redrawHomeGrids() {
	["grdGoal", "grdRaceResult"].forEach(function(psId) {
		var vcGrid = app.lookup(psId);
		if (vcGrid) vcGrid.redraw();
	});
}

/**
 * 배율을 렌더링 후 실제 크기 기준으로 다시 맞춘다.
 * @param {Boolean} pbPlay? true면 최초 로드 애니메이션도 재생한다
 */
function doHomeLayout(pbPlay) {
	cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
		if (app.disposed) return;
		fitHomeScale();
		/* 배율이 반영된 크기로 그리드를 다시 그린 뒤, 새로 만들어진 셀(숫자·막대)에 애니메이션을 건다 */
		cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
			if (app.disposed) return;
			redrawHomeGrids();
			if (pbPlay) playHomeAnim();
		});
	});
}

/************************************************
 ** 자동으로 생성되는 이벤트 자바스크립트 함수를 배치
 ** (이벤트 생성시 자동으로 스크립트 함수 하위에 표시) 
 ************************************************/

/*
 * Body에서 load 이벤트 발생 시 호출.
 * 앱이 최초 구성된후 최초 랜더링 직후에 발생하는 이벤트 입니다.
 */
function onBodyLoad(e) {
	doHomeLayout(true);

	/* 카드형 타일 쉘의 load 이벤트는 코드에서 직접 연결한다. 디자인 편집기에서 쉘을 수정하다 보면 clx의 load 리스너가
	 * 빠지는 일이 있어, 그러면 숨겨진 행에서 보이게 되어도 차트가 그려지지 않는다. */
	for (var i = 0; i < 6; i++) {
		(function(psId) {
			app.lookup(psId).addEventListener("load", function(e) {
				onGaugeShellLoad(psId, e.content);
			});
		})("shlPerfTile" + i);
	}

	/* 창 크기뿐 아니라 메인의 MDI 확장·사이드 메뉴 접기처럼 창은 그대로이고 화면 영역만 바뀌는 경우도 잡도록
	 * 루트 요소 크기를 감시한다. 컨트롤의 resize 이벤트는 이 경우 오지 않고(창 크기를 바꿔도 안 옴),
	 * ResizeObserver는 DOM 요소가 필요하므로 여기서만 DOM으로 찾는다. 홈 루트(_home)는 화면에 하나뿐이다. */
	var voRoot = document.querySelector("._home");
	if (window.ResizeObserver && voRoot) {
		moResizeObserver = new ResizeObserver(function() {
			if (app.disposed) return;
			/* eXBuilder 레이아웃이 끝난 뒤 배율을 다시 구한다 */
			clearTimeout(moScaleTimer);
			moScaleTimer = setTimeout(function() {
				if (!app.disposed) doHomeLayout();
			}, 200);
		});
		moResizeObserver.observe(voRoot);
	}

	/* 사이드바 모드 토글·설정 팝업으로 테마가 바뀌면 body의 data-xb-color 속성이 바뀐다.
	 * 게이지 트랙 색은 그릴 때 테마 변수에서 읽으므로 보이는 게이지를 다시 그린다 */
	if (window.MutationObserver) {
		moThemeObserver = new MutationObserver(function() {
			if (app.disposed) return;
			Object.keys(moGaugeDoms).forEach(function(psId) {
				/* 숨은 쪽(0 크기)은 보이게 될 때 다시 그려지므로 건너뛴다 */
				if (moGaugeDoms[psId].clientWidth > 0) drawGauge(psId, moGaugeDoms[psId]);
			});
		});
		moThemeObserver.observe(document.body, { attributes: true, attributeFilter: ["data-xb-color"] });
	}
}

/*
 * Body에서 unload 이벤트 발생 시 호출.
 * 앱이 언로드된 후 발생하는 이벤트입니다.
 */
function onBodyUnload(e) {
	Object.keys(moGauges).forEach(function(psId) { moGauges[psId].dispose(); });
	if (moResizeObserver) moResizeObserver.disconnect();
	if (moThemeObserver) moThemeObserver.disconnect();
	clearTimeout(moScaleTimer);
}

/*
 * 구분 라디오버튼(전체/경륜/경정 등)에서 selection-change 이벤트 발생 시 호출.
 * 조회는 데이터 연동 시 이 함수에서 처리한다. (e.control.value = 선택한 항목 값)
 * 라디오가 속한 카드(home-card)의 막대·숫자·원형 게이지를 처음부터 다시 채운다.
 */
function onSegChange(e) {
	refillHomeCard(e.control);
}

/*
 * 경륜경정 실적 보기 방식 라디오버튼(목록형/카드형)에서 selection-change 이벤트 발생 시 호출.
 */
function onViewChange(e) {
	var vbList = app.lookup("rdoPerfView").value == "list";
	/* 목록형은 grpPerfBody의 1행, 카드형은 2행 — 컨트롤 visible이 아니라 행 숨김으로 전환한다 */
	var voLayout = app.lookup("grpPerfBody").getLayout();
	voLayout.setRowVisible(0, vbList);
	voLayout.setRowVisible(1, !vbList);

	/* 전환한 카드(경륜경정 실적)만 다시 채운다 */
	refillHomeCard(app.lookup("grpCardPerf"));
}

/*
 * 원형 게이지 쉘에서 load 이벤트 발생 시 호출.
 * 쉘이 그려진 후 내용을 작성하는 이벤트. 쉘마다 핸들러를 따로 두어 id를 직접 넘긴다.
 */
function onShlGoalDonutLoad(e) { onGaugeShellLoad("shlGoalDonut", e.content); }

/*
 * 경주별 실시간 통합 모니터링 탭(경주현황/경주결과)에서 selection-change 이벤트 발생 시 호출.
 */
function onMonTabChange(e) {
	var vbStatus = app.lookup("rdoMon").value == "status";
	/* 경주현황은 grpMonBody의 1행, 경주결과는 2행 — 행 숨김으로 전환한다 */
	var voLayout = app.lookup("grpMonBody").getLayout();
	voLayout.setRowVisible(0, vbStatus);
	voLayout.setRowVisible(1, !vbStatus);

	/* 숨겨져 있던 결과표는 보이게 된 크기로 다시 그린다 */
	if (!vbStatus) {
		cpr.core.DeferredUpdateManager.INSTANCE.asyncExec(function() {
			if (!app.disposed) app.lookup("grdRaceResult").redraw();
		});
	}
}

/*
 * 전체 출주표 (PDF) 버튼에서 click 이벤트 발생 시 호출.
 * 전체 출주표 (PDF) 팝업을 연다.
 * 팝업 본문이 1fr 행이라 높이 자동(-1)이면 0으로 접히므로 높이를 지정한다.
 */
function onBtnRacePdfClick(e) {
	util.Dialog.open(app, "app/pub/COM/comStartList", 896, 600, null);
}

/*
 * 본장 · 지사 카드에서 click 이벤트 발생 시 호출.
 * 해당 지사(본장)의 매출액 팝업을 연다. 지사명은 카드의 fieldLabel 앞부분(「광명 매출액」 → 광명).
 */
function onBranchCardClick(e) {
	/* 카드 안 지사명 버튼을 눌러도 이벤트가 올라오므로 카드(branch-card)까지 거슬러 올라가 fieldLabel을 읽는다 */
	var vcCard = e.control;
	while (vcCard && !vcCard.style.hasClass("branch-card")) vcCard = vcCard.getParent();
	if (!vcCard) return;
	var vsBrnchNm = String(vcCard.fieldLabel || "").split(" ")[0];
	util.Dialog.open(app, "app/pub/COM/comBranchSales", 1200, 720, null, { BRNCH_NM: vsBrnchNm });
}

/*
 * 출주선수 카드에서 click 이벤트 발생 시 호출.
 * 선수조회 팝업을 연다. 선수 번호 · 이름은 카드의 fieldLabel(「1번 이OO 선수」)에서 읽어 initValue로 넘긴다.
 * 팝업 본문은 세로 스크롤이라 높이를 지정한다(창보다 크면 Dialog.open이 창 높이로 줄인다).
 */
function onRunnerCardClick(e) {
	/* 카드 안 이름 버튼을 눌러도 이벤트가 올라오므로 카드(runner-card)까지 거슬러 올라간다 */
	var vcCard = e.control;
	while (vcCard && !vcCard.style.hasClass("runner-card")) vcCard = vcCard.getParent();
	if (!vcCard) return;
	var vaLabel = String(vcCard.fieldLabel || "").split(" ");
	util.Dialog.open(app, "app/pub/COM/comRacerInfo", 896, 800, null, {
		RACER_NO: parseInt(vaLabel[0], 10),
		RACER_NM: vaLabel[1]
	});
}
function onShlPerfRing0Load(e) { onGaugeShellLoad("shlPerfRing0", e.content); }
function onShlPerfRing1Load(e) { onGaugeShellLoad("shlPerfRing1", e.content); }
function onShlPerfRing2Load(e) { onGaugeShellLoad("shlPerfRing2", e.content); }
